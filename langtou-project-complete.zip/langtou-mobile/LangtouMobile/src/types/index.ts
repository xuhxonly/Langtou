// ============ 通用类型 ============

export interface PaginatedResult<T> {
  list: T[];
  total: number;
  page: number;
  pageSize: number;
  hasMore: boolean;
}

export interface ApiResponse<T = any> {
  code: number;
  message: string;
  data: T;
}

// ============ 用户类型 ============

export interface User {
  id: string;
  username: string;
  nickname: string;
  avatar: string;
  bio: string;
  followersCount: number;
  followingCount: number;
  likesCount: number;
  notesCount?: number;
  isFollowing?: boolean;
}

export interface UserProfile extends User {
  gender?: string;
  location?: string;
  website?: string;
  birthday?: string;
  createdAt: string;
}

export interface LoginRequest {
  phone: string;
  code: string;
}

export interface UsernamePasswordLoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  password: string;
  phone?: string;
  nickname?: string;
}

export interface LoginResponse {
  token: string;
  refreshToken: string;
  user: User;
}

// ============ 笔记类型 ============

export interface Note {
  id: string;
  title: string;
  content: string;
  images: string[];
  imageWidth?: number;
  imageHeight?: number;
  author: User;
  likes: number;
  comments: number;
  collects: number;
  isLiked?: boolean;
  isCollected?: boolean;
  createdAt: string;
  tags: string[];
}

export interface NoteDetail extends Note {
  images: string[];
  content: string;
  author: User;
  tags: Tag[];
  commentsList?: Comment[];
  isLiked: boolean;
  isCollected: boolean;
}

export interface NoteFeed {
  notes: Note[];
  hasMore: boolean;
  page: number;
}

export interface CreateNoteRequest {
  title: string;
  content: string;
  images: string[];
  tags: string[];
}

// ============ 标签类型 ============

export interface Tag {
  id: string;
  name: string;
  count: number;
  isHot?: boolean;
}

// ============ 评论类型 ============

export interface Comment {
  id: string;
  content: string;
  author: User;
  createdAt: string;
  likes: number;
  isLiked?: boolean;
  noteId?: string;
  parentId?: string;
  replyTo?: User;
  replies?: Comment[];
}

export interface CreateCommentRequest {
  noteId: string;
  content: string;
  parentId?: string;
  replyToUserId?: string;
}

// ============ 消息类型 ============

export interface Conversation {
  id: string;
  userId: string;
  user: User;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  updatedAt: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  content: string;
  type: 'text' | 'image' | 'note';
  createdAt: string;
  isRead: boolean;
}

export interface SendMessageRequest {
  receiverId: string;
  content: string;
  messageType?: number; // 1-文本, 2-图片
}

// ============ 通知类型 ============

export interface Notification {
  id: string;
  type: 'like' | 'comment' | 'follow' | 'collect' | 'system';
  fromUser: User;
  note?: Note;
  content?: string;
  createdAt: string;
  isRead: boolean;
}

export interface UnreadCount {
  total: number;
  likes: number;
  comments: number;
  follows: number;
  system: number;
}

// ============ 主题类型 ============

export interface ThemeColors {
  primary: string;
  secondary: string;
  background: string;
  surface: string;
  text: string;
  textSecondary: string;
  border: string;
  error: string;
  success: string;
  warning: string;
  overlay: string;
}

export type ThemeMode = 'light' | 'dark';

// ============ 搜索类型 ============

export interface SearchResult {
  notes?: PaginatedResult<Note>;
  users?: User[];
}
