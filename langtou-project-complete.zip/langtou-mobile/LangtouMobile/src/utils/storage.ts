import { MMKV } from 'react-native-mmkv';

const storage = new MMKV();

export const Storage = {
  set: (key: string, value: string) => storage.set(key, value),
  get: (key: string): string | undefined => storage.getString(key),
  remove: (key: string) => storage.delete(key),
  setObject: <T>(key: string, value: T) => storage.set(key, JSON.stringify(value)),
  getObject: <T>(key: string): T | null => {
    const json = storage.getString(key);
    return json ? (JSON.parse(json) as T) : null;
  },
};
