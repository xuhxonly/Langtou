import type { Note, User, Notification } from '../types';

const mockUsers: User[] = [
  {
    id: 'u1',
    username: 'traveler_xiaoming',
    nickname: '旅行家小明',
    avatar: 'https://i.pravatar.cc/150?u=u1',
    bio: '热爱旅行，记录生活点滴',
    followersCount: 12500,
    followingCount: 320,
    likesCount: 89000,
  },
  {
    id: 'u2',
    username: 'foodie_lili',
    nickname: '美食探店莉莉',
    avatar: 'https://i.pravatar.cc/150?u=u2',
    bio: '吃遍天下美食',
    followersCount: 56000,
    followingCount: 120,
    likesCount: 320000,
  },
  {
    id: 'u3',
    username: 'fashion_anna',
    nickname: '时尚达人Anna',
    avatar: 'https://i.pravatar.cc/150?u=u3',
    bio: '分享穿搭灵感',
    followersCount: 89000,
    followingCount: 500,
    likesCount: 560000,
  },
  {
    id: 'u4',
    username: 'tech_geek',
    nickname: '科技极客',
    avatar: 'https://i.pravatar.cc/150?u=u4',
    bio: '数码产品评测',
    followersCount: 34000,
    followingCount: 200,
    likesCount: 180000,
  },
  {
    id: 'u5',
    username: 'cat_lover',
    nickname: '铲屎官日记',
    avatar: 'https://i.pravatar.cc/150?u=u5',
    bio: '两只猫咪的日常',
    followersCount: 67000,
    followingCount: 150,
    likesCount: 420000,
  },
];

const noteTitles = [
  '周末去哪儿？这家咖啡馆太治愈了',
  '新手化妆教程，五分钟出门妆',
  '杭州西湖一日游攻略',
  '这款口红真的太好看了！',
  '独居生活的小确幸',
  '减脂餐打卡第30天',
  '手机摄影技巧分享',
  '租房改造前后对比',
  '书单推荐 | 这个月读的五本好书',
  '周末自制brunch',
];

const noteContents = [
  '今天发现了一家藏在巷子里的咖啡馆，环境超级温馨，适合一个人发呆或者和朋友聊天。',
  '分享一个超简单的日常妆容，只需要五个步骤就能出门，新手也能轻松学会！',
  '西湖的美真的四季不同，这次去正好赶上荷花盛开，随手一拍都是大片。',
  '终于入手了这支热门色号，上嘴效果真的绝了，显白又高级！',
  '一个人住虽然偶尔会感到孤单，但更多的是自由和惬意。',
  '坚持了一个月健康饮食，不仅瘦了五斤，皮肤也变好了！',
  '不用专业相机，用手机也能拍出大片感，这几个构图技巧一定要学。',
  '花了两周时间把出租屋改造成了喜欢的样子，每天回家都有好心情。',
  '这个月读了五本书，每一本都很精彩，推荐给大家！',
  '周末早起给自己做了一份精致的brunch，生活需要仪式感。',
];

const tagsList = [
  ['咖啡', '探店', '周末'],
  ['美妆', '教程', '日常'],
  ['旅行', '杭州', '攻略'],
  ['口红', '美妆', '种草'],
  ['独居', '生活', '日常'],
  ['减脂', '健身', '饮食'],
  ['摄影', '手机', '技巧'],
  ['租房', '改造', '家居'],
  ['读书', '书单', '推荐'],
  ['美食', 'brunch', '周末'],
];

export function generateMockNotes(page: number = 1, pageSize: number = 10): Note[] {
  const notes: Note[] = [];
  const startIndex = (page - 1) * pageSize;

  for (let i = 0; i < pageSize; i++) {
    const index = (startIndex + i) % noteTitles.length;
    const userIndex = (startIndex + i) % mockUsers.length;
    const height = 200 + Math.random() * 300;

    notes.push({
      id: `note_${page}_${i}`,
      title: noteTitles[index],
      content: noteContents[index],
      images: [
        `https://picsum.photos/400/${Math.floor(height)}?random=${page * pageSize + i}`,
      ],
      author: mockUsers[userIndex],
      likes: Math.floor(Math.random() * 5000) + 100,
      comments: Math.floor(Math.random() * 500) + 10,
      collects: Math.floor(Math.random() * 2000) + 50,
      isLiked: Math.random() > 0.7,
      isCollected: Math.random() > 0.8,
      createdAt: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString(),
      tags: tagsList[index],
    });
  }

  return notes;
}

export function generateMockUser(): User {
  return {
    id: 'current_user',
    username: 'langtou_user',
    nickname: '榔头用户',
    avatar: 'https://i.pravatar.cc/150?u=current',
    bio: '记录美好生活',
    followersCount: 128,
    followingCount: 56,
    likesCount: 2340,
  };
}

export function generateMockNotifications(): Notification[] {
  return [
    {
      id: 'n1',
      type: 'like',
      fromUser: mockUsers[0],
      note: generateMockNotes(1, 1)[0],
      createdAt: new Date(Date.now() - 5 * 60000).toISOString(),
      isRead: false,
    },
    {
      id: 'n2',
      type: 'comment',
      fromUser: mockUsers[1],
      content: '拍得太好看了！',
      createdAt: new Date(Date.now() - 30 * 60000).toISOString(),
      isRead: false,
    },
    {
      id: 'n3',
      type: 'follow',
      fromUser: mockUsers[2],
      createdAt: new Date(Date.now() - 2 * 3600000).toISOString(),
      isRead: true,
    },
    {
      id: 'n4',
      type: 'collect',
      fromUser: mockUsers[3],
      note: generateMockNotes(1, 1)[0],
      createdAt: new Date(Date.now() - 5 * 3600000).toISOString(),
      isRead: true,
    },
  ];
}

export { mockUsers };
