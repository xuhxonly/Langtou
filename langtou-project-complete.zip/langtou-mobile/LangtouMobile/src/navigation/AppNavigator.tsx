import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { TabNavigator } from './TabNavigator';
import { LoginScreen } from '../screens/auth/LoginScreen';
import { RegisterScreen } from '../screens/auth/RegisterScreen';
import { NoteDetailScreen } from '../screens/home/NoteDetailScreen';
import { UserProfileScreen } from '../screens/profile/UserProfileScreen';
import { EditProfileScreen } from '../screens/profile/EditProfileScreen';
import { ChatDetailScreen } from '../screens/message/ChatDetailScreen';
import { SearchResultScreen } from '../screens/discover/SearchResultScreen';
import { SettingsScreen } from '../screens/profile/SettingsScreen';
import { CollectionListScreen } from '../screens/profile/CollectionListScreen';
import { FollowerListScreen } from '../screens/profile/FollowerListScreen';
import { FollowingListScreen } from '../screens/profile/FollowingListScreen';
import { EditNoteScreen } from '../screens/publish/EditNoteScreen';

export type RootStackParamList = {
  Main: undefined;
  Login: undefined;
  Register: undefined;
  NoteDetail: { noteId: string };
  UserProfile: { userId: string };
  EditProfile: undefined;
  ChatDetail: { userId: string; nickname: string; avatar: string };
  SearchResult: { keyword: string };
  Settings: undefined;
  CollectionList: undefined;
  FollowerList: { userId: string };
  FollowingList: { userId: string };
  EditNote: { noteId: string };
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export const AppNavigator: React.FC = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Main" component={TabNavigator} />
        <Stack.Screen
          name="Login"
          component={LoginScreen}
          options={{ presentation: 'modal' }}
        />
        <Stack.Screen
          name="Register"
          component={RegisterScreen}
          options={{ presentation: 'modal' }}
        />
        <Stack.Screen
          name="NoteDetail"
          component={NoteDetailScreen}
          options={{ animation: 'slide_from_right' }}
        />
        <Stack.Screen
          name="UserProfile"
          component={UserProfileScreen}
          options={{ animation: 'slide_from_right' }}
        />
        <Stack.Screen
          name="EditProfile"
          component={EditProfileScreen}
          options={{ animation: 'slide_from_right' }}
        />
        <Stack.Screen
          name="ChatDetail"
          component={ChatDetailScreen}
          options={{ animation: 'slide_from_right' }}
        />
        <Stack.Screen
          name="SearchResult"
          component={SearchResultScreen}
          options={{ animation: 'slide_from_right' }}
        />
        <Stack.Screen
          name="Settings"
          component={SettingsScreen}
          options={{ animation: 'slide_from_right' }}
        />
        <Stack.Screen
          name="CollectionList"
          component={CollectionListScreen}
          options={{ animation: 'slide_from_right' }}
        />
        <Stack.Screen
          name="FollowerList"
          component={FollowerListScreen}
          options={{ animation: 'slide_from_right' }}
        />
        <Stack.Screen
          name="FollowingList"
          component={FollowingListScreen}
          options={{ animation: 'slide_from_right' }}
        />
        <Stack.Screen
          name="EditNote"
          component={EditNoteScreen}
          options={{ animation: 'slide_from_right' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};
