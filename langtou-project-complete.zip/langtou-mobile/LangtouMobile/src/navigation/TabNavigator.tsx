import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text, StyleSheet, View, TouchableOpacity } from 'react-native';
import { HomeScreen } from '../screens/home/HomeScreen';
import { DiscoverScreen } from '../screens/discover/DiscoverScreen';
import { PublishScreen } from '../screens/publish/PublishScreen';
import { MessageScreen } from '../screens/message/MessageScreen';
import { ProfileScreen } from '../screens/profile/ProfileScreen';
import { useTheme } from '../hooks/useTheme';

export type TabParamList = {
  Home: undefined;
  Discover: undefined;
  Publish: undefined;
  Message: undefined;
  Profile: undefined;
};

const Tab = createBottomTabNavigator<TabParamList>();

const TAB_ICONS: Record<string, { active: string; inactive: string }> = {
  Home: { active: '🏠', inactive: '🏠' },
  Discover: { active: '🔍', inactive: '🔍' },
  Publish: { active: '➕', inactive: '➕' },
  Message: { active: '💬', inactive: '💬' },
  Profile: { active: '👤', inactive: '👤' },
};

const TAB_LABELS: Record<string, string> = {
  Home: '首页',
  Discover: '发现',
  Publish: '发布',
  Message: '消息',
  Profile: '我的',
};

export const TabNavigator: React.FC = () => {
  const { colors } = useTheme();

  return (
    <Tab.Navigator
      screenOptions={({ route, navigation }) => ({
        headerShown: false,
        tabBarStyle: [
          styles.tabBar,
          { backgroundColor: colors.surface, borderTopColor: colors.border },
        ],
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textSecondary,
        tabBarIcon: ({ focused }) => {
          if (route.name === 'Publish') {
            return (
              <View style={styles.publishIconContainer}>
                <View style={styles.publishIcon}>
                  <Text style={styles.publishIconText}>+</Text>
                </View>
              </View>
            );
          }
          return (
            <Text style={styles.icon}>
              {focused
                ? TAB_ICONS[route.name].active
                : TAB_ICONS[route.name].inactive}
            </Text>
          );
        },
        tabBarLabel: ({ focused }) => {
          if (route.name === 'Publish') {
            return <Text style={[styles.label, { color: colors.textSecondary }]}>发布</Text>;
          }
          return (
            <Text
              style={[
                styles.label,
                { color: focused ? colors.primary : colors.textSecondary },
              ]}
            >
              {TAB_LABELS[route.name]}
            </Text>
          );
        },
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Discover" component={DiscoverScreen} />
      <Tab.Screen
        name="Publish"
        component={PublishScreen}
        options={{
          tabBarIcon: () => (
            <View style={styles.publishIconContainer}>
              <View style={styles.publishIcon}>
                <Text style={styles.publishIconText}>+</Text>
              </View>
            </View>
          ),
        }}
      />
      <Tab.Screen name="Message" component={MessageScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  );
};

const styles = StyleSheet.create({
  tabBar: {
    height: 56,
    borderTopWidth: 1,
    paddingBottom: 4,
    paddingTop: 4,
  },
  icon: {
    fontSize: 20,
    marginBottom: 2,
  },
  label: {
    fontSize: 11,
    fontWeight: '500',
  },
  publishIconContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  publishIcon: {
    width: 44,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#FF2442',
    justifyContent: 'center',
    alignItems: 'center',
  },
  publishIconText: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: '300',
    marginTop: -2,
  },
});
