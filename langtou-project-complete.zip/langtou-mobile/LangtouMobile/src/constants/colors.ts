import type { ThemeColors } from '../types';

export const LightColors: ThemeColors = {
  primary: '#FF2442',
  secondary: '#FF5722',
  background: '#F5F5F5',
  surface: '#FFFFFF',
  text: '#333333',
  textSecondary: '#999999',
  border: '#E5E5E5',
  error: '#FF4D4F',
  success: '#52C41A',
  warning: '#FAAD14',
  overlay: 'rgba(0, 0, 0, 0.5)',
};

export const DarkColors: ThemeColors = {
  primary: '#FF2442',
  secondary: '#FF5722',
  background: '#121212',
  surface: '#1E1E1E',
  text: '#E0E0E0',
  textSecondary: '#A0A0A0',
  border: '#333333',
  error: '#FF4D4F',
  success: '#52C41A',
  warning: '#FAAD14',
  overlay: 'rgba(0, 0, 0, 0.7)',
};

export const Colors = {
  light: LightColors,
  dark: DarkColors,
};
