/**
 * API 路径常量 - 与后端路由完全对齐
 * 基础路径: /api/v1 (由 axios baseURL 配置)
 */

// ============ 认证相关 ============
export const AUTH = {
  LOGIN: '/auth/login',               // POST 用户名密码登录
  SMS_LOGIN: '/auth/sms-login',       // POST 手机号验证码登录
  REGISTER: '/auth/register',         // POST 注册
  REFRESH: '/auth/refresh',           // POST 刷新Token
  SEND_SMS_CODE: '/auth/send-sms-code', // POST 发送短信验证码
} as const;

// ============ 用户相关 ============
export const USERS = {
  ME: '/users/me',                              // GET 当前用户信息
  ME_PROFILE: '/users/me/profile',              // PUT 修改个人资料
  ME_AVATAR: '/users/me/avatar',                // POST 上传头像
  ME_COLLECTIONS: '/users/me/collections',      // GET 我的收藏
  DETAIL: (userId: string) => `/users/${userId}`,          // GET 用户详情
  PROFILE: (userId: string) => `/users/${userId}/profile`, // GET 用户公开资料
  FOLLOW: (userId: string) => `/users/${userId}/follow`,   // POST/DELETE 关注/取消关注
  FOLLOWERS: (userId: string) => `/users/${userId}/followers`, // GET 粉丝列表
  FOLLOWING: (userId: string) => `/users/${userId}/following`, // GET 关注列表
  RELATIONSHIP: (userId: string) => `/users/${userId}/relationship`, // GET 关系查询
  NOTES: (userId: string) => `/users/${userId}/notes`,   // GET 用户笔记列表
} as const;

// ============ 笔记/内容相关 ============
export const NOTES = {
  LIST: '/notes',                               // GET 笔记Feed流
  FOLLOWING: '/notes/following',                // GET 关注用户Feed流
  DETAIL: (noteId: string) => `/notes/${noteId}`,         // GET 笔记详情
  UPDATE: (noteId: string) => `/notes/${noteId}`,         // PUT 编辑笔记
  DELETE: (noteId: string) => `/notes/${noteId}`,         // DELETE 删除笔记
  LIKE: (noteId: string) => `/notes/${noteId}/like`,      // POST/DELETE 点赞/取消点赞
  COLLECT: (noteId: string) => `/notes/${noteId}/collect`, // POST/DELETE 收藏/取消收藏
  COMMENTS: (noteId: string) => `/notes/${noteId}/comments`, // GET/POST 评论列表/发表评论
  SHARE: (noteId: string) => `/notes/${noteId}/share`,   // POST 转发
  SHARE_LINK: (noteId: string) => `/notes/${noteId}/share-link`, // GET 分享链接
} as const;

// ============ 评论相关 ============
export const COMMENTS = {
  DETAIL: (commentId: string) => `/comments/${commentId}`,       // DELETE 删除评论
  LIKE: (commentId: string) => `/comments/${commentId}/like`,    // POST 点赞评论
} as const;

// ============ 消息相关 ============
export const MESSAGES = {
  SEND: '/messages/send',                                   // POST 发送消息
  CONVERSATIONS: '/messages/conversations',                  // GET 会话列表
  CONVERSATION: (userId: string) => `/messages/conversation/${userId}`, // GET 聊天记录
  MARK_READ: (userId: string) => `/messages/conversation/${userId}/read`, // PUT 标记会话已读
  DELETE: (messageId: string) => `/messages/${messageId}`,   // DELETE 删除消息
} as const;

// ============ 通知相关 ============
export const NOTIFICATIONS = {
  LIST: '/notifications',                                   // GET 通知列表
  UNREAD_COUNT: '/notifications/unread-count',              // GET 未读数
  READ_ALL: '/notifications/read-all',                      // PUT 全部已读
  MARK_READ: (id: string) => `/notifications/${id}/read`,   // PUT 标记单条已读
} as const;

// ============ 标签相关 ============
export const TAGS = {
  HOT: '/tags/hot',                                         // GET 热门标签
  SEARCH: '/tags/search',                                   // GET 标签搜索
  NOTES: (tagId: string) => `/tags/${tagId}/notes`,         // GET 标签下的笔记
} as const;

// ============ 搜索相关 ============
export const SEARCH = {
  UNIFIED: '/search',                                       // GET 统一搜索
  NOTES: '/search/notes',                                   // GET 搜索笔记
  USERS: '/search/users',                                   // GET 搜索用户
  HOT: '/search/hot',                                       // GET 热门搜索
} as const;

// ============ 上传相关 ============
export const UPLOAD = {
  FILE: '/upload',                                          // POST 文件上传（通用）
  IMAGE: '/upload',                                         // POST 图片上传（与后端 /upload 对齐）
} as const;
