export const API_BASE_URL = 'https://api.langtou.app/api/v1';

export const STORAGE_KEYS = {
  AUTH_TOKEN: '@auth_token',
  REFRESH_TOKEN: '@refresh_token',
  USER_INFO: '@user_info',
  THEME_MODE: '@theme_mode',
} as const;

export const PAGE_SIZE = 20;

export const TAB_BAR_HEIGHT = 56;
