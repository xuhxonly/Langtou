import { useQuery, useMutation, useQueryClient, useInfiniteQuery } from '@tanstack/react-query';
import {
  getFeed,
  likeNote,
  unlikeNote,
  collectNote,
  uncollectNote,
  getNoteDetail,
  getUserNotes,
  searchNotes,
  getHotTags,
  updateNote,
} from '../api/content';
import { createNote, deleteNote, uploadImage } from '../api/content';
import type { CreateNoteRequest, PaginatedResult, Note, NoteDetail, Tag } from '../types';

// ============ Feed流（分页查询） ============

export function useNotes(page: number = 1) {
  return useQuery({
    queryKey: ['notes', page],
    queryFn: () => getFeed(page),
  });
}

export function useInfiniteFeed() {
  return useInfiniteQuery({
    queryKey: ['feed'],
    queryFn: ({ pageParam = 1 }) => getFeed(pageParam),
    getNextPageParam: (lastPage) => {
      // 使用后端返回的 hasMore 判断是否还有下一页
      if (lastPage.hasMore) {
        return lastPage.page + 1;
      }
      return undefined;
    },
    initialPageParam: 1,
  });
}

// ============ 笔记详情 ============

export function useNoteDetail(noteId: string) {
  return useQuery({
    queryKey: ['noteDetail', noteId],
    queryFn: () => getNoteDetail(noteId),
    enabled: !!noteId,
  });
}

// ============ 用户笔记 ============

export function useUserNotes(userId: string, page: number = 1) {
  return useQuery({
    queryKey: ['userNotes', userId, page],
    queryFn: () => getUserNotes(userId, page),
    enabled: !!userId,
  });
}

// ============ 搜索笔记 ============

export function useSearchNotes(keyword: string, page: number = 1) {
  return useQuery({
    queryKey: ['searchNotes', keyword, page],
    queryFn: () => searchNotes(keyword, page),
    enabled: !!keyword.trim(),
  });
}

// ============ 热门标签 ============

export function useHotTags() {
  return useQuery({
    queryKey: ['hotTags'],
    queryFn: getHotTags,
    staleTime: 5 * 60 * 1000, // 5分钟缓存
  });
}

// ============ 点赞（乐观更新） ============

export function useLikeNote() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ noteId, isLiked }: { noteId: string; isLiked: boolean }) => {
      if (isLiked) {
        return unlikeNote(noteId);
      }
      return likeNote(noteId);
    },
    onMutate: async ({ noteId, isLiked }) => {
      // 取消所有正在进行的查询
      await queryClient.cancelQueries({ queryKey: ['notes'] });
      await queryClient.cancelQueries({ queryKey: ['feed'] });
      await queryClient.cancelQueries({ queryKey: ['noteDetail', noteId] });

      // 乐观更新 Feed 列表
      const previousNotes = queryClient.getQueriesData<PaginatedResult<Note>>({ queryKey: ['feed'] });

      queryClient.setQueriesData<PaginatedResult<Note>>({ queryKey: ['feed'] }, (oldData) => {
        if (!oldData) return oldData;
        return {
          ...oldData,
          list: oldData.list.map((note) =>
            note.id === noteId
              ? {
                  ...note,
                  isLiked: !isLiked,
                  likes: isLiked ? Math.max(0, note.likes - 1) : note.likes + 1,
                }
              : note
          ),
        };
      });

      // 乐观更新详情
      const previousDetail = queryClient.getQueryData<NoteDetail>(['noteDetail', noteId]);
      if (previousDetail) {
        queryClient.setQueryData(['noteDetail', noteId], {
          ...previousDetail,
          isLiked: !isLiked,
          likes: isLiked
            ? Math.max(0, previousDetail.likes - 1)
            : previousDetail.likes + 1,
        });
      }

      return { previousNotes, previousDetail };
    },
    onError: (_err, { noteId }, context) => {
      // 回滚
      if (context?.previousNotes) {
        context.previousNotes.forEach(([key, data]) => {
          queryClient.setQueryData(key, data);
        });
      }
      if (context?.previousDetail) {
        queryClient.setQueryData(['noteDetail', noteId], context.previousDetail);
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['feed'] });
    },
  });
}

// ============ 收藏（乐观更新） ============

export function useCollectNote() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ noteId, isCollected }: { noteId: string; isCollected: boolean }) => {
      if (isCollected) {
        return uncollectNote(noteId);
      }
      return collectNote(noteId);
    },
    onMutate: async ({ noteId, isCollected }) => {
      await queryClient.cancelQueries({ queryKey: ['notes'] });
      await queryClient.cancelQueries({ queryKey: ['feed'] });
      await queryClient.cancelQueries({ queryKey: ['noteDetail', noteId] });

      const previousNotes = queryClient.getQueriesData<PaginatedResult<Note>>({ queryKey: ['feed'] });

      queryClient.setQueriesData<PaginatedResult<Note>>({ queryKey: ['feed'] }, (oldData) => {
        if (!oldData) return oldData;
        return {
          ...oldData,
          list: oldData.list.map((note) =>
            note.id === noteId
              ? {
                  ...note,
                  isCollected: !isCollected,
                  collects: isCollected
                    ? Math.max(0, note.collects - 1)
                    : note.collects + 1,
                }
              : note
          ),
        };
      });

      const previousDetail = queryClient.getQueryData<NoteDetail>(['noteDetail', noteId]);
      if (previousDetail) {
        queryClient.setQueryData(['noteDetail', noteId], {
          ...previousDetail,
          isCollected: !isCollected,
          collects: isCollected
            ? Math.max(0, previousDetail.collects - 1)
            : previousDetail.collects + 1,
        });
      }

      return { previousNotes, previousDetail };
    },
    onError: (_err, { noteId }, context) => {
      if (context?.previousNotes) {
        context.previousNotes.forEach(([key, data]) => {
          queryClient.setQueryData(key, data);
        });
      }
      if (context?.previousDetail) {
        queryClient.setQueryData(['noteDetail', noteId], context.previousDetail);
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['feed'] });
    },
  });
}

// ============ 编辑笔记 ============

export function useUpdateNote() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ noteId, data }: { noteId: string; data: Partial<CreateNoteRequest> }) =>
      updateNote(noteId, data),
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['notes'] });
      queryClient.invalidateQueries({ queryKey: ['feed'] });
      queryClient.invalidateQueries({ queryKey: ['noteDetail', variables.noteId] });
      queryClient.invalidateQueries({ queryKey: ['userNotes'] });
    },
  });
}

// ============ 发布笔记 ============

export function useCreateNote() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: CreateNoteRequest) => createNote(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notes'] });
      queryClient.invalidateQueries({ queryKey: ['feed'] });
    },
  });
}

// ============ 删除笔记 ============

export function useDeleteNote() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: deleteNote,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notes'] });
      queryClient.invalidateQueries({ queryKey: ['feed'] });
      queryClient.invalidateQueries({ queryKey: ['userNotes'] });
    },
  });
}

// ============ 上传图片 ============

export function useUploadImage() {
  return useMutation({
    mutationFn: uploadImage,
  });
}
