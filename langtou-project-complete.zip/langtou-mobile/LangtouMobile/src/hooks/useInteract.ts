import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  like,
  unlike,
  collect,
  uncollect,
  getComments,
  createComment,
  getCollections,
  removeCollection,
} from '../api/interact';
import type { CreateCommentRequest, Comment, PaginatedResult, Note } from '../types';

// ============ 点赞（乐观更新） ============

export function useLike() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ noteId, isLiked }: { noteId: string; isLiked: boolean }) => {
      if (isLiked) {
        return unlike(noteId);
      }
      return like(noteId);
    },
    onMutate: async ({ noteId, isLiked }) => {
      await queryClient.cancelQueries({ queryKey: ['noteDetail', noteId] });

      const previous = queryClient.getQueryData<any>(['noteDetail', noteId]);
      if (previous) {
        queryClient.setQueryData(['noteDetail', noteId], {
          ...previous,
          isLiked: !isLiked,
          likes: isLiked ? Math.max(0, previous.likes - 1) : previous.likes + 1,
        });
      }

      return { previous };
    },
    onError: (_err, { noteId }, context) => {
      if (context?.previous) {
        queryClient.setQueryData(['noteDetail', noteId], context.previous);
      }
    },
    onSettled: (_data, _err, { noteId }) => {
      queryClient.invalidateQueries({ queryKey: ['noteDetail', noteId] });
    },
  });
}

// ============ 收藏（乐观更新） ============

export function useCollect() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ noteId, isCollected }: { noteId: string; isCollected: boolean }) => {
      if (isCollected) {
        return uncollect(noteId);
      }
      return collect(noteId);
    },
    onMutate: async ({ noteId, isCollected }) => {
      await queryClient.cancelQueries({ queryKey: ['noteDetail', noteId] });

      const previous = queryClient.getQueryData<any>(['noteDetail', noteId]);
      if (previous) {
        queryClient.setQueryData(['noteDetail', noteId], {
          ...previous,
          isCollected: !isCollected,
          collects: isCollected
            ? Math.max(0, previous.collects - 1)
            : previous.collects + 1,
        });
      }

      return { previous };
    },
    onError: (_err, { noteId }, context) => {
      if (context?.previous) {
        queryClient.setQueryData(['noteDetail', noteId], context.previous);
      }
    },
    onSettled: (_data, _err, { noteId }) => {
      queryClient.invalidateQueries({ queryKey: ['noteDetail', noteId] });
    },
  });
}

// ============ 评论列表 ============

export function useComments(noteId: string, page: number = 1) {
  return useQuery({
    queryKey: ['comments', noteId, page],
    queryFn: () => getComments(noteId, page),
    enabled: !!noteId,
  });
}

// ============ 收藏列表 ============

export function useCollections(page: number = 1) {
  return useQuery({
    queryKey: ['collections', page],
    queryFn: () => getCollections(page),
  });
}

// ============ 取消收藏 ============

export function useRemoveCollection() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: removeCollection,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['collections'] });
    },
  });
}

// ============ 发表评论 ============

export function useCreateComment() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ noteId, data }: { noteId: string; data: CreateCommentRequest }) =>
      createComment(noteId, data),
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['comments', variables.noteId] });
      queryClient.invalidateQueries({ queryKey: ['noteDetail', variables.noteId] });
    },
  });
}
