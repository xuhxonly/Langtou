import { useThemeStore } from '../store/useThemeStore';

export function useTheme() {
  const { mode, colors, toggleTheme, setTheme } = useThemeStore();

  return {
    isDark: mode === 'dark',
    mode,
    colors,
    toggleTheme,
    setTheme,
  };
}
