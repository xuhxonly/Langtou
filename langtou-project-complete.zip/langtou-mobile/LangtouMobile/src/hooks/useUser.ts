import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  getUserProfile,
  getCurrentUser,
  updateUserProfile,
  updateAvatar,
  follow,
  unfollow,
  getFollowers,
  getFollowing,
  searchUsers,
  login as loginApi,
  register as registerApi,
  smsLogin,
} from '../api/user';
import { useAuthStore } from '../store/useAuthStore';
import { Storage } from '../utils/storage';
import { STORAGE_KEYS } from '../constants/config';
import type { LoginRequest, RegisterRequest, PaginatedResult, User, UserProfile } from '../types';

// ============ 用户资料 ============

export function useUserProfile(userId: string) {
  return useQuery({
    queryKey: ['userProfile', userId],
    queryFn: () => getUserProfile(userId),
    enabled: !!userId,
  });
}

// ============ 当前用户资料 ============

export function useCurrentUserProfile() {
  const { user } = useAuthStore();
  return useQuery({
    queryKey: ['currentUserProfile'],
    queryFn: () => getCurrentUser(),
    enabled: !!user?.id,
  });
}

// ============ 修改资料 ============

export function useUpdateUserProfile() {
  const queryClient = useQueryClient();
  const { updateUser } = useAuthStore();

  return useMutation({
    mutationFn: updateUserProfile,
    onSuccess: (updatedUser) => {
      updateUser(updatedUser);
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
    },
  });
}

// ============ 更新头像 ============

export function useUpdateAvatar() {
  const queryClient = useQueryClient();
  const { updateUser } = useAuthStore();

  return useMutation({
    mutationFn: updateAvatar,
    onSuccess: (avatarUrl) => {
      updateUser({ avatar: avatarUrl } as Partial<User>);
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
    },
  });
}

// ============ 关注/取消关注 ============

export function useFollowUser() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ userId, isFollowing }: { userId: string; isFollowing: boolean }) => {
      if (isFollowing) {
        return unfollow(userId);
      }
      return follow(userId);
    },
    onMutate: async ({ userId, isFollowing }) => {
      await queryClient.cancelQueries({ queryKey: ['userProfile', userId] });

      const previousProfile = queryClient.getQueryData<UserProfile>(['userProfile', userId]);
      if (previousProfile) {
        queryClient.setQueryData(['userProfile', userId], {
          ...previousProfile,
          isFollowing: !isFollowing,
          followersCount: isFollowing
            ? Math.max(0, previousProfile.followersCount - 1)
            : previousProfile.followersCount + 1,
        });
      }

      return { previousProfile };
    },
    onError: (_err, { userId }, context) => {
      if (context?.previousProfile) {
        queryClient.setQueryData(['userProfile', userId], context.previousProfile);
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['userProfile'] });
    },
  });
}

// ============ 粉丝列表 ============

export function useFollowers(userId: string, page: number = 1) {
  return useQuery({
    queryKey: ['followers', userId, page],
    queryFn: () => getFollowers(userId, page),
    enabled: !!userId,
  });
}

// ============ 关注列表 ============

export function useFollowing(userId: string, page: number = 1) {
  return useQuery({
    queryKey: ['following', userId, page],
    queryFn: () => getFollowing(userId, page),
    enabled: !!userId,
  });
}

// ============ 搜索用户 ============

export function useSearchUsers(keyword: string) {
  return useQuery({
    queryKey: ['searchUsers', keyword],
    queryFn: () => searchUsers(keyword),
    enabled: !!keyword.trim(),
  });
}

// ============ 登录 ============

export function useLogin() {
  const { login: storeLogin } = useAuthStore();

  return useMutation({
    mutationFn: (data: LoginRequest) => loginApi(data.phone, data.code),
    onSuccess: (res) => {
      Storage.set(STORAGE_KEYS.AUTH_TOKEN, res.token);
      Storage.set(STORAGE_KEYS.REFRESH_TOKEN, res.refreshToken);
      Storage.setObject(STORAGE_KEYS.USER_INFO, res.user);
      storeLogin(res.user, res.token);
    },
  });
}

// ============ 短信验证码登录 ============

export function useSmsLogin() {
  const { login: storeLogin } = useAuthStore();

  return useMutation({
    mutationFn: ({ phone, code }: { phone: string; code: string }) => smsLogin(phone, code),
    onSuccess: (res) => {
      Storage.set(STORAGE_KEYS.AUTH_TOKEN, res.token);
      Storage.set(STORAGE_KEYS.REFRESH_TOKEN, res.refreshToken);
      Storage.setObject(STORAGE_KEYS.USER_INFO, res.user);
      storeLogin(res.user, res.token);
    },
  });
}

// ============ 注册 ============

export function useRegister() {
  const { login: storeLogin } = useAuthStore();

  return useMutation({
    mutationFn: (data: RegisterRequest) => registerApi(data),
    onSuccess: (res) => {
      Storage.set(STORAGE_KEYS.AUTH_TOKEN, res.token);
      Storage.set(STORAGE_KEYS.REFRESH_TOKEN, res.refreshToken);
      Storage.setObject(STORAGE_KEYS.USER_INFO, res.user);
      storeLogin(res.user, res.token);
    },
  });
}
