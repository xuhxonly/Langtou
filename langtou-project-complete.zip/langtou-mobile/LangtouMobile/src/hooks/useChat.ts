import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  getConversations,
  getMessages,
  sendMessage,
  markConversationRead,
} from '../api/message';
import type { SendMessageRequest, PaginatedResult, Message } from '../types';

// ============ 会话列表 ============

export function useConversations() {
  return useQuery({
    queryKey: ['conversations'],
    queryFn: getConversations,
  });
}

// ============ 聊天记录 ============

export function useChatMessages(userId: string, page: number = 1) {
  return useQuery({
    queryKey: ['chatMessages', userId, page],
    queryFn: () => getMessages(userId, page),
    enabled: !!userId,
  });
}

// ============ 发送消息 ============

export function useSendMessage() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: SendMessageRequest) => sendMessage(data),
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['chatMessages', variables.receiverId] });
      queryClient.invalidateQueries({ queryKey: ['conversations'] });
    },
  });
}

// ============ 标记会话已读 ============

export function useMarkConversationRead() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (userId: string) => markConversationRead(userId),
    onSuccess: (_data, userId) => {
      queryClient.invalidateQueries({ queryKey: ['conversations'] });
    },
  });
}
