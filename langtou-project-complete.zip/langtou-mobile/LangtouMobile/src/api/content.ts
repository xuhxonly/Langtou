import apiClient from './client';
import type {
  Note,
  NoteDetail,
  PaginatedResult,
  CreateNoteRequest,
  Tag,
} from '../types';
import { NOTES, TAGS, UPLOAD, SEARCH, USERS } from '../constants/api';
import { generateMockNotes } from '../utils/mockData';

// ============ Feed流 ============

export async function getFeed(
  page: number = 1,
  size: number = 20
): Promise<PaginatedResult<Note>> {
  try {
    const data = await apiClient.get<{ total: number; page: number; size: number; records: Note[] }>(NOTES.LIST, {
      params: { page, size },
    });
    return {
      list: data.records,
      total: data.total,
      page: data.page,
      pageSize: data.size,
      hasMore: data.page * data.size < data.total,
    };
  } catch {
    // Mock fallback
    console.warn('[ContentAPI] getFeed fallback to mock');
    const notes = generateMockNotes(page, size);
    return {
      list: notes,
      total: 100,
      page,
      pageSize: size,
      hasMore: page < 5,
    };
  }
}

// ============ 关注用户Feed流 ============

export async function getFollowingFeed(
  page: number = 1,
  size: number = 20
): Promise<PaginatedResult<Note>> {
  try {
    const data = await apiClient.get<{ total: number; page: number; size: number; records: Note[] }>(NOTES.FOLLOWING, {
      params: { page, size },
    });
    return {
      list: data.records,
      total: data.total,
      page: data.page,
      pageSize: data.size,
      hasMore: data.page * data.size < data.total,
    };
  } catch {
    // Mock fallback
    console.warn('[ContentAPI] getFollowingFeed fallback to mock');
    const notes = generateMockNotes(page, size);
    return {
      list: notes,
      total: 50,
      page,
      pageSize: size,
      hasMore: page < 3,
    };
  }
}

// ============ 笔记详情 ============

export async function getNoteDetail(noteId: string): Promise<NoteDetail> {
  try {
    return await apiClient.get<NoteDetail>(NOTES.DETAIL(noteId));
  } catch {
    // Mock fallback
    console.warn('[ContentAPI] getNoteDetail fallback to mock');
    const notes = generateMockNotes(1, 10);
    const note = notes.find((n) => n.id === noteId) || notes[0];
    return {
      ...note,
      isLiked: note.isLiked ?? false,
      isCollected: note.isCollected ?? false,
      tags: note.tags.map((name, i) => ({
        id: `tag_${i}`,
        name,
        count: Math.floor(Math.random() * 1000) + 100,
        isHot: i < 2,
      })),
      commentsList: [],
    };
  }
}

// ============ 发布笔记 ============

export async function createNote(data: CreateNoteRequest): Promise<Note> {
  try {
    // 将前端 CreateNoteRequest 映射到后端 ContentDTO 字段
    const payload = {
      title: data.title,
      textContent: data.content,
      mediaUrls: data.images,
      contentType: 1, // 1-图文笔记
      tags: data.tags,
    };
    return await apiClient.post<Note>(NOTES.LIST, payload);
  } catch {
    // Mock fallback
    console.warn('[ContentAPI] createNote fallback to mock');
    return {
      id: `note_${Date.now()}`,
      title: data.title,
      content: data.content,
      images: data.images,
      author: {
        id: 'current_user',
        username: 'langtou_user',
        nickname: '榔头用户',
        avatar: 'https://i.pravatar.cc/150?u=current',
        bio: '记录美好生活',
        followersCount: 128,
        followingCount: 56,
        likesCount: 2340,
      },
      likes: 0,
      comments: 0,
      collects: 0,
      isLiked: false,
      isCollected: false,
      createdAt: new Date().toISOString(),
      tags: data.tags,
    };
  }
}

// ============ 编辑笔记 ============

export async function updateNote(
  noteId: string,
  data: Partial<CreateNoteRequest>
): Promise<Note> {
  try {
    const payload = {
      title: data.title,
      textContent: data.content,
      tags: data.tags,
    };
    return await apiClient.put<Note>(NOTES.UPDATE(noteId), payload);
  } catch {
    console.warn('[ContentAPI] updateNote fallback to mock');
    return {
      id: noteId,
      title: data.title || '',
      content: data.content || '',
      images: data.images || [],
      author: {
        id: 'current_user',
        username: 'langtou_user',
        nickname: '榔头用户',
        avatar: 'https://i.pravatar.cc/150?u=current',
        bio: '记录美好生活',
        followersCount: 128,
        followingCount: 56,
        likesCount: 2340,
      },
      likes: 0,
      comments: 0,
      collects: 0,
      isLiked: false,
      isCollected: false,
      createdAt: new Date().toISOString(),
      tags: data.tags || [],
    };
  }
}

// ============ 删除笔记 ============

export async function deleteNote(noteId: string): Promise<boolean> {
  try {
    await apiClient.delete(NOTES.DELETE(noteId));
    return true;
  } catch {
    console.warn('[ContentAPI] deleteNote fallback to mock');
    return true;
  }
}

// ============ 获取分享链接 ============

export async function getShareLink(noteId: string): Promise<string> {
  try {
    const data = await apiClient.get<{ shareLink: string }>(NOTES.SHARE_LINK(noteId));
    return data.shareLink;
  } catch {
    // Mock fallback
    console.warn('[ContentAPI] getShareLink fallback to mock');
    return `https://langtou.app/notes/${noteId}`;
  }
}

// ============ 用户笔记列表 ============

export async function getUserNotes(
  userId: string,
  page: number = 1,
  pageSize: number = 20
): Promise<PaginatedResult<Note>> {
  try {
    const data = await apiClient.get<{ total: number; page: number; size: number; records: Note[] }>(
      USERS.NOTES(userId),
      { params: { page, size: pageSize } }
    );
    return {
      list: data.records,
      total: data.total,
      page: data.page,
      pageSize: data.size,
      hasMore: data.page * data.size < data.total,
    };
  } catch {
    console.warn('[ContentAPI] getUserNotes fallback to mock');
    const notes = generateMockNotes(page, pageSize);
    return {
      list: notes,
      total: 30,
      page,
      pageSize,
      hasMore: page < 3,
    };
  }
}

// ============ 搜索笔记 ============

export async function searchNotes(
  keyword: string,
  page: number = 1,
  pageSize: number = 20
): Promise<PaginatedResult<Note>> {
  try {
    const data = await apiClient.get<{ total: number; page: number; size: number; records: Note[] }>(SEARCH.UNIFIED, {
      params: { keyword, type: 'note', page, size: pageSize },
    });
    return {
      list: data.records,
      total: data.total,
      page: data.page,
      pageSize: data.size,
      hasMore: data.page * data.size < data.total,
    };
  } catch {
    console.warn('[ContentAPI] searchNotes fallback to mock');
    const notes = generateMockNotes(page, pageSize);
    return {
      list: notes,
      total: 50,
      page,
      pageSize,
      hasMore: page < 3,
    };
  }
}

// ============ 热门标签 ============

export async function getHotTags(): Promise<Tag[]> {
  try {
    return await apiClient.get<Tag[]>(TAGS.HOT);
  } catch {
    // Mock fallback
    console.warn('[ContentAPI] getHotTags fallback to mock');
    return [
      { id: 't1', name: '夏日穿搭', count: 12500, isHot: true },
      { id: 't2', name: '减脂餐', count: 8900, isHot: true },
      { id: 't3', name: '杭州旅游', count: 6700, isHot: true },
      { id: 't4', name: '口红试色', count: 5400, isHot: true },
      { id: 't5', name: '独居生活', count: 4300, isHot: true },
      { id: 't6', name: '手机摄影', count: 3200, isHot: false },
      { id: 't7', name: '租房改造', count: 2800, isHot: false },
      { id: 't8', name: '书单推荐', count: 2100, isHot: false },
      { id: 't9', name: '周末brunch', count: 1800, isHot: false },
      { id: 't10', name: '咖啡探店', count: 1500, isHot: false },
    ];
  }
}

// ============ 上传图片 ============

export async function uploadImage(
  file: string | { uri: string; type: string; name: string },
  onProgress?: (progress: number) => void
): Promise<string> {
  try {
    const formData = new FormData();
    if (typeof file === 'string') {
      formData.append('file', {
        uri: file,
        type: 'image/jpeg',
        name: 'upload.jpg',
      } as any);
    } else {
      formData.append('file', file as any);
    }

    const data = await apiClient.post<{ url: string }>(UPLOAD.IMAGE, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      onUploadProgress: onProgress
        ? (progressEvent) => {
            const total = progressEvent.total || 1;
            const loaded = progressEvent.loaded || 0;
            onProgress(Math.round((loaded / total) * 100));
          }
        : undefined,
    });
    return data.url;
  } catch {
    // Mock fallback: 返回原始 URI
    console.warn('[ContentAPI] uploadImage fallback to mock');
    return typeof file === 'string' ? file : file.uri;
  }
}
