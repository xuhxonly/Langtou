import apiClient from './client';
import type { Note, User, PaginatedResult } from '../types';
import { SEARCH } from '../constants/api';
import { generateMockNotes, mockUsers } from '../utils/mockData';

/**
 * 获取热门搜索关键词
 */
export async function getHotSearch(): Promise<string[]> {
  try {
    return await apiClient.get<string[]>(SEARCH.HOT);
  } catch {
    // Mock fallback
    console.warn('[SearchAPI] getHotSearch fallback to mock');
    return ['夏日穿搭', '减脂餐', '杭州旅游', '口红试色', '独居生活'];
  }
}

/**
 * 统一搜索接口
 * @param keyword 搜索关键词
 * @param type 搜索类型: note | user
 * @param page 页码
 * @param pageSize 每页数量
 */
export async function search(
  keyword: string,
  type: 'note' | 'user',
  page: number = 1,
  pageSize: number = 20
): Promise<PaginatedResult<Note> | User[]> {
  try {
    if (type === 'note') {
      const data = await apiClient.get<{ total: number; page: number; size: number; records: Note[] }>(SEARCH.UNIFIED, {
        params: { keyword, type, page, size: pageSize },
      });
      return {
        list: data.records,
        total: data.total,
        page: data.page,
        pageSize: data.size,
        hasMore: data.page * data.size < data.total,
      } as PaginatedResult<Note>;
    }
    return await apiClient.get<User[]>(SEARCH.UNIFIED, {
      params: { keyword, type },
    });
  } catch {
    console.warn('[SearchAPI] search fallback to mock');
    if (type === 'note') {
      const notes = generateMockNotes(page, pageSize);
      return {
        list: notes,
        total: 50,
        page,
        pageSize,
        hasMore: page < 3,
      } as PaginatedResult<Note>;
    }
    return mockUsers.filter(
      (u) => u.nickname.includes(keyword) || u.username.includes(keyword)
    );
  }
}
