import apiClient from './client';
import type {
  Comment,
  CreateCommentRequest,
  PaginatedResult,
  Note,
} from '../types';
import { NOTES, USERS } from '../constants/api';
import { mockUsers, generateMockNotes } from '../utils/mockData';

// ============ 点赞 ============

export async function like(noteId: string): Promise<boolean> {
  try {
    await apiClient.post(NOTES.LIKE(noteId));
    return true;
  } catch {
    console.warn('[InteractAPI] like fallback to mock');
    return true;
  }
}

export async function unlike(noteId: string): Promise<boolean> {
  try {
    await apiClient.delete(NOTES.LIKE(noteId));
    return true;
  } catch {
    console.warn('[InteractAPI] unlike fallback to mock');
    return true;
  }
}

// ============ 收藏 ============

export async function collect(noteId: string): Promise<boolean> {
  try {
    await apiClient.post(NOTES.COLLECT(noteId));
    return true;
  } catch {
    console.warn('[InteractAPI] collect fallback to mock');
    return true;
  }
}

export async function uncollect(noteId: string): Promise<boolean> {
  try {
    await apiClient.delete(NOTES.COLLECT(noteId));
    return true;
  } catch {
    console.warn('[InteractAPI] uncollect fallback to mock');
    return true;
  }
}

// ============ 评论 ============

export async function getComments(
  noteId: string,
  page: number = 1,
  pageSize: number = 20
): Promise<PaginatedResult<Comment>> {
  try {
    const data = await apiClient.get<{ list: Comment[]; total: number; current: number; size: number; pages: number }>(
      NOTES.COMMENTS(noteId),
      { params: { current: page, size: pageSize } }
    );
    return {
      list: data.list,
      total: data.total,
      page: data.current,
      pageSize: data.size,
      hasMore: data.current < data.pages,
    };
  } catch {
    // Mock fallback
    console.warn('[InteractAPI] getComments fallback to mock');
    const mockComments: Comment[] = [
      {
        id: 'c1',
        content: '拍得太好看了！',
        author: mockUsers[0],
        createdAt: new Date(Date.now() - 10 * 60000).toISOString(),
        likes: 12,
        isLiked: false,
        noteId,
        replies: [
          {
            id: 'c1_r1',
            content: '谢谢喜欢~',
            author: mockUsers[1],
            createdAt: new Date(Date.now() - 5 * 60000).toISOString(),
            likes: 3,
            isLiked: false,
            noteId,
            parentId: 'c1',
            replyTo: mockUsers[0],
          },
        ],
      },
      {
        id: 'c2',
        content: '请问这是在哪里呀？',
        author: mockUsers[2],
        createdAt: new Date(Date.now() - 2 * 3600000).toISOString(),
        likes: 5,
        isLiked: false,
        noteId,
      },
      {
        id: 'c3',
        content: '收藏了，下次去打卡',
        author: mockUsers[3],
        createdAt: new Date(Date.now() - 5 * 3600000).toISOString(),
        likes: 8,
        isLiked: true,
        noteId,
      },
    ];
    return {
      list: mockComments,
      total: 3,
      page,
      pageSize,
      hasMore: false,
    };
  }
}

// ============ 收藏列表 ============

export async function getCollections(
  page: number = 1,
  pageSize: number = 20
): Promise<PaginatedResult<Note>> {
  try {
    const data = await apiClient.get<{ total: number; page: number; size: number; records: Note[] }>(
      USERS.ME_COLLECTIONS,
      { params: { page, size: pageSize } }
    );
    return {
      list: data.records,
      total: data.total,
      page: data.page,
      pageSize: data.size,
      hasMore: data.page * data.size < data.total,
    };
  } catch {
    console.warn('[InteractAPI] getCollections fallback to mock');
    const notes = generateMockNotes(page, pageSize);
    return {
      list: notes,
      total: 30,
      page,
      pageSize,
      hasMore: page < 3,
    };
  }
}

export async function removeCollection(noteId: string): Promise<boolean> {
  try {
    await apiClient.delete(NOTES.COLLECT(noteId));
    return true;
  } catch {
    console.warn('[InteractAPI] removeCollection fallback to mock');
    return true;
  }
}

export async function createComment(noteId: string, data: CreateCommentRequest): Promise<Comment> {
  try {
    // 后端接收 Map<String, Object>，包含 content 和 parentId
    const params: Record<string, any> = { content: data.content };
    if (data.parentId) {
      params.parentId = data.parentId;
    }
    return await apiClient.post<Comment>(NOTES.COMMENTS(noteId), params);
  } catch {
    // Mock fallback
    console.warn('[InteractAPI] createComment fallback to mock');
    return {
      id: `comment_${Date.now()}`,
      content: data.content,
      author: {
        id: 'current_user',
        username: 'langtou_user',
        nickname: '榔头用户',
        avatar: 'https://i.pravatar.cc/150?u=current',
        bio: '记录美好生活',
        followersCount: 128,
        followingCount: 56,
        likesCount: 2340,
      },
      createdAt: new Date().toISOString(),
      likes: 0,
      isLiked: false,
      noteId: data.noteId,
      parentId: data.parentId,
    };
  }
}
