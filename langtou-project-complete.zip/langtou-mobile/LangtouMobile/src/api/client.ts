import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios';
import { API_BASE_URL, STORAGE_KEYS } from '../constants/config';
import { Storage } from '../utils/storage';
import type { ApiResponse } from '../types';

// 后端业务错误码映射
const BUSINESS_ERROR_MESSAGES: Record<number, string> = {
  // 通用错误 (400-499)
  400: '参数错误，请检查输入',
  401: '未授权，请先登录',
  403: '禁止访问该资源',
  404: '请求的资源不存在',
  405: '请求方式不支持',
  429: '请求过于频繁，请稍后再试',

  // 用户模块 (1001-1999)
  1001: '用户不存在',
  1002: '用户名或密码错误',
  1003: '用户已存在',
  1004: '用户未登录',
  1005: 'Token无效或已过期',
  1006: 'Token已过期',

  // 内容模块 (2001-2999)
  2001: '内容不存在',
  2002: '内容发布失败',

  // 互动模块 (3001-3999)
  3001: '操作失败',
  3002: '已经点赞过了',
  3003: '还未点赞',
  3004: '已经收藏过了',
  3005: '还未收藏',
  3006: '不能收藏自己的笔记',

  // 消息模块 (4001-4999)
  4001: '消息发送失败',

  // 通知模块 (5001-5999)
  5001: '通知不存在',
  5002: '已经关注过了',
  5003: '还未关注',
  5004: '不能关注自己',
  5005: '取消关注失败',

  // 文件模块 (6001-6999)
  6001: '文件上传失败',
  6002: '不支持的文件类型',
};

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// 是否正在刷新Token
let isRefreshing = false;
// 等待Token刷新的请求队列
let refreshSubscribers: Array<(token: string) => void> = [];

function onRefreshed(token: string) {
  refreshSubscribers.forEach((cb) => cb(token));
  refreshSubscribers = [];
}

function addRefreshSubscriber(callback: (token: string) => void) {
  refreshSubscribers.push(callback);
}

// 请求拦截器：自动附加JWT Token
apiClient.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = Storage.get(STORAGE_KEYS.AUTH_TOKEN);
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error: AxiosError) => {
    return Promise.reject(error);
  }
);

// 响应拦截器：统一解包 Result<T> 格式 + 错误处理 + Token刷新
apiClient.interceptors.response.use(
  (response) => {
    const resData = response.data;

    // 后端返回 Result<T> 格式：{ code, message, data, timestamp }
    if (resData && typeof resData === 'object' && 'code' in resData) {
      if (resData.code === 200) {
        // 成功：解包返回 data 字段
        return resData.data;
      } else {
        // 业务错误：code !== 200，使用错误码映射获取友好提示
        const code = resData.code as number;
        const errorMessage = BUSINESS_ERROR_MESSAGES[code] || resData.message || `请求失败 (${code})`;
        console.error(`[API] 业务错误 (code=${code}):`, errorMessage);
        return Promise.reject(new Error(errorMessage));
      }
    }

    // 非标准格式，直接返回
    return resData;
  },
  async (error: AxiosError<ApiResponse>) => {
    if (!error.response) {
      // 网络错误或请求未发出
      console.error('[API] 网络错误:', error.message);
      return Promise.reject(new Error('网络连接失败，请检查网络设置'));
    }

    const { status, data, config } = error.response;
    const originalRequest = config as InternalAxiosRequestConfig & { _retry?: boolean };

    switch (status) {
      case 401: {
        // Token 过期或无效，尝试刷新
        if (originalRequest._retry) {
          // 已经重试过，不再重试
          clearAuthAndRedirect();
          break;
        }

        // 如果正在刷新Token，将请求加入队列
        if (isRefreshing) {
          return new Promise((resolve) => {
            addRefreshSubscriber((newToken: string) => {
              originalRequest.headers.Authorization = `Bearer ${newToken}`;
              resolve(apiClient(originalRequest));
            });
          });
        }

        originalRequest._retry = true;
        isRefreshing = true;

        try {
          // 使用当前Token尝试刷新
          const currentToken = Storage.get(STORAGE_KEYS.AUTH_TOKEN);
          if (!currentToken) {
            clearAuthAndRedirect();
            break;
          }

          const response = await axios.post(
            `${API_BASE_URL}/auth/refresh`,
            {},
            {
              headers: {
                Authorization: `Bearer ${currentToken}`,
                'Content-Type': 'application/json',
              },
            }
          );

          const resData = response.data;
          if (resData && resData.code === 200 && resData.data) {
            const newToken = resData.data.token;
            Storage.set(STORAGE_KEYS.AUTH_TOKEN, newToken);
            isRefreshing = false;
            onRefreshed(newToken);

            // 重试原请求
            originalRequest.headers.Authorization = `Bearer ${newToken}`;
            return apiClient(originalRequest);
          } else {
            // 刷新失败
            isRefreshing = false;
            clearAuthAndRedirect();
          }
        } catch (refreshError) {
          isRefreshing = false;
          refreshSubscribers = [];
          clearAuthAndRedirect();
        }
        break;
      }
      case 403:
        return Promise.reject(new Error(BUSINESS_ERROR_MESSAGES[403] || '没有权限访问该资源'));
      case 404:
        return Promise.reject(new Error(BUSINESS_ERROR_MESSAGES[404] || '请求的资源不存在'));
      case 429:
        return Promise.reject(new Error(BUSINESS_ERROR_MESSAGES[429] || '请求过于频繁，请稍后再试'));
      case 500:
        return Promise.reject(new Error('服务器内部错误，请稍后重试'));
      default:
        console.error(`[API] 请求错误 (${status}):`, data?.message);
    }

    const errorMessage = data?.message || `请求失败 (${status})`;
    return Promise.reject(new Error(errorMessage));
  }
);

function clearAuthAndRedirect() {
  Storage.remove(STORAGE_KEYS.AUTH_TOKEN);
  Storage.remove(STORAGE_KEYS.REFRESH_TOKEN);
  Storage.remove(STORAGE_KEYS.USER_INFO);
  console.warn('[API] Token 已过期，请重新登录');
  // 注意：React Native 中跳转登录页需要通过 navigation 或事件总线
  // 这里通过一个全局事件通知
  try {
    const { EventEmitter } = require('events');
    const emitter = new EventEmitter();
    emitter.emit('AUTH_EXPIRED');
  } catch {
    // 静默处理
  }
}

export default apiClient;
