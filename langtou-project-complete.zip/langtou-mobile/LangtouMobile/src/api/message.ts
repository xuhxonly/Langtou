import apiClient from './client';
import type {
  Conversation,
  Message,
  Notification,
  UnreadCount,
  PaginatedResult,
  SendMessageRequest,
} from '../types';
import { MESSAGES, NOTIFICATIONS } from '../constants/api';
import { mockUsers, generateMockNotifications } from '../utils/mockData';

// ============ 会话列表 ============

export async function getConversations(): Promise<Conversation[]> {
  try {
    return await apiClient.get<Conversation[]>(MESSAGES.CONVERSATIONS);
  } catch {
    // Mock fallback
    console.warn('[MessageAPI] getConversations fallback to mock');
    return [
      {
        id: 'conv1',
        userId: mockUsers[0].id,
        user: mockUsers[0],
        lastMessage: '你好呀！',
        lastMessageTime: new Date(Date.now() - 5 * 60000).toISOString(),
        unreadCount: 2,
        updatedAt: new Date(Date.now() - 5 * 60000).toISOString(),
      },
      {
        id: 'conv2',
        userId: mockUsers[1].id,
        user: mockUsers[1],
        lastMessage: '那个餐厅在哪里？',
        lastMessageTime: new Date(Date.now() - 2 * 3600000).toISOString(),
        unreadCount: 0,
        updatedAt: new Date(Date.now() - 2 * 3600000).toISOString(),
      },
    ];
  }
}

// ============ 聊天记录 ============

export async function getMessages(
  userId: string,
  page: number = 1,
  pageSize: number = 20
): Promise<PaginatedResult<Message>> {
  try {
    const data = await apiClient.get<{ list: Message[]; total: number; current: number; size: number; pages: number }>(
      MESSAGES.CONVERSATION(userId),
      { params: { current: page, size: pageSize } }
    );
    return {
      list: data.list,
      total: data.total,
      page: data.current,
      pageSize: data.size,
      hasMore: data.current < data.pages,
    };
  } catch {
    // Mock fallback
    console.warn('[MessageAPI] getMessages fallback to mock');
    const mockMessages: Message[] = [
      {
        id: 'msg1',
        conversationId: 'conv1',
        senderId: mockUsers[0].id,
        content: '你好呀！',
        type: 'text',
        createdAt: new Date(Date.now() - 10 * 60000).toISOString(),
        isRead: true,
      },
      {
        id: 'msg2',
        conversationId: 'conv1',
        senderId: 'current_user',
        content: '你好！看到你的笔记了，拍得真好',
        type: 'text',
        createdAt: new Date(Date.now() - 8 * 60000).toISOString(),
        isRead: true,
      },
      {
        id: 'msg3',
        conversationId: 'conv1',
        senderId: mockUsers[0].id,
        content: '谢谢！下次一起去拍',
        type: 'text',
        createdAt: new Date(Date.now() - 5 * 60000).toISOString(),
        isRead: false,
      },
    ];
    return {
      list: mockMessages,
      total: 3,
      page,
      pageSize,
      hasMore: false,
    };
  }
}

// ============ 发送消息 ============

export async function sendMessage(data: SendMessageRequest): Promise<Message> {
  try {
    return await apiClient.post<Message>(MESSAGES.SEND, data);
  } catch {
    // Mock fallback
    console.warn('[MessageAPI] sendMessage fallback to mock');
    return {
      id: `msg_${Date.now()}`,
      conversationId: 'conv_new',
      senderId: 'current_user',
      content: data.content,
      type: (data.messageType === 2 ? 'image' : 'text'),
      createdAt: new Date().toISOString(),
      isRead: false,
    };
  }
}

// ============ 通知列表 ============

export async function getNotifications(
  page: number = 1,
  pageSize: number = 20,
  type?: string
): Promise<PaginatedResult<Notification>> {
  try {
    const params: Record<string, any> = { current: page, size: pageSize };
    if (type) {
      params.type = type;
    }
    const data = await apiClient.get<{ list: Notification[]; total: number; current: number; size: number; pages: number }>(
      NOTIFICATIONS.LIST,
      { params }
    );
    return {
      list: data.list,
      total: data.total,
      page: data.current,
      pageSize: data.size,
      hasMore: data.current < data.pages,
    };
  } catch {
    // Mock fallback
    console.warn('[MessageAPI] getNotifications fallback to mock');
    const notifications = generateMockNotifications();
    return {
      list: notifications,
      total: notifications.length,
      page,
      pageSize,
      hasMore: false,
    };
  }
}

// ============ 未读数 ============

export async function getUnreadCount(): Promise<UnreadCount> {
  try {
    const count = await apiClient.get<number>(NOTIFICATIONS.UNREAD_COUNT);
    return {
      total: count,
      likes: 0,
      comments: 0,
      follows: 0,
      system: 0,
    };
  } catch {
    // Mock fallback
    console.warn('[MessageAPI] getUnreadCount fallback to mock');
    return {
      total: 5,
      likes: 2,
      comments: 1,
      follows: 1,
      system: 1,
    };
  }
}

// ============ 标记会话已读 ============

export async function markConversationRead(userId: string): Promise<boolean> {
  try {
    await apiClient.put(MESSAGES.MARK_READ(userId));
    return true;
  } catch {
    console.warn('[MessageAPI] markConversationRead fallback to mock');
    return true;
  }
}

// ============ 全部已读 ============

export async function markAllRead(): Promise<boolean> {
  try {
    await apiClient.put(NOTIFICATIONS.READ_ALL);
    return true;
  } catch {
    console.warn('[MessageAPI] markAllRead fallback to mock');
    return true;
  }
}
