import apiClient from './client';
import type {
  User,
  UserProfile,
  LoginRequest,
  UsernamePasswordLoginRequest,
  RegisterRequest,
  LoginResponse,
  PaginatedResult,
} from '../types';
import { AUTH, USERS, SEARCH } from '../constants/api';
import { generateMockUser, mockUsers } from '../utils/mockData';

// ============ 发送短信验证码 ============

export async function sendSmsCode(phone: string): Promise<boolean> {
  try {
    await apiClient.post(AUTH.SEND_SMS, { phone });
    return true;
  } catch {
    // Mock fallback
    console.warn('[UserAPI] sendSmsCode fallback to mock');
    return true;
  }
}

// ============ 登录注册 ============

/**
 * 手机号验证码登录
 * 拦截器已解包 Result<T>，直接返回 data 内容
 */
export async function smsLogin(phone: string, code: string): Promise<LoginResponse> {
  try {
    const data = await apiClient.post<{ token: string; tokenType: string }>(
      AUTH.SMS_LOGIN,
      { phone, code } as LoginRequest
    );
    // 后端 sms-login 只返回 token，需额外获取用户信息
    const token = data.token;
    let user = generateMockUser();
    try {
      user = await apiClient.get<User>(USERS.ME);
    } catch {
      // 获取用户信息失败，使用默认值
    }
    return { token, refreshToken: '', user };
  } catch {
    // Mock fallback
    console.warn('[UserAPI] smsLogin fallback to mock');
    const user = generateMockUser();
    return { token: 'mock_token_' + Date.now(), refreshToken: 'mock_refresh', user };
  }
}

/**
 * 用户名密码登录
 */
export async function login(username: string, password: string): Promise<LoginResponse> {
  try {
    const data = await apiClient.post<{ token: string; tokenType: string }>(
      AUTH.LOGIN,
      { username, password } as UsernamePasswordLoginRequest
    );
    const token = data.token;
    let user = generateMockUser();
    try {
      user = await apiClient.get<User>(USERS.ME);
    } catch {
      // 获取用户信息失败，使用默认值
    }
    return { token, refreshToken: '', user };
  } catch {
    // Mock fallback
    console.warn('[UserAPI] login fallback to mock');
    const user = generateMockUser();
    return { token: 'mock_token_' + Date.now(), refreshToken: 'mock_refresh', user };
  }
}

/**
 * 刷新Token
 */
export async function refreshToken(): Promise<{ token: string }> {
  const data = await apiClient.post<{ token: string; tokenType: string }>(AUTH.REFRESH);
  return { token: data.token };
}

export async function register(data: RegisterRequest): Promise<LoginResponse> {
  try {
    const user = await apiClient.post<User>(AUTH.REGISTER, data);
    return { token: 'mock_token_' + Date.now(), refreshToken: 'mock_refresh', user };
  } catch {
    // Mock fallback
    console.warn('[UserAPI] register fallback to mock');
    const user = generateMockUser();
    user.nickname = data.nickname || data.username;
    return { token: 'mock_token_' + Date.now(), refreshToken: 'mock_refresh', user };
  }
}

// ============ 用户资料 ============

export async function getUserProfile(userId: string): Promise<UserProfile> {
  try {
    return await apiClient.get<UserProfile>(USERS.DETAIL(userId));
  } catch {
    // Mock fallback
    console.warn('[UserAPI] getUserProfile fallback to mock');
    const mockUser = mockUsers.find((u) => u.id === userId) || generateMockUser();
    return {
      ...mockUser,
      gender: '未设置',
      location: '未设置',
      createdAt: new Date().toISOString(),
    } as UserProfile;
  }
}

export async function getCurrentUser(): Promise<UserProfile> {
  try {
    return await apiClient.get<UserProfile>(USERS.ME);
  } catch {
    console.warn('[UserAPI] getCurrentUser fallback to mock');
    const user = generateMockUser();
    return {
      ...user,
      gender: '未设置',
      location: '未设置',
      createdAt: new Date().toISOString(),
    } as UserProfile;
  }
}

export async function updateUserProfile(data: Partial<UserProfile>): Promise<User> {
  try {
    return await apiClient.put<User>(USERS.ME_PROFILE, data);
  } catch {
    // Mock fallback
    console.warn('[UserAPI] updateUserProfile fallback to mock');
    return generateMockUser();
  }
}

export async function updateAvatar(avatarUrl: string): Promise<string> {
  try {
    const data = await apiClient.post<{ avatarUrl: string }>(USERS.ME_AVATAR, { avatarUrl });
    return data.avatarUrl;
  } catch {
    // Mock fallback
    console.warn('[UserAPI] updateAvatar fallback to mock');
    return avatarUrl;
  }
}

// ============ 关注系统 ============

export async function follow(userId: string): Promise<boolean> {
  try {
    await apiClient.post(USERS.FOLLOW(userId));
    return true;
  } catch {
    console.warn('[UserAPI] follow fallback to mock');
    return true;
  }
}

export async function unfollow(userId: string): Promise<boolean> {
  try {
    await apiClient.delete(USERS.FOLLOW(userId));
    return true;
  } catch {
    console.warn('[UserAPI] unfollow fallback to mock');
    return true;
  }
}

export async function getFollowers(
  userId: string,
  page: number = 1,
  pageSize: number = 20
): Promise<PaginatedResult<User>> {
  try {
    const data = await apiClient.get<{ total: number; page: number; size: number; records: User[] }>(
      USERS.FOLLOWERS(userId),
      { params: { page, size: pageSize } }
    );
    return {
      list: data.records,
      total: data.total,
      page: data.page,
      pageSize: data.size,
      hasMore: data.page * data.size < data.total,
    };
  } catch {
    console.warn('[UserAPI] getFollowers fallback to mock');
    return {
      list: mockUsers.slice(0, pageSize),
      total: mockUsers.length,
      page,
      pageSize,
      hasMore: page < 2,
    };
  }
}

export async function getFollowing(
  userId: string,
  page: number = 1,
  pageSize: number = 20
): Promise<PaginatedResult<User>> {
  try {
    const data = await apiClient.get<{ total: number; page: number; size: number; records: User[] }>(
      USERS.FOLLOWING(userId),
      { params: { page, size: pageSize } }
    );
    return {
      list: data.records,
      total: data.total,
      page: data.page,
      pageSize: data.size,
      hasMore: data.page * data.size < data.total,
    };
  } catch {
    console.warn('[UserAPI] getFollowing fallback to mock');
    return {
      list: mockUsers.slice(0, Math.min(3, pageSize)),
      total: 3,
      page,
      pageSize,
      hasMore: false,
    };
  }
}

// ============ 搜索用户 ============

export async function searchUsers(keyword: string): Promise<User[]> {
  try {
    return await apiClient.get<User[]>(SEARCH.UNIFIED, { params: { keyword, type: 'user' } });
  } catch {
    console.warn('[UserAPI] searchUsers fallback to mock');
    return mockUsers.filter(
      (u) =>
        u.nickname.includes(keyword) ||
        u.username.includes(keyword)
    );
  }
}
