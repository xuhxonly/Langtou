/**
 * WebSocket 连接管理
 * 支持自动重连、心跳检测、连接状态管理
 * 后端端点: /ws/chat (聊天), /ws/notification (通知)
 */

import { Platform } from 'react-native';
import { STORAGE_KEYS, API_BASE_URL } from '../constants/config';
import { Storage } from '../utils/storage';

// WebSocket 连接状态
export enum WSConnectionState {
  CONNECTING = 'connecting',
  CONNECTED = 'connected',
  DISCONNECTED = 'disconnected',
  RECONNECTING = 'reconnecting',
}

// WebSocket 消息类型
export enum WSMessageType {
  // 聊天消息
  CHAT_MESSAGE = 'chat_message',
  // 正在输入
  TYPING = 'typing',
  // 新通知
  NOTIFICATION = 'notification',
  // 在线状态
  ONLINE_STATUS = 'online_status',
  // 心跳
  HEARTBEAT = 'heartbeat',
  HEARTBEAT_ACK = 'heartbeat_ack',
}

// WebSocket 消息格式
export interface WSMessage<T = any> {
  type: WSMessageType;
  data: T;
  timestamp: number;
}

// WebSocket 端点类型
export type WSEndpointType = 'chat' | 'notification';

// 监听器类型
type MessageListener = (message: WSMessage) => void;
type StateListener = (state: WSConnectionState) => void;

class WebSocketManager {
  private ws: WebSocket | null = null;
  private url: string = '';
  private endpointType: WSEndpointType = 'chat';
  private state: WSConnectionState = WSConnectionState.DISCONNECTED;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private heartbeatTimer: ReturnType<typeof setInterval> | null = null;
  private reconnectAttempts: number = 0;
  private maxReconnectAttempts: number = 5;
  private reconnectInterval: number = 3000; // 初始重连间隔 3秒
  private maxReconnectInterval: number = 30000; // 最大重连间隔 30秒
  private heartbeatInterval: number = 30000; // 心跳间隔 30秒
  private heartbeatTimeout: number = 10000; // 心跳超时 10秒
  private messageListeners: Map<string, MessageListener[]> = new Map();
  private stateListeners: Set<StateListener> = new Set();
  private isManualClose: boolean = false;

  /**
   * 初始化 WebSocket 连接
   * @param token JWT Token
   * @param endpointType 端点类型: 'chat' 或 'notification'
   */
  connect(token: string, endpointType: WSEndpointType = 'chat'): void {
    if (this.ws && (this.state === WSConnectionState.CONNECTED || this.state === WSConnectionState.CONNECTING)) {
      console.warn('[WebSocket] 已存在连接');
      return;
    }

    this.isManualClose = false;
    this.endpointType = endpointType;
    this.setState(WSConnectionState.CONNECTING);

    // 构建 WebSocket URL
    // 后端端点: /ws/chat 和 /ws/notification
    // 从 API_BASE_URL (https://api.langtou.app/api/v1) 提取基础域名
    const apiBase = API_BASE_URL.replace(/\/api\/v1$/, '');
    const wsBase = apiBase.replace(/^https/, 'wss');
    const wsPath = endpointType === 'chat' ? '/ws/chat' : '/ws/notification';
    this.url = `${wsBase}${wsPath}?token=${encodeURIComponent(token)}`;

    try {
      this.ws = new WebSocket(this.url);

      this.ws.onopen = () => {
        console.log('[WebSocket] 连接成功');
        this.setState(WSConnectionState.CONNECTED);
        this.reconnectAttempts = 0;
        this.startHeartbeat();
      };

      this.ws.onmessage = (event) => {
        try {
          const message: WSMessage = JSON.parse(event.data as string);
          this.handleMessage(message);
        } catch (e) {
          console.error('[WebSocket] 消息解析失败:', e);
        }
      };

      this.ws.onclose = (event) => {
        console.log(`[WebSocket] 连接关闭: code=${event.code}, reason=${event.reason}`);
        this.stopHeartbeat();
        this.setState(WSConnectionState.DISCONNECTED);

        if (!this.isManualClose) {
          this.scheduleReconnect();
        }
      };

      this.ws.onerror = (error) => {
        console.error('[WebSocket] 连接错误:', error);
        this.setState(WSConnectionState.DISCONNECTED);
      };
    } catch (error) {
      console.error('[WebSocket] 创建连接失败:', error);
      this.setState(WSConnectionState.DISCONNECTED);
      this.scheduleReconnect();
    }
  }

  /**
   * 断开连接
   */
  disconnect(): void {
    this.isManualClose = true;
    this.stopHeartbeat();
    this.clearReconnectTimer();

    if (this.ws) {
      try {
        this.ws.close(1000, '用户主动断开');
      } catch {
        // 忽略关闭错误
      }
      this.ws = null;
    }

    this.setState(WSConnectionState.DISCONNECTED);
    this.reconnectAttempts = 0;
  }

  /**
   * 发送消息
   */
  send(message: WSMessage): boolean {
    if (!this.ws || this.state !== WSConnectionState.CONNECTED) {
      console.warn('[WebSocket] 未连接，无法发送消息');
      return false;
    }

    try {
      this.ws.send(JSON.stringify(message));
      return true;
    } catch (error) {
      console.error('[WebSocket] 发送消息失败:', error);
      return false;
    }
  }

  /**
   * 发送聊天消息
   */
  sendChatMessage(conversationId: string, content: string, type: string = 'text'): boolean {
    return this.send({
      type: WSMessageType.CHAT_MESSAGE,
      data: { conversationId, content, type },
      timestamp: Date.now(),
    });
  }

  /**
   * 发送正在输入状态
   */
  sendTyping(conversationId: string): boolean {
    return this.send({
      type: WSMessageType.TYPING,
      data: { conversationId },
      timestamp: Date.now(),
    });
  }

  /**
   * 注册消息监听器
   */
  onMessage(type: WSMessageType | string, listener: MessageListener): () => void {
    const key = type;
    if (!this.messageListeners.has(key)) {
      this.messageListeners.set(key, []);
    }
    this.messageListeners.get(key)!.push(listener);

    // 返回取消监听函数
    return () => {
      const listeners = this.messageListeners.get(key);
      if (listeners) {
        const index = listeners.indexOf(listener);
        if (index > -1) {
          listeners.splice(index, 1);
        }
      }
    };
  }

  /**
   * 注册连接状态监听器
   */
  onStateChange(listener: StateListener): () => void {
    this.stateListeners.add(listener);
    // 立即触发当前状态
    listener(this.state);

    // 返回取消监听函数
    return () => {
      this.stateListeners.delete(listener);
    };
  }

  /**
   * 获取当前连接状态
   */
  getState(): WSConnectionState {
    return this.state;
  }

  /**
   * 处理收到的消息
   */
  private handleMessage(message: WSMessage): void {
    // 心跳响应
    if (message.type === WSMessageType.HEARTBEAT_ACK) {
      return;
    }

    // 通知所有该类型的监听器
    const listeners = this.messageListeners.get(message.type);
    if (listeners) {
      listeners.forEach((listener) => {
        try {
          listener(message);
        } catch (e) {
          console.error(`[WebSocket] 消息处理错误 (type=${message.type}):`, e);
        }
      });
    }

    // 通知通配符监听器
    const allListeners = this.messageListeners.get('*');
    if (allListeners) {
      allListeners.forEach((listener) => {
        try {
          listener(message);
        } catch (e) {
          console.error('[WebSocket] 通配符消息处理错误:', e);
        }
      });
    }
  }

  /**
   * 设置连接状态
   */
  private setState(state: WSConnectionState): void {
    this.state = state;
    this.stateListeners.forEach((listener) => {
      try {
        listener(state);
      } catch {
        // 忽略监听器错误
      }
    });
  }

  /**
   * 启动心跳
   */
  private startHeartbeat(): void {
    this.stopHeartbeat();
    this.heartbeatTimer = setInterval(() => {
      this.send({
        type: WSMessageType.HEARTBEAT,
        data: {},
        timestamp: Date.now(),
      });
    }, this.heartbeatInterval);
  }

  /**
   * 停止心跳
   */
  private stopHeartbeat(): void {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
  }

  /**
   * 安排重连
   */
  private scheduleReconnect(): void {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.warn('[WebSocket] 已达到最大重连次数，停止重连');
      return;
    }

    this.clearReconnectTimer();
    this.reconnectAttempts++;

    // 指数退避重连
    const delay = Math.min(
      this.reconnectInterval * Math.pow(1.5, this.reconnectAttempts - 1),
      this.maxReconnectInterval
    );

    console.log(`[WebSocket] ${delay}ms 后进行第 ${this.reconnectAttempts} 次重连`);
    this.setState(WSConnectionState.RECONNECTING);

    this.reconnectTimer = setTimeout(() => {
      const token = Storage.get(STORAGE_KEYS.AUTH_TOKEN);
      if (token) {
        this.connect(token, this.endpointType);
      } else {
        console.warn('[WebSocket] 无Token，无法重连');
      }
    }, delay);
  }

  /**
   * 清除重连定时器
   */
  private clearReconnectTimer(): void {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
  }
}

// 单例导出
export const wsManager = new WebSocketManager();
export default wsManager;
