import type { Note } from '../types';
import { getFeed, getNoteDetail, getUserNotes, searchNotes, getFollowingFeed } from './content';
import { like as likeApi, unlike as unlikeApi, collect as collectApi, uncollect as uncollectApi } from './interact';

// 兼容旧接口，内部委托到新的 content/interact API
export async function fetchNotes(page: number = 1, pageSize: number = 10): Promise<Note[]> {
  const result = await getFeed(page, pageSize);
  return result.list;
}

export async function fetchFollowingNotes(page: number = 1, pageSize: number = 10): Promise<Note[]> {
  const result = await getFollowingFeed(page, pageSize);
  return result.list;
}

export async function fetchNoteById(id: string): Promise<Note | null> {
  try {
    const detail = await getNoteDetail(id);
    return detail;
  } catch {
    return null;
  }
}

export async function likeNote(noteId: string): Promise<boolean> {
  return likeApi(noteId);
}

export async function unlikeNote(noteId: string): Promise<boolean> {
  return unlikeApi(noteId);
}

export async function collectNote(noteId: string): Promise<boolean> {
  return collectApi(noteId);
}

export async function uncollectNote(noteId: string): Promise<boolean> {
  return uncollectApi(noteId);
}

// 导出新的 content API 供直接使用
export { getFeed, getNoteDetail, getUserNotes, searchNotes };
