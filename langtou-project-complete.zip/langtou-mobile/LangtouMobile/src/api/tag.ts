import apiClient from './client';
import type { Tag } from '../types';
import { TAGS } from '../constants/api';

/**
 * 获取热门标签
 */
export async function getHotTags(): Promise<Tag[]> {
  try {
    return await apiClient.get<Tag[]>(TAGS.HOT);
  } catch {
    console.warn('[TagAPI] getHotTags fallback to mock');
    return [
      { id: 't1', name: '夏日穿搭', count: 12500, isHot: true },
      { id: 't2', name: '减脂餐', count: 8900, isHot: true },
      { id: 't3', name: '杭州旅游', count: 6700, isHot: true },
      { id: 't4', name: '口红试色', count: 5400, isHot: true },
      { id: 't5', name: '独居生活', count: 4300, isHot: true },
      { id: 't6', name: '手机摄影', count: 3200, isHot: false },
      { id: 't7', name: '租房改造', count: 2800, isHot: false },
      { id: 't8', name: '书单推荐', count: 2100, isHot: false },
      { id: 't9', name: '周末brunch', count: 1800, isHot: false },
      { id: 't10', name: '咖啡探店', count: 1500, isHot: false },
    ];
  }
}
