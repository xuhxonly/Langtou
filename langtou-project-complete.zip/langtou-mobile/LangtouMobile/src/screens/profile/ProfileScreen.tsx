import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  RefreshControl,
  ActivityIndicator,
  Alert,
} from 'react-native';
import FastImage from 'react-native-fast-image';
import { useTheme } from '../../hooks/useTheme';
import { useAuthStore } from '../../store/useAuthStore';
import { useCurrentUserProfile, useUserNotes } from '../../hooks/useUser';
import { formatNumber } from '../../utils/format';
import { NoteCard } from '../../components/common/NoteCard';
import type { Note } from '../../types';

interface ProfileScreenProps {
  navigation?: any;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({ navigation }) => {
  const { colors } = useTheme();
  const { isAuthenticated, user, logout } = useAuthStore();
  const [notesPage, setNotesPage] = useState(1);
  const [allNotes, setAllNotes] = useState<Note[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const {
    data: profileData,
    isLoading: profileLoading,
    refetch: refetchProfile,
  } = useCurrentUserProfile();
  const {
    data: notesData,
    isLoading: notesLoading,
    refetch: refetchNotes,
  } = useUserNotes(user?.id || 'current_user', notesPage);

  // 合并本地user和API profile数据
  const currentUser = profileData || user;

  React.useEffect(() => {
    if (notesData) {
      setAllNotes((prev) =>
        notesPage === 1 ? notesData.list : [...prev, ...notesData.list]
      );
    }
  }, [notesData, notesPage]);

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    setNotesPage(1);
    setAllNotes([]);
    await Promise.all([refetchProfile(), refetchNotes()]);
    setIsRefreshing(false);
  }, [refetchProfile, refetchNotes]);

  const handleLoadMore = useCallback(() => {
    if (!notesLoading && notesData?.hasMore) {
      setNotesPage((prev) => prev + 1);
    }
  }, [notesLoading, notesData]);

  const handleLogin = useCallback(() => {
    navigation?.navigate('Login');
  }, [navigation]);

  const handleEditProfile = useCallback(() => {
    navigation?.navigate('EditProfile');
  }, [navigation]);

  const handleSettings = useCallback(() => {
    navigation?.navigate('Settings');
  }, [navigation]);

  const handleNotePress = useCallback(
    (note: Note) => {
      navigation?.navigate('NoteDetail', { noteId: note.id });
    },
    [navigation]
  );

  const handleLogout = useCallback(() => {
    Alert.alert('退出登录', '确定要退出登录吗？', [
      { text: '取消', style: 'cancel' },
      {
        text: '确定',
        style: 'destructive',
        onPress: logout,
      },
    ]);
  }, [logout]);

  if (!isAuthenticated) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.unauthenticatedContainer}>
          <View style={[styles.avatarPlaceholder, { backgroundColor: colors.surface }]}>
            <Text style={[styles.avatarPlaceholderText, { color: colors.textSecondary }]}>?</Text>
          </View>
          <Text style={[styles.unauthenticatedText, { color: colors.textSecondary }]}>
            登录后查看个人中心
          </Text>
          <TouchableOpacity
            style={[styles.loginButton, { backgroundColor: colors.primary }]}
            onPress={handleLogin}
          >
            <Text style={styles.loginButtonText}>立即登录</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary}
          />
        }
        onScroll={({ nativeEvent }) => {
          const { layoutMeasurement, contentOffset, contentSize } = nativeEvent;
          if (layoutMeasurement.height + contentOffset.y >= contentSize.height - 50) {
            handleLoadMore();
          }
        }}
        scrollEventThrottle={400}
      >
        {/* 用户信息头部 */}
        <View style={[styles.header, { backgroundColor: colors.surface }]}>
          {profileLoading ? (
            <View style={styles.profileLoading}>
              <ActivityIndicator size="small" color={colors.primary} />
            </View>
          ) : (
            <>
              <View style={styles.userInfo}>
                <FastImage
                  source={{ uri: currentUser?.avatar || '' }}
                  style={styles.avatar}
                />
                <View style={styles.userMeta}>
                  <Text style={[styles.nickname, { color: colors.text }]}>
                    {currentUser?.nickname || '榔头用户'}
                  </Text>
                  <Text style={[styles.username, { color: colors.textSecondary }]}>
                    @{currentUser?.username || 'langtou_user'}
                  </Text>
                  <Text style={[styles.bio, { color: colors.textSecondary }]} numberOfLines={2}>
                    {currentUser?.bio || '这个人很懒，什么都没写~'}
                  </Text>
                </View>
              </View>

              {/* 统计数据 */}
              <View style={styles.statsContainer}>
                <View style={styles.statItem}>
                  <Text style={[styles.statNumber, { color: colors.text }]}>
                    {formatNumber(currentUser?.notesCount || allNotes.length)}
                  </Text>
                  <Text style={[styles.statLabel, { color: colors.textSecondary }]}>笔记</Text>
                </View>
                <TouchableOpacity
                  style={styles.statItem}
                  onPress={() => navigation?.navigate('FollowerList', { userId: user?.id || 'current_user' })}
                >
                  <Text style={[styles.statNumber, { color: colors.text }]}>
                    {formatNumber(currentUser?.followersCount || 0)}
                  </Text>
                  <Text style={[styles.statLabel, { color: colors.textSecondary }]}>粉丝</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.statItem}
                  onPress={() => navigation?.navigate('FollowingList', { userId: user?.id || 'current_user' })}
                >
                  <Text style={[styles.statNumber, { color: colors.text }]}>
                    {formatNumber(currentUser?.followingCount || 0)}
                  </Text>
                  <Text style={[styles.statLabel, { color: colors.textSecondary }]}>关注</Text>
                </TouchableOpacity>
                <View style={styles.statItem}>
                  <Text style={[styles.statNumber, { color: colors.text }]}>
                    {formatNumber(currentUser?.likesCount || 0)}
                  </Text>
                  <Text style={[styles.statLabel, { color: colors.textSecondary }]}>获赞</Text>
                </View>
              </View>

              {/* 操作按钮 */}
              <View style={styles.actionButtons}>
                <TouchableOpacity
                  style={[styles.editButton, { borderColor: colors.border }]}
                  onPress={handleEditProfile}
                >
                  <Text style={[styles.editButtonText, { color: colors.text }]}>编辑资料</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.settingsButton, { borderColor: colors.border }]}
                  onPress={handleSettings}
                >
                  <Text style={[styles.settingsButtonText, { color: colors.text }]}>设置</Text>
                </TouchableOpacity>
              </View>
            </>
          )}
        </View>

        {/* 功能入口 */}
        <View style={[styles.functionGrid, { backgroundColor: colors.surface }]}>
          <TouchableOpacity style={styles.functionItem} onPress={() => {
            // 滚动到我的笔记区域
          }}>
            <View style={[styles.functionIcon, { backgroundColor: '#FFF0F2' }]}>
              <Text style={styles.functionIconText}>📝</Text>
            </View>
            <Text style={[styles.functionLabel, { color: colors.text }]}>我的笔记</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.functionItem}
            onPress={() => navigation?.navigate('CollectionList')}
          >
            <View style={[styles.functionIcon, { backgroundColor: '#FFF7E6' }]}>
              <Text style={styles.functionIconText}>⭐</Text>
            </View>
            <Text style={[styles.functionLabel, { color: colors.text }]}>我的收藏</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.functionItem}>
            <View style={[styles.functionIcon, { backgroundColor: '#F0F5FF' }]}>
              <Text style={styles.functionIconText}>❤️</Text>
            </View>
            <Text style={[styles.functionLabel, { color: colors.text }]}>我的点赞</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.functionItem}>
            <View style={[styles.functionIcon, { backgroundColor: '#F6FFED' }]}>
              <Text style={styles.functionIconText}>📄</Text>
            </View>
            <Text style={[styles.functionLabel, { color: colors.text }]}>草稿箱</Text>
          </TouchableOpacity>
        </View>

        {/* 我的笔记 */}
        <View style={styles.notesSection}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>我的笔记</Text>
          {allNotes.length > 0 ? (
            <View style={styles.notesGrid}>
              {allNotes.map((note) => (
                <NoteCard key={note.id} note={note} onPress={handleNotePress} />
              ))}
            </View>
          ) : (
            <View style={styles.emptyNotes}>
              <Text style={[styles.emptyNotesText, { color: colors.textSecondary }]}>
                还没有发布笔记，去发布第一篇吧~
              </Text>
              <TouchableOpacity
                style={[styles.publishNowButton, { backgroundColor: colors.primary }]}
                onPress={() => navigation?.navigate('Publish')}
              >
                <Text style={styles.publishNowButtonText}>去发布</Text>
              </TouchableOpacity>
            </View>
          )}
          {notesLoading && (
            <View style={styles.loadingMore}>
              <ActivityIndicator size="small" color={colors.primary} />
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  unauthenticatedContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
  },
  avatarPlaceholder: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  avatarPlaceholderText: {
    fontSize: 32,
  },
  unauthenticatedText: {
    fontSize: 16,
    marginBottom: 24,
  },
  loginButton: {
    paddingHorizontal: 48,
    paddingVertical: 12,
    borderRadius: 24,
  },
  loginButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  profileLoading: {
    paddingVertical: 40,
    alignItems: 'center',
  },
  header: {
    padding: 16,
    marginBottom: 8,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: 16,
  },
  userMeta: {
    flex: 1,
  },
  nickname: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  username: {
    fontSize: 14,
    marginBottom: 4,
  },
  bio: {
    fontSize: 13,
    lineHeight: 18,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 16,
  },
  statItem: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  statLabel: {
    fontSize: 13,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  editButton: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 16,
    borderWidth: 1,
    alignItems: 'center',
  },
  editButtonText: {
    fontSize: 14,
    fontWeight: '500',
  },
  settingsButton: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 16,
    borderWidth: 1,
    alignItems: 'center',
  },
  settingsButtonText: {
    fontSize: 14,
    fontWeight: '500',
  },
  functionGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: 16,
    marginBottom: 8,
  },
  functionItem: {
    width: '25%',
    alignItems: 'center',
    marginBottom: 8,
  },
  functionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  functionIconText: {
    fontSize: 22,
  },
  functionLabel: {
    fontSize: 13,
  },
  notesSection: {
    paddingHorizontal: 8,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
    paddingHorizontal: 8,
  },
  notesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  emptyNotes: {
    paddingVertical: 40,
    alignItems: 'center',
  },
  emptyNotesText: {
    fontSize: 14,
    marginBottom: 16,
  },
  publishNowButton: {
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderRadius: 20,
  },
  publishNowButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
  loadingMore: {
    paddingVertical: 16,
    alignItems: 'center',
  },
});
