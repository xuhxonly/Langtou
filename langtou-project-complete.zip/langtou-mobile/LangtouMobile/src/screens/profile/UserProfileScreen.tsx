import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  RefreshControl,
  ActivityIndicator,
  Alert,
} from 'react-native';
import FastImage from 'react-native-fast-image';
import { useTheme } from '../../hooks/useTheme';
import { useAuthStore } from '../../store/useAuthStore';
import {
  useUserProfile,
  useUserNotes,
  useFollowUser,
} from '../../hooks/useUser';
import { formatNumber } from '../../utils/format';
import { NoteCard } from '../../components/common/NoteCard';
import type { Note } from '../../types';

interface UserProfileScreenProps {
  route: { params: { userId: string } };
  navigation: any;
}

export const UserProfileScreen: React.FC<UserProfileScreenProps> = ({ route, navigation }) => {
  const { colors } = useTheme();
  const { isAuthenticated } = useAuthStore();
  const { userId } = route.params;
  const [notesPage, setNotesPage] = useState(1);
  const [allNotes, setAllNotes] = useState<Note[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const {
    data: profileData,
    isLoading: profileLoading,
    refetch: refetchProfile,
  } = useUserProfile(userId);
  const {
    data: notesData,
    isLoading: notesLoading,
    refetch: refetchNotes,
  } = useUserNotes(userId, notesPage);
  const followMutation = useFollowUser();

  React.useEffect(() => {
    if (notesData) {
      setAllNotes((prev) =>
        notesPage === 1 ? notesData.list : [...prev, ...notesData.list]
      );
    }
  }, [notesData, notesPage]);

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    setNotesPage(1);
    setAllNotes([]);
    await Promise.all([refetchProfile(), refetchNotes()]);
    setIsRefreshing(false);
  }, [refetchProfile, refetchNotes]);

  const handleLoadMore = useCallback(() => {
    if (!notesLoading && notesData?.hasMore) {
      setNotesPage((prev) => prev + 1);
    }
  }, [notesLoading, notesData]);

  const handleFollow = useCallback(() => {
    if (!isAuthenticated) {
      navigation.navigate('Login');
      return;
    }
    if (profileData) {
      followMutation.mutate({
        userId,
        isFollowing: profileData.isFollowing ?? false,
      });
    }
  }, [isAuthenticated, profileData, userId, followMutation, navigation]);

  const handleNotePress = useCallback(
    (note: Note) => {
      navigation.navigate('NoteDetail', { noteId: note.id });
    },
    [navigation]
  );

  if (profileLoading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  if (!profileData) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.errorContainer}>
          <Text style={[styles.errorText, { color: colors.textSecondary }]}>
            用户不存在或加载失败
          </Text>
          <TouchableOpacity
            style={[styles.retryButton, { backgroundColor: colors.primary }]}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.retryButtonText}>返回</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      {/* 顶部导航 */}
      <View style={[styles.header, { backgroundColor: colors.background }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Text style={[styles.backButtonText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.text }]}>用户主页</Text>
        <View style={styles.headerRight} />
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary}
          />
        }
        onScroll={({ nativeEvent }) => {
          const { layoutMeasurement, contentOffset, contentSize } = nativeEvent;
          if (layoutMeasurement.height + contentOffset.y >= contentSize.height - 50) {
            handleLoadMore();
          }
        }}
        scrollEventThrottle={400}
      >
        {/* 用户信息头部 */}
        <View style={[styles.profileHeader, { backgroundColor: colors.surface }]}>
          <View style={styles.userInfo}>
            <FastImage
              source={{ uri: profileData.avatar || '' }}
              style={styles.avatar}
            />
            <View style={styles.userMeta}>
              <Text style={[styles.nickname, { color: colors.text }]}>
                {profileData.nickname || '榔头用户'}
              </Text>
              <Text style={[styles.username, { color: colors.textSecondary }]}>
                @{profileData.username || 'langtou_user'}
              </Text>
              {profileData.bio ? (
                <Text style={[styles.bio, { color: colors.textSecondary }]} numberOfLines={3}>
                  {profileData.bio}
                </Text>
              ) : null}
              {profileData.location ? (
                <Text style={[styles.location, { color: colors.textSecondary }]}>
                  {profileData.location}
                </Text>
              ) : null}
            </View>
          </View>

          {/* 统计数据 */}
          <View style={styles.statsContainer}>
            <View style={styles.statItem}>
              <Text style={[styles.statNumber, { color: colors.text }]}>
                {formatNumber(profileData.notesCount ?? 0)}
              </Text>
              <Text style={[styles.statLabel, { color: colors.textSecondary }]}>笔记</Text>
            </View>
            <TouchableOpacity
              style={styles.statItem}
              onPress={() => navigation.navigate('FollowerList', { userId })}
            >
              <Text style={[styles.statNumber, { color: colors.text }]}>
                {formatNumber(profileData.followersCount ?? 0)}
              </Text>
              <Text style={[styles.statLabel, { color: colors.textSecondary }]}>粉丝</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.statItem}
              onPress={() => navigation.navigate('FollowingList', { userId })}
            >
              <Text style={[styles.statNumber, { color: colors.text }]}>
                {formatNumber(profileData.followingCount ?? 0)}
              </Text>
              <Text style={[styles.statLabel, { color: colors.textSecondary }]}>关注</Text>
            </TouchableOpacity>
            <View style={styles.statItem}>
              <Text style={[styles.statNumber, { color: colors.text }]}>
                {formatNumber(profileData.likesCount ?? 0)}
              </Text>
              <Text style={[styles.statLabel, { color: colors.textSecondary }]}>获赞</Text>
            </View>
          </View>

          {/* 关注按钮 */}
          <TouchableOpacity
            style={[
              styles.followButton,
              {
                backgroundColor: profileData.isFollowing
                  ? colors.surface
                  : colors.primary,
                borderColor: colors.border,
              },
            ]}
            onPress={handleFollow}
            disabled={followMutation.isPending}
          >
            {followMutation.isPending ? (
              <ActivityIndicator size="small" color={profileData.isFollowing ? colors.primary : '#FFFFFF'} />
            ) : (
              <Text
                style={[
                  styles.followButtonText,
                  { color: profileData.isFollowing ? colors.text : '#FFFFFF' },
                ]}
              >
                {profileData.isFollowing ? '已关注' : '+ 关注'}
              </Text>
            )}
          </TouchableOpacity>
        </View>

        {/* 用户笔记 */}
        <View style={styles.notesSection}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>TA的笔记</Text>
          {allNotes.length > 0 ? (
            <View style={styles.notesGrid}>
              {allNotes.map((note) => (
                <NoteCard key={note.id} note={note} onPress={handleNotePress} />
              ))}
            </View>
          ) : (
            <View style={styles.emptyNotes}>
              <Text style={[styles.emptyNotesText, { color: colors.textSecondary }]}>
                暂无笔记
              </Text>
            </View>
          )}
          {notesLoading && (
            <View style={styles.loadingMore}>
              <ActivityIndicator size="small" color={colors.primary} />
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
  },
  errorText: {
    fontSize: 16,
    marginBottom: 16,
  },
  retryButton: {
    paddingHorizontal: 32,
    paddingVertical: 10,
    borderRadius: 20,
  },
  retryButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#eee',
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
  },
  backButtonText: {
    fontSize: 24,
  },
  headerTitle: {
    fontSize: 17,
    fontWeight: '600',
  },
  headerRight: {
    width: 40,
  },
  profileHeader: {
    padding: 16,
    marginBottom: 8,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: 16,
  },
  userMeta: {
    flex: 1,
  },
  nickname: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  username: {
    fontSize: 14,
    marginBottom: 4,
  },
  bio: {
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 4,
  },
  location: {
    fontSize: 12,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 16,
  },
  statItem: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  statLabel: {
    fontSize: 13,
  },
  followButton: {
    paddingVertical: 10,
    borderRadius: 20,
    borderWidth: 1,
    alignItems: 'center',
  },
  followButtonText: {
    fontSize: 15,
    fontWeight: '600',
  },
  notesSection: {
    paddingHorizontal: 8,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
    paddingHorizontal: 8,
  },
  notesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  emptyNotes: {
    paddingVertical: 40,
    alignItems: 'center',
  },
  emptyNotesText: {
    fontSize: 14,
  },
  loadingMore: {
    paddingVertical: 16,
    alignItems: 'center',
  },
});
