import React, { useState, useCallback, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  ActivityIndicator,
  Alert,
  Image as RNImage,
} from 'react-native';
import FastImage from 'react-native-fast-image';
import { useTheme } from '../../hooks/useTheme';
import { useAuthStore } from '../../store/useAuthStore';
import { useCurrentUserProfile, useUpdateUserProfile, useUpdateAvatar } from '../../hooks/useUser';
import type { UserProfile } from '../../types';

interface EditProfileScreenProps {
  navigation?: any;
}

const GENDER_OPTIONS = [
  { label: '男', value: 'male' },
  { label: '女', value: 'female' },
  { label: '保密', value: 'secret' },
];

export const EditProfileScreen: React.FC<EditProfileScreenProps> = ({ navigation }) => {
  const { colors } = useTheme();
  const { user } = useAuthStore();
  const { data: profileData, isLoading: profileLoading } = useCurrentUserProfile();
  const updateProfileMutation = useUpdateUserProfile();
  const updateAvatarMutation = useUpdateAvatar();

  const [nickname, setNickname] = useState('');
  const [bio, setBio] = useState('');
  const [gender, setGender] = useState<string>('secret');
  const [birthday, setBirthday] = useState('');
  const [location, setLocation] = useState('');
  const [avatarUri, setAvatarUri] = useState('');

  // 初始化表单数据
  useEffect(() => {
    const profile = profileData || user;
    if (profile) {
      setNickname(profile.nickname || '');
      setBio(profile.bio || '');
      setGender((profile as UserProfile).gender || 'secret');
      setBirthday((profile as UserProfile).birthday || '');
      setLocation((profile as UserProfile).location || '');
      setAvatarUri(profile.avatar || '');
    }
  }, [profileData, user]);

  const handlePickAvatar = useCallback(() => {
    // 使用 React Native 的 ImagePicker 或自定义实现
    // 这里使用简单的 Alert 提示，实际项目中应接入 ImagePicker
    Alert.alert('更换头像', '选择头像来源', [
      {
        text: '拍照',
        onPress: () => {
          // 实际项目中接入相机
          Alert.alert('提示', '相机功能需要接入 ImagePicker');
        },
      },
      {
        text: '从相册选择',
        onPress: () => {
          // 实际项目中接入相册
          Alert.alert('提示', '相册功能需要接入 ImagePicker');
        },
      },
      { text: '取消', style: 'cancel' },
    ]);
  }, []);

  const handleGenderSelect = useCallback((value: string) => {
    setGender(value);
  }, []);

  const handleBirthdaySelect = useCallback(() => {
    Alert.alert('选择生日', '请输入生日日期 (YYYY-MM-DD)', [
      {
        text: '确定',
        onPress: (inputValue) => {
          // 简化处理，实际项目中应使用 DatePicker
          if (inputValue) {
            setBirthday(inputValue as unknown as string);
          }
        },
      },
      { text: '取消', style: 'cancel' },
    ]);
  }, []);

  const validate = useCallback((): boolean => {
    if (!nickname.trim()) {
      Alert.alert('提示', '请输入昵称');
      return false;
    }
    if (nickname.trim().length < 2 || nickname.trim().length > 20) {
      Alert.alert('提示', '昵称长度需要在2-20个字符之间');
      return false;
    }
    if (bio.length > 200) {
      Alert.alert('提示', '个人简介不能超过200个字符');
      return false;
    }
    return true;
  }, [nickname, bio]);

  const handleSave = useCallback(() => {
    if (!validate()) return;

    const profileDataToUpdate: Partial<UserProfile> = {
      nickname: nickname.trim(),
      bio: bio.trim(),
      gender,
      birthday: birthday || undefined,
      location: location.trim() || undefined,
    };

    updateProfileMutation.mutate(profileDataToUpdate, {
      onSuccess: () => {
        Alert.alert('成功', '资料更新成功', [
          {
            text: '确定',
            onPress: () => navigation?.goBack(),
          },
        ]);
      },
      onError: (error: any) => {
        Alert.alert('保存失败', error?.message || '请稍后重试');
      },
    });
  }, [validate, nickname, bio, gender, birthday, location, updateProfileMutation, navigation]);

  if (profileLoading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      {/* 顶部导航 */}
      <View style={[styles.header, { backgroundColor: colors.background }]}>
        <TouchableOpacity onPress={() => navigation?.goBack()} style={styles.backButton}>
          <Text style={[styles.backButtonText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.text }]}>编辑资料</Text>
        <TouchableOpacity
          onPress={handleSave}
          disabled={updateProfileMutation.isPending}
          style={styles.saveButton}
        >
          {updateProfileMutation.isPending ? (
            <ActivityIndicator size="small" color={colors.primary} />
          ) : (
            <Text style={[styles.saveButtonText, { color: colors.primary }]}>保存</Text>
          )}
        </TouchableOpacity>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.scrollContent}
        >
          {/* 头像 */}
          <TouchableOpacity style={styles.avatarSection} onPress={handlePickAvatar}>
            <FastImage
              source={{ uri: avatarUri || '' }}
              style={styles.avatar}
              fallback
            />
            <View style={styles.avatarEditOverlay}>
              <Text style={styles.avatarEditText}>更换</Text>
            </View>
          </TouchableOpacity>

          {/* 昵称 */}
          <View style={styles.formSection}>
            <Text style={[styles.formLabel, { color: colors.text }]}>昵称</Text>
            <TextInput
              style={[
                styles.formInput,
                {
                  backgroundColor: colors.surface,
                  color: colors.text,
                  borderColor: colors.border,
                },
              ]}
              placeholder="请输入昵称"
              placeholderTextColor={colors.textSecondary}
              value={nickname}
              onChangeText={setNickname}
              maxLength={20}
              clearButtonMode="while-editing"
            />
            <Text style={[styles.formHint, { color: colors.textSecondary }]}>
              {nickname.length}/20
            </Text>
          </View>

          {/* 性别 */}
          <View style={styles.formSection}>
            <Text style={[styles.formLabel, { color: colors.text }]}>性别</Text>
            <View style={styles.genderOptions}>
              {GENDER_OPTIONS.map((option) => (
                <TouchableOpacity
                  key={option.value}
                  style={[
                    styles.genderOption,
                    {
                      backgroundColor:
                        gender === option.value ? colors.primary : colors.surface,
                      borderColor: colors.border,
                    },
                  ]}
                  onPress={() => handleGenderSelect(option.value)}
                >
                  <Text
                    style={{
                      color: gender === option.value ? '#FFFFFF' : colors.text,
                      fontSize: 14,
                    }}
                  >
                    {option.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* 生日 */}
          <View style={styles.formSection}>
            <Text style={[styles.formLabel, { color: colors.text }]}>生日</Text>
            <TextInput
              style={[
                styles.formInput,
                {
                  backgroundColor: colors.surface,
                  color: colors.text,
                  borderColor: colors.border,
                },
              ]}
              placeholder="YYYY-MM-DD"
              placeholderTextColor={colors.textSecondary}
              value={birthday}
              onChangeText={setBirthday}
              maxLength={10}
            />
          </View>

          {/* 个人简介 */}
          <View style={styles.formSection}>
            <Text style={[styles.formLabel, { color: colors.text }]}>个人简介</Text>
            <TextInput
              style={[
                styles.formInput,
                styles.bioInput,
                {
                  backgroundColor: colors.surface,
                  color: colors.text,
                  borderColor: colors.border,
                },
              ]}
              placeholder="介绍一下自己吧~"
              placeholderTextColor={colors.textSecondary}
              value={bio}
              onChangeText={setBio}
              maxLength={200}
              multiline
              numberOfLines={4}
              textAlignVertical="top"
            />
            <Text style={[styles.formHint, { color: colors.textSecondary }]}>
              {bio.length}/200
            </Text>
          </View>

          {/* 所在地 */}
          <View style={styles.formSection}>
            <Text style={[styles.formLabel, { color: colors.text }]}>所在地</Text>
            <TextInput
              style={[
                styles.formInput,
                {
                  backgroundColor: colors.surface,
                  color: colors.text,
                  borderColor: colors.border,
                },
              ]}
              placeholder="请输入所在城市"
              placeholderTextColor={colors.textSecondary}
              value={location}
              onChangeText={setLocation}
              maxLength={50}
              clearButtonMode="while-editing"
            />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#eee',
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
  },
  backButtonText: {
    fontSize: 24,
  },
  headerTitle: {
    fontSize: 17,
    fontWeight: '600',
  },
  saveButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: '600',
  },
  keyboardView: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 40,
  },
  avatarSection: {
    alignItems: 'center',
    marginTop: 24,
    marginBottom: 24,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
  },
  avatarEditOverlay: {
    position: 'absolute',
    bottom: 0,
    left: '50%',
    marginLeft: -24,
    backgroundColor: 'rgba(0,0,0,0.5)',
    paddingHorizontal: 12,
    paddingVertical: 2,
    borderRadius: 10,
  },
  avatarEditText: {
    color: '#FFFFFF',
    fontSize: 11,
  },
  formSection: {
    paddingHorizontal: 16,
    marginBottom: 20,
  },
  formLabel: {
    fontSize: 14,
    fontWeight: '500',
    marginBottom: 8,
  },
  formInput: {
    height: 48,
    borderRadius: 12,
    paddingHorizontal: 16,
    fontSize: 15,
    borderWidth: 1,
  },
  bioInput: {
    height: 100,
    paddingTop: 12,
  },
  formHint: {
    fontSize: 12,
    marginTop: 4,
    textAlign: 'right',
  },
  genderOptions: {
    flexDirection: 'row',
    gap: 12,
  },
  genderOption: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: 'center',
  },
});
