import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Switch,
  Alert,
  Linking,
  ActivityIndicator,
} from 'react-native';
import { useTheme } from '../../hooks/useTheme';
import { useAuthStore } from '../../store/useAuthStore';
import { Storage } from '../../utils/storage';
import { STORAGE_KEYS } from '../../constants/config';

interface SettingsScreenProps {
  navigation: any;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({ navigation }) => {
  const { colors } = useTheme();
  const { logout } = useAuthStore();
  const [pushEnabled, setPushEnabled] = useState(true);
  const [commentPermission, setCommentPermission] = useState<'all' | 'follow'>('all');
  const [messagePermission, setMessagePermission] = useState<'all' | 'follow'>('all');
  const [isClearing, setIsClearing] = useState(false);

  const handleLogout = useCallback(() => {
    Alert.alert('退出登录', '确定要退出登录吗？', [
      { text: '取消', style: 'cancel' },
      {
        text: '确定',
        style: 'destructive',
        onPress: () => {
          logout();
          navigation.goBack();
        },
      },
    ]);
  }, [logout, navigation]);

  const handleClearCache = useCallback(async () => {
    setIsClearing(true);
    try {
      // 模拟清除缓存
      await new Promise((resolve) => setTimeout(resolve, 1000));
      Alert.alert('提示', '缓存已清除');
    } catch {
      Alert.alert('提示', '清除缓存失败');
    } finally {
      setIsClearing(false);
    }
  }, []);

  const handleAbout = useCallback(() => {
    Alert.alert(
      '关于榔头',
      '榔头 v1.0.0\n记录美好生活，分享精彩瞬间',
      [{ text: '确定' }]
    );
  }, []);

  const renderSection = (title: string, children: React.ReactNode) => (
    <View style={styles.section}>
      <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>{title}</Text>
      <View style={[styles.sectionContent, { backgroundColor: colors.surface }]}>
        {children}
      </View>
    </View>
  );

  const renderMenuItem = (
    label: string,
    onPress?: () => void,
    right?: React.ReactNode,
    showArrow: boolean = true
  ) => (
    <TouchableOpacity
      style={[styles.menuItem, { borderBottomColor: colors.border }]}
      onPress={onPress}
      disabled={!onPress}
    >
      <Text style={[styles.menuLabel, { color: colors.text }]}>{label}</Text>
      <View style={styles.menuRight}>
        {right}
        {showArrow && onPress && (
          <Text style={[styles.arrow, { color: colors.textSecondary }]}>›</Text>
        )}
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      {/* 顶部导航 */}
      <View style={[styles.header, { backgroundColor: colors.background }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Text style={[styles.backButtonText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.text }]}>设置</Text>
        <View style={styles.headerRight} />
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* 账号与安全 */}
        {renderSection('账号与安全', (
          <>
            {renderMenuItem('修改密码', () => {
              Alert.alert('提示', '修改密码功能开发中');
            })}
            {renderMenuItem('绑定手机', () => {
              Alert.alert('提示', '绑定手机功能开发中');
            })}
          </>
        ))}

        {/* 通知设置 */}
        {renderSection('通知设置', (
          <>
            <View style={[styles.menuItem, { borderBottomColor: colors.border }]}>
              <Text style={[styles.menuLabel, { color: colors.text }]}>推送通知</Text>
              <View style={styles.menuRight}>
                <Switch
                  value={pushEnabled}
                  onValueChange={setPushEnabled}
                  trackColor={{ false: colors.border, true: colors.primary }}
                />
              </View>
            </View>
          </>
        ))}

        {/* 隐私设置 */}
        {renderSection('隐私设置', (
          <>
            <View style={[styles.menuItem, { borderBottomColor: colors.border }]}>
              <Text style={[styles.menuLabel, { color: colors.text }]}>谁可以评论我的笔记</Text>
              <View style={styles.menuRight}>
                <TouchableOpacity
                  onPress={() => setCommentPermission(commentPermission === 'all' ? 'follow' : 'all')}
                >
                  <Text style={{ color: colors.primary, fontSize: 14 }}>
                    {commentPermission === 'all' ? '所有人' : '仅关注的人'}
                  </Text>
                </TouchableOpacity>
                <Text style={[styles.arrow, { color: colors.textSecondary }]}>›</Text>
              </View>
            </View>
            <View style={styles.menuItem}>
              <Text style={[styles.menuLabel, { color: colors.text }]}>谁可以私信我</Text>
              <View style={styles.menuRight}>
                <TouchableOpacity
                  onPress={() => setMessagePermission(messagePermission === 'all' ? 'follow' : 'all')}
                >
                  <Text style={{ color: colors.primary, fontSize: 14 }}>
                    {messagePermission === 'all' ? '所有人' : '仅关注的人'}
                  </Text>
                </TouchableOpacity>
                <Text style={[styles.arrow, { color: colors.textSecondary }]}>›</Text>
              </View>
            </View>
          </>
        ))}

        {/* 通用设置 */}
        {renderSection('通用', (
          <>
            {renderMenuItem(
              '清除缓存',
              handleClearCache,
              isClearing ? (
                <ActivityIndicator size="small" color={colors.primary} />
              ) : (
                <Text style={{ color: colors.textSecondary, fontSize: 14 }}>12.3 MB</Text>
              ),
              true
            )}
            {renderMenuItem('关于榔头', handleAbout)}
          </>
        ))}

        {/* 退出登录 */}
        <View style={styles.logoutSection}>
          <TouchableOpacity
            style={[styles.logoutButton, { backgroundColor: colors.surface }]}
            onPress={handleLogout}
          >
            <Text style={[styles.logoutButtonText, { color: '#FF2442' }]}>退出登录</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.versionFooter}>
          <Text style={[styles.versionText, { color: colors.textSecondary }]}>
            榔头 v1.0.0
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#eee',
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
  },
  backButtonText: {
    fontSize: 24,
  },
  headerTitle: {
    fontSize: 17,
    fontWeight: '600',
  },
  headerRight: {
    width: 40,
  },
  scrollView: {
    flex: 1,
  },
  section: {
    marginTop: 16,
  },
  sectionTitle: {
    fontSize: 13,
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  sectionContent: {
    marginHorizontal: 16,
    borderRadius: 12,
    overflow: 'hidden',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  menuLabel: {
    fontSize: 16,
  },
  menuRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  arrow: {
    fontSize: 20,
  },
  logoutSection: {
    marginTop: 32,
    paddingHorizontal: 16,
  },
  logoutButton: {
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  logoutButtonText: {
    fontSize: 16,
    fontWeight: '500',
  },
  versionFooter: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  versionText: {
    fontSize: 12,
  },
});
