import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  RefreshControl,
  ActivityIndicator,
  Alert,
  Dimensions,
} from 'react-native';
import FastImage from 'react-native-fast-image';
import { useTheme } from '../../hooks/useTheme';
import { useCollections, useRemoveCollection } from '../../hooks/useInteract';
import type { Note } from '../../types';

const { width } = Dimensions.get('window');
const CARD_WIDTH = (width - 24) / 2;
const DEFAULT_RATIO = 1.2;

interface CollectionListScreenProps {
  navigation: any;
}

export const CollectionListScreen: React.FC<CollectionListScreenProps> = ({ navigation }) => {
  const { colors } = useTheme();
  const [page, setPage] = useState(1);
  const [allNotes, setAllNotes] = useState<Note[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const {
    data: collectionsData,
    isLoading: collectionsLoading,
    refetch: refetchCollections,
  } = useCollections(page);

  const removeCollectionMutation = useRemoveCollection();

  React.useEffect(() => {
    if (collectionsData) {
      setAllNotes((prev) =>
        page === 1 ? collectionsData.list : [...prev, ...collectionsData.list]
      );
    }
  }, [collectionsData, page]);

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    setPage(1);
    setAllNotes([]);
    await refetchCollections();
    setIsRefreshing(false);
  }, [refetchCollections]);

  const handleLoadMore = useCallback(() => {
    if (!collectionsLoading && collectionsData?.hasMore) {
      setPage((prev) => prev + 1);
    }
  }, [collectionsLoading, collectionsData]);

  const handleNotePress = useCallback(
    (note: Note) => {
      navigation?.navigate('NoteDetail', { noteId: note.id });
    },
    [navigation]
  );

  const handleRemoveCollection = useCallback(
    (note: Note) => {
      Alert.alert('取消收藏', '确定要取消收藏这篇笔记吗？', [
        { text: '取消', style: 'cancel' },
        {
          text: '确定',
          style: 'destructive',
          onPress: () => {
            removeCollectionMutation.mutate(note.id, {
              onSuccess: () => {
                setAllNotes((prev) => prev.filter((n) => n.id !== note.id));
              },
            });
          },
        },
      ]);
    },
    [removeCollectionMutation]
  );

  const renderNoteCard = (note: Note) => {
    const imageHeight = CARD_WIDTH * DEFAULT_RATIO;
    return (
      <TouchableOpacity
        key={note.id}
        style={[styles.card, { backgroundColor: colors.surface }]}
        onPress={() => handleNotePress(note)}
        onLongPress={() => handleRemoveCollection(note)}
        activeOpacity={0.9}
      >
        <FastImage
          source={{ uri: note.images[0] }}
          style={[styles.cardImage, { height: imageHeight }]}
          resizeMode={FastImage.resizeMode.cover}
        />
        <View style={styles.cardContent}>
          <Text style={[styles.cardTitle, { color: colors.text }]} numberOfLines={2}>
            {note.title}
          </Text>
          <View style={styles.cardAuthorRow}>
            <FastImage
              source={{ uri: note.author.avatar }}
              style={styles.cardAvatar}
            />
            <Text style={[styles.cardAuthorName, { color: colors.textSecondary }]} numberOfLines={1}>
              {note.author.nickname}
            </Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const leftColumn = allNotes.filter((_, index) => index % 2 === 0);
  const rightColumn = allNotes.filter((_, index) => index % 2 === 1);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      {/* 顶部导航 */}
      <View style={[styles.header, { backgroundColor: colors.background, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Text style={[styles.backButtonText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.text }]}>我的收藏</Text>
        <View style={styles.headerRight} />
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary}
          />
        }
        onScroll={({ nativeEvent }) => {
          const { layoutMeasurement, contentOffset, contentSize } = nativeEvent;
          if (layoutMeasurement.height + contentOffset.y >= contentSize.height - 50) {
            handleLoadMore();
          }
        }}
        scrollEventThrottle={400}
      >
        {allNotes.length > 0 ? (
          <View style={styles.masonryContainer}>
            <View style={styles.column}>
              {leftColumn.map((note) => renderNoteCard(note))}
            </View>
            <View style={styles.column}>
              {rightColumn.map((note) => renderNoteCard(note))}
            </View>
          </View>
        ) : (
          <View style={styles.emptyContainer}>
            {!collectionsLoading && (
              <>
                <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
                  还没有收藏任何笔记
                </Text>
                <TouchableOpacity
                  style={[styles.exploreButton, { backgroundColor: colors.primary }]}
                  onPress={() => navigation?.navigate('Main', { screen: 'Home' })}
                >
                  <Text style={styles.exploreButtonText}>去发现</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        )}
        {collectionsLoading && (
          <View style={styles.loadingMore}>
            <ActivityIndicator size="small" color={colors.primary} />
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
  },
  backButtonText: {
    fontSize: 24,
  },
  headerTitle: {
    fontSize: 17,
    fontWeight: '600',
  },
  headerRight: {
    width: 40,
  },
  masonryContainer: {
    flexDirection: 'row',
    paddingHorizontal: 8,
    paddingTop: 8,
  },
  column: {
    flex: 1,
    paddingHorizontal: 4,
  },
  card: {
    width: CARD_WIDTH,
    borderRadius: 12,
    marginBottom: 8,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  cardImage: {
    width: CARD_WIDTH,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
  },
  cardContent: {
    padding: 10,
  },
  cardTitle: {
    fontSize: 14,
    fontWeight: '500',
    lineHeight: 20,
    marginBottom: 8,
  },
  cardAuthorRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  cardAvatar: {
    width: 20,
    height: 20,
    borderRadius: 10,
    marginRight: 6,
  },
  cardAuthorName: {
    fontSize: 12,
    flex: 1,
  },
  emptyContainer: {
    paddingVertical: 80,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 14,
    marginBottom: 16,
  },
  exploreButton: {
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderRadius: 20,
  },
  exploreButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
  loadingMore: {
    paddingVertical: 16,
    alignItems: 'center',
  },
});
