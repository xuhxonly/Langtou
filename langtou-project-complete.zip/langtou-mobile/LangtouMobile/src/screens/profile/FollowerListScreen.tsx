import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  FlatList,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import FastImage from 'react-native-fast-image';
import { useTheme } from '../../hooks/useTheme';
import { useFollowers, useFollowUser } from '../../hooks/useUser';
import { useAuthStore } from '../../store/useAuthStore';
import type { User } from '../../types';

interface FollowerListScreenProps {
  route: { params: { userId: string } };
  navigation: any;
}

export const FollowerListScreen: React.FC<FollowerListScreenProps> = ({ route, navigation }) => {
  const { colors } = useTheme();
  const { isAuthenticated } = useAuthStore();
  const { userId } = route.params;
  const [page, setPage] = useState(1);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const {
    data: followersData,
    isLoading: followersLoading,
    refetch: refetchFollowers,
  } = useFollowers(userId, page);

  const followMutation = useFollowUser();

  React.useEffect(() => {
    if (followersData) {
      setAllUsers((prev) =>
        page === 1 ? followersData.list : [...prev, ...followersData.list]
      );
    }
  }, [followersData, page]);

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    setPage(1);
    setAllUsers([]);
    await refetchFollowers();
    setIsRefreshing(false);
  }, [refetchFollowers]);

  const handleLoadMore = useCallback(() => {
    if (!followersLoading && followersData?.hasMore) {
      setPage((prev) => prev + 1);
    }
  }, [followersLoading, followersData]);

  const handleUserPress = useCallback(
    (user: User) => {
      navigation.navigate('UserProfile', { userId: user.id });
    },
    [navigation]
  );

  const handleFollow = useCallback(
    (user: User) => {
      if (!isAuthenticated) {
        navigation.navigate('Login');
        return;
      }
      followMutation.mutate({
        userId: user.id,
        isFollowing: user.isFollowing ?? false,
      });
      // 乐观更新本地状态
      setAllUsers((prev) =>
        prev.map((u) =>
          u.id === user.id ? { ...u, isFollowing: !u.isFollowing } : u
        )
      );
    },
    [isAuthenticated, followMutation, navigation]
  );

  const renderItem = useCallback(
    ({ item }: { item: User }) => {
      const isFollowing = item.isFollowing ?? false;
      return (
        <TouchableOpacity
          style={[styles.userItem, { borderBottomColor: colors.border }]}
          onPress={() => handleUserPress(item)}
          activeOpacity={0.8}
        >
          <FastImage source={{ uri: item.avatar || '' }} style={styles.avatar} />
          <View style={styles.userInfo}>
            <Text style={[styles.nickname, { color: colors.text }]} numberOfLines={1}>
              {item.nickname || '榔头用户'}
            </Text>
            <Text style={[styles.bio, { color: colors.textSecondary }]} numberOfLines={1}>
              {item.bio || '这个人很懒，什么都没写~'}
            </Text>
          </View>
          <TouchableOpacity
            style={[
              styles.followButton,
              {
                backgroundColor: isFollowing ? colors.surface : colors.primary,
                borderColor: colors.border,
              },
            ]}
            onPress={() => handleFollow(item)}
            disabled={followMutation.isPending}
          >
            {followMutation.isPending ? (
              <ActivityIndicator size="small" color={isFollowing ? colors.primary : '#FFFFFF'} />
            ) : (
              <Text
                style={[
                  styles.followButtonText,
                  { color: isFollowing ? colors.text : '#FFFFFF' },
                ]}
              >
                {isFollowing ? '已关注' : '+ 关注'}
              </Text>
            )}
          </TouchableOpacity>
        </TouchableOpacity>
      );
    },
    [colors, handleUserPress, handleFollow, followMutation.isPending]
  );

  const renderEmpty = () => {
    if (followersLoading && page === 1) {
      return (
        <View style={styles.emptyContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      );
    }
    return (
      <View style={styles.emptyContainer}>
        <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
          还没有粉丝
        </Text>
      </View>
    );
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      {/* 顶部导航 */}
      <View style={[styles.header, { backgroundColor: colors.background, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Text style={[styles.backButtonText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.text }]}>粉丝</Text>
        <View style={styles.headerRight} />
      </View>

      <FlatList
        data={allUsers}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary}
          />
        }
        onEndReached={handleLoadMore}
        onEndReachedThreshold={0.5}
        ListEmptyComponent={renderEmpty}
        ListFooterComponent={
          followersLoading && page > 1 ? (
            <View style={styles.loadingMore}>
              <ActivityIndicator size="small" color={colors.primary} />
            </View>
          ) : null
        }
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
  },
  backButtonText: {
    fontSize: 24,
  },
  headerTitle: {
    fontSize: 17,
    fontWeight: '600',
  },
  headerRight: {
    width: 40,
  },
  userItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    marginRight: 12,
  },
  userInfo: {
    flex: 1,
    justifyContent: 'center',
  },
  nickname: {
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 4,
  },
  bio: {
    fontSize: 13,
    lineHeight: 18,
  },
  followButton: {
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1,
    minWidth: 72,
    alignItems: 'center',
  },
  followButtonText: {
    fontSize: 13,
    fontWeight: '600',
  },
  emptyContainer: {
    paddingVertical: 80,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 14,
  },
  loadingMore: {
    paddingVertical: 16,
    alignItems: 'center',
  },
});
