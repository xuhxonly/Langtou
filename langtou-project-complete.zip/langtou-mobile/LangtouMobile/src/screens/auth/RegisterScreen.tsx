import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useTheme } from '../../hooks/useTheme';
import { useRegister } from '../../hooks/useUser';
import { sendSmsCode } from '../../api/user';

interface RegisterScreenProps {
  navigation?: any;
}

export const RegisterScreen: React.FC<RegisterScreenProps> = ({ navigation }) => {
  const { colors } = useTheme();
  const registerMutation = useRegister();

  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [nickname, setNickname] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isCodeSent, setIsCodeSent] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [isSendingCode, setIsSendingCode] = useState(false);
  const [agreedTerms, setAgreedTerms] = useState(false);

  const handleSendCode = useCallback(async () => {
    if (phone.length !== 11) {
      Alert.alert('提示', '请输入正确的手机号');
      return;
    }
    setIsSendingCode(true);
    try {
      await sendSmsCode(phone);
      setIsCodeSent(true);
      setCountdown(60);
      const timer = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } catch (err: any) {
      Alert.alert('发送失败', err?.message || '验证码发送失败，请稍后重试');
    } finally {
      setIsSendingCode(false);
    }
  }, [phone]);

  const validate = useCallback((): boolean => {
    if (!phone || phone.length !== 11) {
      Alert.alert('提示', '请输入正确的手机号');
      return false;
    }
    if (!code || code.length < 4) {
      Alert.alert('提示', '请输入验证码');
      return false;
    }
    if (!nickname.trim()) {
      Alert.alert('提示', '请输入昵称');
      return false;
    }
    if (nickname.trim().length < 2 || nickname.trim().length > 20) {
      Alert.alert('提示', '昵称长度需要在2-20个字符之间');
      return false;
    }
    if (!password || password.length < 6) {
      Alert.alert('提示', '密码长度至少6位');
      return false;
    }
    if (password !== confirmPassword) {
      Alert.alert('提示', '两次输入的密码不一致');
      return false;
    }
    if (!agreedTerms) {
      Alert.alert('提示', '请先同意用户协议和隐私政策');
      return false;
    }
    return true;
  }, [phone, code, nickname, password, confirmPassword, agreedTerms]);

  const handleRegister = useCallback(() => {
    if (!validate()) return;

    registerMutation.mutate(
      {
        phone,
        code,
        nickname: nickname.trim(),
      },
      {
        onSuccess: () => {
          navigation?.goBack();
        },
        onError: (error: any) => {
          Alert.alert('注册失败', error?.message || '请稍后重试');
        },
      }
    );
  }, [validate, phone, code, nickname, registerMutation, navigation]);

  const handleGoLogin = useCallback(() => {
    navigation?.goBack();
  }, [navigation]);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.scrollContent}
        >
          <View style={styles.content}>
            {/* 顶部关闭按钮 */}
            <View style={styles.closeRow}>
              <TouchableOpacity onPress={() => navigation?.goBack()} style={styles.closeButton}>
                <Text style={[styles.closeButtonText, { color: colors.text }]}>×</Text>
              </TouchableOpacity>
            </View>

            <Text style={[styles.title, { color: colors.text }]}>创建账号</Text>
            <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
              注册后开始探索精彩内容
            </Text>

            <View style={styles.form}>
              {/* 手机号 */}
              <View style={styles.inputContainer}>
                <Text style={[styles.inputLabel, { color: colors.text }]}>手机号</Text>
                <TextInput
                  style={[
                    styles.input,
                    {
                      backgroundColor: colors.surface,
                      color: colors.text,
                      borderColor: colors.border,
                    },
                  ]}
                  placeholder="请输入手机号"
                  placeholderTextColor={colors.textSecondary}
                  value={phone}
                  onChangeText={setPhone}
                  keyboardType="phone-pad"
                  maxLength={11}
                  clearButtonMode="while-editing"
                />
              </View>

              {/* 验证码 */}
              <View style={styles.inputContainer}>
                <Text style={[styles.inputLabel, { color: colors.text }]}>验证码</Text>
                <View style={styles.codeInputContainer}>
                  <TextInput
                    style={[
                      styles.codeInput,
                      {
                        backgroundColor: colors.surface,
                        color: colors.text,
                        borderColor: colors.border,
                      },
                    ]}
                    placeholder="请输入验证码"
                    placeholderTextColor={colors.textSecondary}
                    value={code}
                    onChangeText={setCode}
                    keyboardType="number-pad"
                    maxLength={6}
                  />
                  <TouchableOpacity
                    style={[
                      styles.sendCodeButton,
                      {
                        backgroundColor:
                          (isCodeSent && countdown > 0) || isSendingCode ? colors.border : colors.primary,
                      },
                    ]}
                    onPress={handleSendCode}
                    disabled={(isCodeSent && countdown > 0) || isSendingCode}
                  >
                    {isSendingCode ? (
                      <ActivityIndicator color="#FFFFFF" size="small" />
                    ) : countdown > 0 ? (
                      <Text style={styles.sendCodeButtonText}>{countdown}s</Text>
                    ) : (
                      <Text style={styles.sendCodeButtonText}>
                        {isCodeSent ? '重新获取' : '获取验证码'}
                      </Text>
                    )}
                  </TouchableOpacity>
                </View>
              </View>

              {/* 昵称 */}
              <View style={styles.inputContainer}>
                <Text style={[styles.inputLabel, { color: colors.text }]}>昵称</Text>
                <TextInput
                  style={[
                    styles.input,
                    {
                      backgroundColor: colors.surface,
                      color: colors.text,
                      borderColor: colors.border,
                    },
                  ]}
                  placeholder="给自己取个名字吧"
                  placeholderTextColor={colors.textSecondary}
                  value={nickname}
                  onChangeText={setNickname}
                  maxLength={20}
                  clearButtonMode="while-editing"
                />
              </View>

              {/* 密码 */}
              <View style={styles.inputContainer}>
                <Text style={[styles.inputLabel, { color: colors.text }]}>设置密码</Text>
                <TextInput
                  style={[
                    styles.input,
                    {
                      backgroundColor: colors.surface,
                      color: colors.text,
                      borderColor: colors.border,
                    },
                  ]}
                  placeholder="至少6位密码"
                  placeholderTextColor={colors.textSecondary}
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry
                  maxLength={32}
                />
              </View>

              {/* 确认密码 */}
              <View style={styles.inputContainer}>
                <Text style={[styles.inputLabel, { color: colors.text }]}>确认密码</Text>
                <TextInput
                  style={[
                    styles.input,
                    {
                      backgroundColor: colors.surface,
                      color: colors.text,
                      borderColor: colors.border,
                    },
                  ]}
                  placeholder="再次输入密码"
                  placeholderTextColor={colors.textSecondary}
                  value={confirmPassword}
                  onChangeText={setConfirmPassword}
                  secureTextEntry
                  maxLength={32}
                />
              </View>

              {/* 用户协议 */}
              <TouchableOpacity
                style={styles.termsRow}
                onPress={() => setAgreedTerms(!agreedTerms)}
                activeOpacity={0.7}
              >
                <View
                  style={[
                    styles.checkbox,
                    {
                      backgroundColor: agreedTerms ? colors.primary : colors.surface,
                      borderColor: colors.border,
                    },
                  ]}
                >
                  {agreedTerms && <Text style={styles.checkmark}>✓</Text>}
                </View>
                <Text style={[styles.termsText, { color: colors.textSecondary }]}>
                  我已阅读并同意
                  <Text style={{ color: colors.primary }}>《用户协议》</Text>
                  和
                  <Text style={{ color: colors.primary }}>《隐私政策》</Text>
                </Text>
              </TouchableOpacity>

              {/* 注册按钮 */}
              <TouchableOpacity
                style={[
                  styles.registerButton,
                  {
                    backgroundColor:
                      registerMutation.isPending || !agreedTerms
                        ? colors.border
                        : colors.primary,
                  },
                ]}
                onPress={handleRegister}
                disabled={registerMutation.isPending || !agreedTerms}
              >
                {registerMutation.isPending ? (
                  <ActivityIndicator color="#FFFFFF" size="small" />
                ) : (
                  <Text style={styles.registerButtonText}>注册</Text>
                )}
              </TouchableOpacity>

              {/* 已有账号 */}
              <TouchableOpacity style={styles.loginLink} onPress={handleGoLogin}>
                <Text style={[styles.loginText, { color: colors.textSecondary }]}>
                  已有账号？
                  <Text style={{ color: colors.primary }}> 去登录</Text>
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  keyboardView: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 40,
  },
  content: {
    paddingHorizontal: 24,
    paddingTop: 8,
  },
  closeRow: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginBottom: 8,
  },
  closeButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeButtonText: {
    fontSize: 28,
    fontWeight: '300',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    marginBottom: 32,
  },
  form: {
    gap: 20,
  },
  inputContainer: {
    gap: 8,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '500',
  },
  input: {
    height: 48,
    borderRadius: 12,
    paddingHorizontal: 16,
    fontSize: 16,
    borderWidth: 1,
  },
  codeInputContainer: {
    flexDirection: 'row',
    gap: 12,
  },
  codeInput: {
    flex: 1,
    height: 48,
    borderRadius: 12,
    paddingHorizontal: 16,
    fontSize: 16,
    borderWidth: 1,
  },
  sendCodeButton: {
    paddingHorizontal: 16,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    minWidth: 100,
  },
  sendCodeButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
  termsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  checkbox: {
    width: 20,
    height: 20,
    borderRadius: 4,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkmark: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  termsText: {
    fontSize: 13,
    flex: 1,
    lineHeight: 20,
  },
  registerButton: {
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 8,
  },
  registerButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  loginLink: {
    alignItems: 'center',
    marginTop: 16,
  },
  loginText: {
    fontSize: 14,
  },
});
