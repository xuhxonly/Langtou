import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Image,
  Alert,
  SafeAreaView,
  ActivityIndicator,
} from 'react-native';
import { launchImageLibrary } from 'react-native-image-picker';
import { useTheme } from '../../hooks/useTheme';
import { useCreateNote, useUploadImage } from '../../hooks/useNotes';
import { useAuthStore } from '../../store/useAuthStore';

interface PublishScreenProps {
  navigation?: any;
}

export const PublishScreen: React.FC<PublishScreenProps> = ({ navigation }) => {
  const { colors } = useTheme();
  const { isAuthenticated } = useAuthStore();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState('');
  const [location, setLocation] = useState('');
  const [publishing, setPublishing] = useState(false);

  const createNoteMutation = useCreateNote();
  const uploadImageMutation = useUploadImage();

  const handleSelectImages = useCallback(() => {
    launchImageLibrary(
      {
        mediaType: 'photo',
        selectionLimit: 18 - images.length,
      },
      (response) => {
        if (response.assets) {
          const newImages = response.assets.map((asset) => asset.uri || '');
          setImages((prev) => [...prev, ...newImages]);
        }
      }
    );
  }, [images.length]);

  const handleRemoveImage = useCallback((index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
  }, []);

  const handleMoveImage = useCallback((fromIndex: number, toIndex: number) => {
    setImages((prev) => {
      const newImages = [...prev];
      const [removed] = newImages.splice(fromIndex, 1);
      newImages.splice(toIndex, 0, removed);
      return newImages;
    });
  }, []);

  const handleAddTag = useCallback(() => {
    if (tagInput.trim() && !tags.includes(tagInput.trim()) && tags.length < 10) {
      setTags((prev) => [...prev, tagInput.trim()]);
      setTagInput('');
    }
  }, [tagInput, tags]);

  const handleRemoveTag = useCallback((tag: string) => {
    setTags((prev) => prev.filter((t) => t !== tag));
  }, []);

  const handlePublish = useCallback(async () => {
    if (!isAuthenticated) {
      Alert.alert('提示', '请先登录');
      navigation?.navigate('Login');
      return;
    }

    if (!title.trim()) {
      Alert.alert('提示', '请输入标题');
      return;
    }
    if (images.length === 0) {
      Alert.alert('提示', '请至少选择一张图片');
      return;
    }

    setPublishing(true);
    try {
      // 上传图片
      const uploadedUrls: string[] = [];
      for (const imageUri of images) {
        try {
          const url = await uploadImageMutation.mutateAsync(imageUri);
          uploadedUrls.push(url);
        } catch {
          // 上传失败时使用原始 URI 作为 fallback
          uploadedUrls.push(imageUri);
        }
      }

      // 发布笔记
      await createNoteMutation.mutateAsync({
        title: title.trim(),
        content: content.trim(),
        images: uploadedUrls,
        tags,
      });

      Alert.alert('发布成功', '您的笔记已发布！', [
        {
          text: '确定',
          onPress: () => {
            setTitle('');
            setContent('');
            setImages([]);
            setTags([]);
            setLocation('');
            navigation?.navigate('Home');
          },
        },
      ]);
    } catch (err: any) {
      Alert.alert('发布失败', err?.message || '请稍后重试');
    } finally {
      setPublishing(false);
    }
  }, [
    isAuthenticated,
    title,
    content,
    images,
    tags,
    location,
    navigation,
    createNoteMutation,
    uploadImageMutation,
  ]);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* 图片选择区域 */}
        <View style={styles.imageSection}>
          <Text style={[styles.sectionLabel, { color: colors.textSecondary }]}>
            添加图片 ({images.length}/18)
          </Text>
          <View style={styles.imageGrid}>
            {images.map((uri, index) => (
              <TouchableOpacity
                key={`img_${index}`}
                onLongPress={() => {
                  Alert.alert(
                    '图片操作',
                    '',
                    [
                      { text: '取消', style: 'cancel' },
                      {
                        text: '向左移动',
                        onPress: () => index > 0 && handleMoveImage(index, index - 1),
                      },
                      {
                        text: '向右移动',
                        onPress: () =>
                          index < images.length - 1 && handleMoveImage(index, index + 1),
                      },
                      { text: '删除', style: 'destructive', onPress: () => handleRemoveImage(index) },
                    ]
                  );
                }}
              >
                <View style={styles.imageContainer}>
                  <Image source={{ uri }} style={styles.image} />
                  <TouchableOpacity
                    style={styles.removeButton}
                    onPress={() => handleRemoveImage(index)}
                  >
                    <Text style={styles.removeButtonText}>×</Text>
                  </TouchableOpacity>
                  <View style={styles.imageIndex}>
                    <Text style={styles.imageIndexText}>{index + 1}</Text>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
            {images.length < 18 && (
              <TouchableOpacity
                style={[styles.addButton, { borderColor: colors.border }]}
                onPress={handleSelectImages}
              >
                <Text style={[styles.addButtonText, { color: colors.textSecondary }]}>+</Text>
                <Text style={[styles.addButtonLabel, { color: colors.textSecondary }]}>
                  添加图片
                </Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* 标题输入 */}
        <View style={styles.titleSection}>
          <TextInput
            style={[styles.titleInput, { color: colors.text }]}
            placeholder="填写标题会有更多赞哦~"
            placeholderTextColor={colors.textSecondary}
            value={title}
            onChangeText={setTitle}
            maxLength={20}
          />
          <Text style={[styles.charCount, { color: colors.textSecondary }]}>
            {title.length}/20
          </Text>
        </View>

        {/* 正文输入 */}
        <TextInput
          style={[styles.contentInput, { color: colors.text }]}
          placeholder="添加正文"
          placeholderTextColor={colors.textSecondary}
          value={content}
          onChangeText={setContent}
          multiline
          textAlignVertical="top"
          maxLength={1000}
        />
        <Text style={[styles.contentCharCount, { color: colors.textSecondary }]}>
          {content.length}/1000
        </Text>

        {/* 位置信息 */}
        <View style={styles.locationSection}>
          <TouchableOpacity
            style={[styles.locationButton, { borderColor: colors.border }]}
            onPress={() => {
              Alert.alert('添加位置', '位置选择功能开发中');
            }}
          >
            <Text style={[styles.locationIcon, { color: colors.textSecondary }]}>📍</Text>
            <Text style={[styles.locationText, { color: location ? colors.text : colors.textSecondary }]}>
              {location || '添加位置'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* 标签输入 */}
        <View style={styles.tagsSection}>
          <Text style={[styles.sectionLabel, { color: colors.textSecondary }]}>
            添加标签 ({tags.length}/10)
          </Text>
          <View style={styles.tagInputRow}>
            <TextInput
              style={[styles.tagInput, { color: colors.text, borderColor: colors.border }]}
              placeholder="输入标签后按回车添加"
              placeholderTextColor={colors.textSecondary}
              value={tagInput}
              onChangeText={setTagInput}
              onSubmitEditing={handleAddTag}
              returnKeyType="done"
            />
            <TouchableOpacity
              style={[styles.addTagButton, { backgroundColor: colors.primary }]}
              onPress={handleAddTag}
            >
              <Text style={styles.addTagButtonText}>添加</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.tagsContainer}>
            {tags.map((tag) => (
              <TouchableOpacity
                key={tag}
                style={[styles.tag, { backgroundColor: colors.surface }]}
                onPress={() => handleRemoveTag(tag)}
              >
                <Text style={[styles.tagText, { color: colors.primary }]}>#{tag} ×</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </ScrollView>

      {/* 发布按钮 */}
      <TouchableOpacity
        style={[
          styles.publishButton,
          {
            backgroundColor:
              publishing || !title.trim() || images.length === 0
                ? colors.border
                : colors.primary,
          },
        ]}
        onPress={handlePublish}
        disabled={publishing || !title.trim() || images.length === 0}
      >
        {publishing ? (
          <ActivityIndicator color="#FFFFFF" size="small" />
        ) : (
          <Text style={styles.publishButtonText}>发布笔记</Text>
        )}
      </TouchableOpacity>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  imageSection: {
    padding: 16,
  },
  sectionLabel: {
    fontSize: 13,
    marginBottom: 8,
  },
  imageGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  imageContainer: {
    position: 'relative',
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 8,
  },
  removeButton: {
    position: 'absolute',
    top: -8,
    right: -8,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#FF2442',
    justifyContent: 'center',
    alignItems: 'center',
  },
  removeButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  imageIndex: {
    position: 'absolute',
    bottom: 4,
    left: 4,
    backgroundColor: 'rgba(0,0,0,0.5)',
    paddingHorizontal: 4,
    paddingVertical: 2,
    borderRadius: 8,
  },
  imageIndexText: {
    color: '#FFFFFF',
    fontSize: 10,
  },
  addButton: {
    width: 100,
    height: 100,
    borderRadius: 8,
    borderWidth: 1,
    borderStyle: 'dashed',
    justifyContent: 'center',
    alignItems: 'center',
  },
  addButtonText: {
    fontSize: 32,
  },
  addButtonLabel: {
    fontSize: 12,
    marginTop: 4,
  },
  titleSection: {
    paddingHorizontal: 16,
  },
  titleInput: {
    fontSize: 18,
    fontWeight: '600',
    paddingVertical: 12,
  },
  charCount: {
    fontSize: 12,
    textAlign: 'right',
    paddingBottom: 8,
  },
  contentInput: {
    fontSize: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    minHeight: 120,
  },
  contentCharCount: {
    fontSize: 12,
    textAlign: 'right',
    paddingRight: 16,
    paddingBottom: 8,
  },
  locationSection: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  locationButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 8,
    borderWidth: 1,
  },
  locationIcon: {
    fontSize: 16,
    marginRight: 8,
  },
  locationText: {
    fontSize: 14,
  },
  tagsSection: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  tagInputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 8,
  },
  tagInput: {
    flex: 1,
    height: 40,
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
  },
  addTagButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  addTagButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  tag: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  tagText: {
    fontSize: 14,
  },
  publishButton: {
    marginHorizontal: 16,
    marginVertical: 12,
    paddingVertical: 14,
    borderRadius: 24,
    alignItems: 'center',
  },
  publishButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
});
