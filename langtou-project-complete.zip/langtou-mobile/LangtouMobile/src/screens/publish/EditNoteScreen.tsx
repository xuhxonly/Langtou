import React, { useState, useCallback, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  TextInput,
  ScrollView,
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import FastImage from 'react-native-fast-image';
import { useTheme } from '../../hooks/useTheme';
import { useNoteDetail, useUpdateNote } from '../../hooks/useNotes';
import type { NoteDetail } from '../../types';

interface EditNoteScreenProps {
  route: { params: { noteId: string } };
  navigation: any;
}

export const EditNoteScreen: React.FC<EditNoteScreenProps> = ({ route, navigation }) => {
  const { colors } = useTheme();
  const { noteId } = route.params;

  const {
    data: noteDetail,
    isLoading: noteLoading,
    refetch: refetchNote,
  } = useNoteDetail(noteId);

  const updateNoteMutation = useUpdateNote();

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [tagsInput, setTagsInput] = useState('');
  const [images, setImages] = useState<string[]>([]);

  useEffect(() => {
    if (noteDetail) {
      setTitle(noteDetail.title || '');
      setContent(noteDetail.content || '');
      setTagsInput((noteDetail.tags || []).map((t) => (typeof t === 'string' ? t : t.name)).join(' '));
      setImages(noteDetail.images || []);
    }
  }, [noteDetail]);

  const validateForm = useCallback((): boolean => {
    if (!title.trim()) {
      Alert.alert('提示', '请输入标题');
      return false;
    }
    if (!content.trim()) {
      Alert.alert('提示', '请输入正文内容');
      return false;
    }
    return true;
  }, [title, content]);

  const handleSave = useCallback(() => {
    if (!validateForm()) return;

    const tags = tagsInput
      .split(/\s+/)
      .map((t) => t.trim())
      .filter((t) => t.length > 0);

    updateNoteMutation.mutate(
      {
        noteId,
        data: {
          title: title.trim(),
          content: content.trim(),
          tags,
        },
      },
      {
        onSuccess: () => {
          Alert.alert('保存成功', '', [
            {
              text: '确定',
              onPress: () => {
                refetchNote();
                navigation.goBack();
              },
            },
          ]);
        },
        onError: () => {
          Alert.alert('保存失败', '请稍后重试');
        },
      }
    );
  }, [validateForm, tagsInput, title, content, noteId, updateNoteMutation, refetchNote, navigation]);

  if (noteLoading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  if (!noteDetail) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.errorContainer}>
          <Text style={[styles.errorText, { color: colors.textSecondary }]}>
            笔记加载失败
          </Text>
          <TouchableOpacity
            style={[styles.retryButton, { backgroundColor: colors.primary }]}
            onPress={() => refetchNote()}
          >
            <Text style={styles.retryButtonText}>重试</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      {/* 顶部导航 */}
      <View style={[styles.header, { backgroundColor: colors.background, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Text style={[styles.backButtonText, { color: colors.text }]}>取消</Text>
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.text }]}>编辑笔记</Text>
        <TouchableOpacity
          style={styles.saveButton}
          onPress={handleSave}
          disabled={updateNoteMutation.isPending}
        >
          {updateNoteMutation.isPending ? (
            <ActivityIndicator size="small" color={colors.primary} />
          ) : (
            <Text style={[styles.saveButtonText, { color: colors.primary }]}>保存</Text>
          )}
        </TouchableOpacity>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* 图片预览（不可编辑） */}
          {images.length > 0 && (
            <View style={styles.imagesSection}>
              <Text style={[styles.sectionLabel, { color: colors.textSecondary }]}>
                图片（不可修改）
              </Text>
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                style={styles.imagesScroll}
              >
                {images.map((uri, index) => (
                  <FastImage
                    key={index}
                    source={{ uri }}
                    style={styles.previewImage}
                    resizeMode={FastImage.resizeMode.cover}
                  />
                ))}
              </ScrollView>
            </View>
          )}

          {/* 标题输入 */}
          <View style={[styles.inputSection, { borderBottomColor: colors.border }]}>
            <TextInput
              style={[styles.titleInput, { color: colors.text }]}
              placeholder="填写标题会有更多赞哦~"
              placeholderTextColor={colors.textSecondary}
              value={title}
              onChangeText={setTitle}
              maxLength={50}
            />
            <Text style={[styles.inputCount, { color: colors.textSecondary }]}>
              {title.length}/50
            </Text>
          </View>

          {/* 正文输入 */}
          <View style={[styles.inputSection, { borderBottomColor: colors.border }]}>
            <TextInput
              style={[styles.contentInput, { color: colors.text }]}
              placeholder="添加正文"
              placeholderTextColor={colors.textSecondary}
              value={content}
              onChangeText={setContent}
              multiline
              textAlignVertical="top"
              maxLength={2000}
            />
            <Text style={[styles.inputCount, { color: colors.textSecondary }]}>
              {content.length}/2000
            </Text>
          </View>

          {/* 标签输入 */}
          <View style={styles.inputSection}>
            <Text style={[styles.sectionLabel, { color: colors.textSecondary }]}>
              标签（用空格分隔）
            </Text>
            <TextInput
              style={[styles.tagsInput, { color: colors.text }]}
              placeholder="添加标签，让更多人看到"
              placeholderTextColor={colors.textSecondary}
              value={tagsInput}
              onChangeText={setTagsInput}
            />
            {tagsInput.trim().length > 0 && (
              <View style={styles.tagsPreview}>
                {tagsInput
                  .split(/\s+/)
                  .map((t) => t.trim())
                  .filter((t) => t.length > 0)
                  .map((tag, index) => (
                    <View
                      key={index}
                      style={[styles.tagItem, { backgroundColor: colors.surface }]}
                    >
                      <Text style={[styles.tagText, { color: colors.primary }]}>
                        #{tag}
                      </Text>
                    </View>
                  ))}
              </View>
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backButton: {
    width: 50,
    height: 40,
    justifyContent: 'center',
  },
  backButtonText: {
    fontSize: 15,
  },
  headerTitle: {
    fontSize: 17,
    fontWeight: '600',
  },
  saveButton: {
    width: 50,
    height: 40,
    justifyContent: 'center',
    alignItems: 'flex-end',
  },
  saveButtonText: {
    fontSize: 15,
    fontWeight: '600',
  },
  keyboardView: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
  },
  errorText: {
    fontSize: 16,
    marginBottom: 16,
  },
  retryButton: {
    paddingHorizontal: 32,
    paddingVertical: 10,
    borderRadius: 20,
  },
  retryButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
  },
  imagesSection: {
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  sectionLabel: {
    fontSize: 13,
    marginBottom: 8,
  },
  imagesScroll: {
    flexDirection: 'row',
  },
  previewImage: {
    width: 100,
    height: 100,
    borderRadius: 8,
    marginRight: 8,
  },
  inputSection: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  titleInput: {
    fontSize: 18,
    fontWeight: '600',
    paddingVertical: 8,
  },
  contentInput: {
    fontSize: 15,
    lineHeight: 22,
    minHeight: 120,
    paddingVertical: 8,
  },
  tagsInput: {
    fontSize: 15,
    paddingVertical: 8,
  },
  inputCount: {
    fontSize: 12,
    textAlign: 'right',
    marginTop: 4,
  },
  tagsPreview: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 8,
  },
  tagItem: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    marginRight: 8,
    marginBottom: 6,
  },
  tagText: {
    fontSize: 13,
    fontWeight: '500',
  },
});
