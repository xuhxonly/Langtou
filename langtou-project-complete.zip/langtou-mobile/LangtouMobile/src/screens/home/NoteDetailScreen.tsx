import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  TextInput,
  FlatList,
  Image,
  Dimensions,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Modal,
  Alert,
} from 'react-native';
import FastImage from 'react-native-fast-image';
import { useTheme } from '../../hooks/useTheme';
import { useNoteDetail } from '../../hooks/useNotes';
import { useLike, useCollect, useComments, useCreateComment } from '../../hooks/useInteract';
import { useFollowUser, useUserProfile } from '../../hooks/useUser';
import { useAuthStore } from '../../store/useAuthStore';
import { formatNumber, formatTimeAgo } from '../../utils/format';
import apiClient from '../../api/client';
import { NOTES } from '../../constants/api';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const IMAGE_HEIGHT = SCREEN_WIDTH;

interface NoteDetailScreenProps {
  route: { params: { noteId: string } };
  navigation: any;
}

export const NoteDetailScreen: React.FC<NoteDetailScreenProps> = ({ route, navigation }) => {
  const { colors } = useTheme();
  const { noteId } = route.params;
  const { isAuthenticated } = useAuthStore();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [commentText, setCommentText] = useState('');
  const [replyingTo, setReplyingTo] = useState<{ commentId: string; userName: string } | null>(null);
  const [shareModalVisible, setShareModalVisible] = useState(false);
  const [shareLink, setShareLink] = useState('');

  const { data: note, isLoading, error } = useNoteDetail(noteId);
  const { data: authorProfile } = useUserProfile(note ? note.author.id : '');
  const { data: commentsData } = useComments(noteId);
  const likeMutation = useLike();
  const collectMutation = useCollect();
  const createCommentMutation = useCreateComment();
  const followMutation = useFollowUser();

  const handleLike = useCallback(() => {
    if (!isAuthenticated) {
      navigation.navigate('Login');
      return;
    }
    if (note) {
      likeMutation.mutate({ noteId: note.id, isLiked: note.isLiked });
    }
  }, [isAuthenticated, note, likeMutation, navigation]);

  const handleCollect = useCallback(() => {
    if (!isAuthenticated) {
      navigation.navigate('Login');
      return;
    }
    if (note) {
      collectMutation.mutate({ noteId: note.id, isCollected: note.isCollected });
    }
  }, [isAuthenticated, note, collectMutation, navigation]);

  const handleFollow = useCallback(() => {
    if (!isAuthenticated) {
      navigation.navigate('Login');
      return;
    }
    if (note) {
      const isFollowing = authorProfile?.isFollowing ?? note.author.isFollowing ?? false;
      followMutation.mutate({ userId: note.author.id, isFollowing });
    }
  }, [isAuthenticated, note, authorProfile, followMutation, navigation]);

  const handleAuthorPress = useCallback(() => {
    if (note) {
      navigation.navigate('UserProfile', { userId: note.author.id });
    }
  }, [note, navigation]);

  const handleSubmitComment = useCallback(() => {
    if (!commentText.trim()) return;
    if (!isAuthenticated) {
      navigation.navigate('Login');
      return;
    }

    createCommentMutation.mutate(
      {
        noteId,
        data: {
          noteId,
          content: commentText.trim(),
          parentId: replyingTo?.commentId,
        },
      },
      {
        onSuccess: () => {
          setCommentText('');
          setReplyingTo(null);
        },
      }
    );
  }, [commentText, noteId, replyingTo, isAuthenticated, navigation, createCommentMutation]);

  const handleReply = useCallback((commentId: string, userName: string) => {
    setReplyingTo({ commentId, userName });
    setCommentText(`@${userName} `);
  }, []);

  const handleShare = useCallback(async () => {
    try {
      const data = await apiClient.post<{ link: string }>(NOTES.SHARE(noteId));
      setShareLink(data.link || `https://langtou.app/notes/${noteId}`);
    } catch {
      setShareLink(`https://langtou.app/notes/${noteId}`);
    }
    setShareModalVisible(true);
  }, [noteId]);

  const handleCopyLink = useCallback(() => {
    Alert.alert('提示', '链接已复制到剪贴板');
    setShareModalVisible(false);
  }, []);

  if (isLoading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  if (error || !note) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.errorContainer}>
          <Text style={[styles.errorText, { color: colors.textSecondary }]}>
            加载失败，请稍后重试
          </Text>
          <TouchableOpacity
            style={[styles.retryButton, { backgroundColor: colors.primary }]}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.retryButtonText}>返回</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const comments = commentsData?.list || [];

  const renderCommentItem = ({ item }: { item: any }) => (
    <View style={styles.commentItem}>
      <FastImage source={{ uri: item.author.avatar }} style={styles.commentAvatar} />
      <View style={styles.commentContent}>
        <Text style={[styles.commentAuthor, { color: colors.text }]}>
          {item.author.nickname}
        </Text>
        <Text style={[styles.commentText, { color: colors.text }]}>
          {item.replyTo && (
            <Text style={{ color: colors.primary }}>@{item.replyTo.nickname} </Text>
          )}
          {item.content}
        </Text>
        <View style={styles.commentMeta}>
          <Text style={[styles.commentTime, { color: colors.textSecondary }]}>
            {formatTimeAgo(item.createdAt)}
          </Text>
          <TouchableOpacity onPress={() => handleReply(item.id, item.author.nickname)}>
            <Text style={[styles.replyButton, { color: colors.textSecondary }]}>回复</Text>
          </TouchableOpacity>
        </View>
        {/* 子评论 */}
        {item.replies && item.replies.length > 0 && (
          <View style={styles.repliesContainer}>
            {item.replies.map((reply: any) => (
              <View key={reply.id} style={styles.replyItem}>
                <FastImage source={{ uri: reply.author.avatar }} style={styles.replyAvatar} />
                <View style={styles.replyContent}>
                  <Text style={[styles.commentAuthor, { color: colors.text }]}>
                    {reply.author.nickname}
                  </Text>
                  <Text style={[styles.commentText, { color: colors.text }]}>
                    <Text style={{ color: colors.primary }}>@{reply.replyTo?.nickname} </Text>
                    {reply.content}
                  </Text>
                  <View style={styles.commentMeta}>
                    <Text style={[styles.commentTime, { color: colors.textSecondary }]}>
                      {formatTimeAgo(reply.createdAt)}
                    </Text>
                    <TouchableOpacity onPress={() => handleReply(reply.id, reply.author.nickname)}>
                      <Text style={[styles.replyButton, { color: colors.textSecondary }]}>回复</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            ))}
          </View>
        )}
      </View>
    </View>
  );

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: colors.background }]}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={0}
    >
      <SafeAreaView style={styles.safeArea}>
        {/* 顶部导航 */}
        <View style={[styles.header, { backgroundColor: colors.background }]}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
            <Text style={[styles.backButtonText, { color: colors.text }]}>←</Text>
          </TouchableOpacity>
          <Text style={[styles.headerTitle, { color: colors.text }]}>笔记详情</Text>
          <View style={styles.headerRight} />
        </View>

        <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
          {/* 图片轮播 */}
          {note.images.length > 0 && (
            <View>
              <FlatList
                data={note.images}
                horizontal
                pagingEnabled
                showsHorizontalScrollIndicator={false}
                onMomentumScrollEnd={(event) => {
                  const index = Math.round(
                    event.nativeEvent.contentOffset.x / SCREEN_WIDTH
                  );
                  setCurrentImageIndex(index);
                }}
                renderItem={({ item }) => (
                  <FastImage
                    source={{ uri: item }}
                    style={styles.noteImage}
                    resizeMode={FastImage.resizeMode.cover}
                  />
                )}
                keyExtractor={(_, index) => `img_${index}`}
              />
              {note.images.length > 1 && (
                <View style={styles.imageIndicator}>
                  <Text style={styles.imageIndicatorText}>
                    {currentImageIndex + 1} / {note.images.length}
                  </Text>
                </View>
              )}
            </View>
          )}

          {/* 作者信息 */}
          <View style={[styles.authorSection, { borderBottomColor: colors.border }]}>
            <TouchableOpacity onPress={handleAuthorPress} style={styles.authorAvatarContainer}>
              <FastImage source={{ uri: note.author.avatar }} style={styles.authorAvatar} />
            </TouchableOpacity>
            <TouchableOpacity onPress={handleAuthorPress} style={styles.authorInfo}>
              <Text style={[styles.authorName, { color: colors.text }]}>
                {note.author.nickname}
              </Text>
              <Text style={[styles.authorBio, { color: colors.textSecondary }]} numberOfLines={1}>
                {authorProfile?.bio || note.author.bio || ''}
              </Text>
              <Text style={[styles.authorFollowers, { color: colors.textSecondary }]}>
                {formatNumber(authorProfile?.followersCount ?? note.author.followersCount ?? 0)} 粉丝
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.followButton,
                {
                  backgroundColor: (authorProfile?.isFollowing ?? note.author.isFollowing)
                    ? colors.surface
                    : colors.primary,
                  borderColor: colors.border,
                },
              ]}
              onPress={handleFollow}
            >
              <Text
                style={[
                  styles.followButtonText,
                  {
                    color: (authorProfile?.isFollowing ?? note.author.isFollowing)
                      ? colors.text
                      : '#FFFFFF',
                  },
                ]}
              >
                {(authorProfile?.isFollowing ?? note.author.isFollowing) ? '已关注' : '+ 关注'}
              </Text>
            </TouchableOpacity>
          </View>

          {/* 笔记内容 */}
          <View style={styles.noteContentSection}>
            <Text style={[styles.noteTitle, { color: colors.text }]}>{note.title}</Text>
            <Text style={[styles.noteContent, { color: colors.text }]}>{note.content}</Text>
            {/* 标签 */}
            <View style={styles.tagsContainer}>
              {(note.tags || []).map((tag: any, index: number) => (
                <TouchableOpacity key={index} style={styles.tagItem}>
                  <Text style={{ color: colors.primary }}>
                    #{typeof tag === 'string' ? tag : tag.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            <Text style={[styles.noteTime, { color: colors.textSecondary }]}>
              {formatTimeAgo(note.createdAt)}
            </Text>
          </View>

          {/* 评论区 */}
          <View style={styles.commentsSection}>
            <Text style={[styles.commentsTitle, { color: colors.text }]}>
              评论 ({note.comments})
            </Text>
            {comments.length > 0 ? (
              comments.map((comment: any) => (
                <View key={comment.id}>{renderCommentItem({ item: comment })}</View>
              ))
            ) : (
              <View style={styles.emptyComments}>
                <Text style={[styles.emptyCommentsText, { color: colors.textSecondary }]}>
                  暂无评论，快来抢沙发吧~
                </Text>
              </View>
            )}
          </View>
        </ScrollView>

        {/* 底部互动栏 */}
        <View style={[styles.bottomBar, { backgroundColor: colors.surface, borderTopColor: colors.border }]}>
          {/* 评论输入框 */}
          <View style={[styles.commentInputContainer, { backgroundColor: colors.background }]}>
            <TextInput
              style={[styles.commentInput, { color: colors.text }]}
              placeholder={replyingTo ? `回复 ${replyingTo.userName}...` : '写评论...'}
              placeholderTextColor={colors.textSecondary}
              value={commentText}
              onChangeText={setCommentText}
              onSubmitEditing={handleSubmitComment}
              returnKeyType="send"
            />
            {replyingTo && (
              <TouchableOpacity
                onPress={() => {
                  setReplyingTo(null);
                  setCommentText('');
                }}
                style={styles.cancelReplyButton}
              >
                <Text style={{ color: colors.textSecondary, fontSize: 12 }}>取消</Text>
              </TouchableOpacity>
            )}
          </View>

          {/* 互动按钮 */}
          <View style={styles.actionButtons}>
            <TouchableOpacity style={styles.actionButton} onPress={handleLike}>
              <Text style={styles.actionIcon}>{note.isLiked ? '❤️' : '🤍'}</Text>
              <Text style={[styles.actionCount, { color: colors.textSecondary }]}>
                {formatNumber(note.likes)}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionButton} onPress={handleCollect}>
              <Text style={styles.actionIcon}>{note.isCollected ? '⭐' : '☆'}</Text>
              <Text style={[styles.actionCount, { color: colors.textSecondary }]}>
                {formatNumber(note.collects)}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionButton} onPress={handleShare}>
              <Text style={styles.actionIcon}>🔗</Text>
              <Text style={[styles.actionCount, { color: colors.textSecondary }]}>分享</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* 分享弹窗 */}
        <Modal
          visible={shareModalVisible}
          transparent
          animationType="slide"
          onRequestClose={() => setShareModalVisible(false)}
        >
          <TouchableOpacity
            style={styles.shareOverlay}
            activeOpacity={1}
            onPress={() => setShareModalVisible(false)}
          >
            <View style={[styles.shareSheet, { backgroundColor: colors.surface }]}>
              <View style={styles.shareHandle} />
              <Text style={[styles.shareTitle, { color: colors.text }]}>分享到</Text>
              <View style={styles.shareOptions}>
                <TouchableOpacity style={styles.shareOption} onPress={handleCopyLink}>
                  <View style={[styles.shareOptionIcon, { backgroundColor: '#F0F5FF' }]}>
                    <Text style={styles.shareOptionIconText}>🔗</Text>
                  </View>
                  <Text style={[styles.shareOptionLabel, { color: colors.text }]}>复制链接</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.shareOption} onPress={() => {
                  Alert.alert('提示', '分享到微信功能开发中');
                }}>
                  <View style={[styles.shareOptionIcon, { backgroundColor: '#F6FFED' }]}>
                    <Text style={styles.shareOptionIconText}>💬</Text>
                  </View>
                  <Text style={[styles.shareOptionLabel, { color: colors.text }]}>微信</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.shareOption} onPress={() => {
                  Alert.alert('提示', '分享到朋友圈功能开发中');
                }}>
                  <View style={[styles.shareOptionIcon, { backgroundColor: '#FFF7E6' }]}>
                    <Text style={styles.shareOptionIconText}>📱</Text>
                  </View>
                  <Text style={[styles.shareOptionLabel, { color: colors.text }]}>朋友圈</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.shareOption} onPress={() => {
                  Alert.alert('提示', '更多分享方式开发中');
                }}>
                  <View style={[styles.shareOptionIcon, { backgroundColor: '#FFF0F2' }]}>
                    <Text style={styles.shareOptionIconText}>⋯</Text>
                  </View>
                  <Text style={[styles.shareOptionLabel, { color: colors.text }]}>更多</Text>
                </TouchableOpacity>
              </View>
              <TouchableOpacity
                style={[styles.shareCancelButton, { backgroundColor: colors.background }]}
                onPress={() => setShareModalVisible(false)}
              >
                <Text style={[styles.shareCancelButtonText, { color: colors.text }]}>取消</Text>
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        </Modal>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
  },
  errorText: {
    fontSize: 16,
    marginBottom: 16,
  },
  retryButton: {
    paddingHorizontal: 32,
    paddingVertical: 10,
    borderRadius: 20,
  },
  retryButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#eee',
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
  },
  backButtonText: {
    fontSize: 24,
  },
  headerTitle: {
    fontSize: 17,
    fontWeight: '600',
  },
  headerRight: {
    width: 40,
  },
  scrollView: {
    flex: 1,
  },
  noteImage: {
    width: SCREEN_WIDTH,
    height: IMAGE_HEIGHT,
  },
  imageIndicator: {
    position: 'absolute',
    bottom: 12,
    right: 12,
    backgroundColor: 'rgba(0,0,0,0.5)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  imageIndicatorText: {
    color: '#FFFFFF',
    fontSize: 12,
  },
  authorSection: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  authorAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
  },
  authorAvatarContainer: {
    marginRight: 12,
  },
  authorInfo: {
    flex: 1,
  },
  authorName: {
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 2,
  },
  authorBio: {
    fontSize: 13,
    marginBottom: 2,
  },
  authorFollowers: {
    fontSize: 12,
  },
  followButton: {
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1,
  },
  followButtonText: {
    fontSize: 13,
    fontWeight: '500',
  },
  noteContentSection: {
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  noteTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  noteContent: {
    fontSize: 15,
    lineHeight: 24,
    marginBottom: 12,
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 8,
  },
  tagItem: {
    marginRight: 4,
  },
  noteTime: {
    fontSize: 12,
  },
  commentsSection: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  commentsTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
  },
  commentItem: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  commentAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    marginRight: 10,
  },
  commentContent: {
    flex: 1,
  },
  commentAuthor: {
    fontSize: 14,
    fontWeight: '500',
    marginBottom: 4,
  },
  commentText: {
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 4,
  },
  commentMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  commentTime: {
    fontSize: 12,
  },
  replyButton: {
    fontSize: 12,
  },
  repliesContainer: {
    marginTop: 8,
    paddingLeft: 4,
    borderLeftWidth: 2,
    borderLeftColor: '#eee',
  },
  replyItem: {
    flexDirection: 'row',
    marginBottom: 12,
  },
  replyAvatar: {
    width: 28,
    height: 28,
    borderRadius: 14,
    marginRight: 8,
  },
  replyContent: {
    flex: 1,
  },
  emptyComments: {
    paddingVertical: 32,
    alignItems: 'center',
  },
  emptyCommentsText: {
    fontSize: 14,
  },
  bottomBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderTopWidth: StyleSheet.hairlineWidth,
  },
  commentInputContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    height: 36,
    borderRadius: 18,
    paddingHorizontal: 12,
    marginRight: 12,
  },
  commentInput: {
    flex: 1,
    fontSize: 14,
    height: 36,
  },
  cancelReplyButton: {
    marginLeft: 8,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 16,
  },
  actionButton: {
    alignItems: 'center',
    minWidth: 44,
  },
  actionIcon: {
    fontSize: 20,
    textAlign: 'center',
  },
  actionCount: {
    fontSize: 10,
    marginTop: 2,
  },
  shareOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  shareSheet: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 20,
  },
  shareHandle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#E5E5E5',
    alignSelf: 'center',
    marginBottom: 16,
  },
  shareTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 20,
    textAlign: 'center',
  },
  shareOptions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 20,
  },
  shareOption: {
    alignItems: 'center',
    gap: 8,
  },
  shareOptionIcon: {
    width: 52,
    height: 52,
    borderRadius: 26,
    justifyContent: 'center',
    alignItems: 'center',
  },
  shareOptionIconText: {
    fontSize: 24,
  },
  shareOptionLabel: {
    fontSize: 12,
  },
  shareCancelButton: {
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  shareCancelButtonText: {
    fontSize: 16,
    fontWeight: '500',
  },
});
