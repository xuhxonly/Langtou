import React, { useCallback, useMemo } from 'react';
import { View, StyleSheet, SafeAreaView, ActivityIndicator } from 'react-native';
import { MasonryList } from '../../components/common/MasonryList';
import { useInfiniteFeed, useLikeNote, useCollectNote } from '../../hooks/useNotes';
import { useTheme } from '../../hooks/useTheme';
import type { Note } from '../../types';

interface HomeScreenProps {
  navigation?: any;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({ navigation }) => {
  const { colors } = useTheme();
  const {
    data,
    isLoading,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    refetch,
    isRefetching,
  } = useInfiniteFeed();
  const likeMutation = useLikeNote();
  const collectMutation = useCollectNote();

  // 将所有分页数据合并为一个 Note 数组
  const allNotes = useMemo(() => {
    if (!data?.pages) return [];
    return data.pages.flatMap((page) => page.list);
  }, [data?.pages]);

  const handleRefresh = useCallback(async () => {
    await refetch();
  }, [refetch]);

  const handleLoadMore = useCallback(() => {
    if (hasNextPage && !isFetchingNextPage) {
      fetchNextPage();
    }
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  const handleNotePress = useCallback(
    (note: Note) => {
      navigation?.navigate('NoteDetail', { noteId: note.id });
    },
    [navigation]
  );

  const handleLikePress = useCallback(
    (noteId: string) => {
      const note = allNotes.find((n) => n.id === noteId);
      if (note) {
        likeMutation.mutate({ noteId, isLiked: note.isLiked ?? false });
      }
    },
    [allNotes, likeMutation]
  );

  if (isLoading && allNotes.length === 0) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        {/* Header content can be added here */}
      </View>
      <MasonryList
        data={allNotes}
        onRefresh={handleRefresh}
        onLoadMore={handleLoadMore}
        refreshing={isRefetching}
        loadingMore={isFetchingNextPage}
        onNotePress={handleNotePress}
        onLikePress={handleLikePress}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
});
