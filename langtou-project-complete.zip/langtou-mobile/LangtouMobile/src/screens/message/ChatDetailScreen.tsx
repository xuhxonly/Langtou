import React, { useState, useCallback, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  SafeAreaView,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Alert,
} from 'react-native';
import FastImage from 'react-native-fast-image';
import { useTheme } from '../../hooks/useTheme';
import { useAuthStore } from '../../store/useAuthStore';
import { useChatMessages, useSendMessage, useMarkConversationRead } from '../../hooks/useChat';
import { formatTimeAgo } from '../../utils/format';
import type { Message } from '../../types';

interface ChatDetailScreenProps {
  route: { params: { userId: string; nickname: string; avatar: string } };
  navigation: any;
}

export const ChatDetailScreen: React.FC<ChatDetailScreenProps> = ({ route, navigation }) => {
  const { colors } = useTheme();
  const { user: currentUser } = useAuthStore();
  const { userId, nickname, avatar } = route.params;
  const [messageText, setMessageText] = useState('');
  const [allMessages, setAllMessages] = useState<Message[]>([]);
  const [page, setPage] = useState(1);
  const flatListRef = useRef<FlatList>(null);

  const {
    data: messagesData,
    isLoading,
    refetch,
  } = useChatMessages(userId, page);

  const sendMessageMutation = useSendMessage();
  const markReadMutation = useMarkConversationRead();

  // 合并消息列表
  useEffect(() => {
    if (messagesData) {
      setAllMessages((prev) =>
        page === 1 ? messagesData.list : [...messagesData.list.reverse(), ...prev]
      );
    }
  }, [messagesData, page]);

  // 标记已读
  useEffect(() => {
    if (userId) {
      markReadMutation.mutate(userId);
    }
  }, [userId]);

  // 滚动到底部
  useEffect(() => {
    if (allMessages.length > 0) {
      setTimeout(() => {
        flatListRef.current?.scrollToEnd({ animated: false });
      }, 100);
    }
  }, [allMessages.length]);

  const handleSend = useCallback(() => {
    if (!messageText.trim()) return;

    const optimisticMessage: Message = {
      id: `msg_${Date.now()}`,
      conversationId: '',
      senderId: currentUser?.id || 'current_user',
      content: messageText.trim(),
      type: 'text',
      createdAt: new Date().toISOString(),
      isRead: false,
    };

    setAllMessages((prev) => [...prev, optimisticMessage]);
    setMessageText('');

    sendMessageMutation.mutate(
      {
        receiverId: userId,
        content: messageText.trim(),
        type: 'text',
      },
      {
        onError: () => {
          Alert.alert('发送失败', '消息发送失败，请稍后重试');
        },
      }
    );
  }, [messageText, userId, currentUser, sendMessageMutation]);

  const handleLoadMore = useCallback(() => {
    if (!isLoading && messagesData?.hasMore) {
      setPage((prev) => prev + 1);
    }
  }, [isLoading, messagesData]);

  const isOwnMessage = (message: Message) =>
    message.senderId === currentUser?.id || message.senderId === 'current_user';

  const renderMessageItem = ({ item }: { item: Message }) => {
    const own = isOwnMessage(item);
    return (
      <View style={[styles.messageRow, own ? styles.ownRow : styles.otherRow]}>
        {!own && (
          <FastImage source={{ uri: avatar }} style={styles.messageAvatar} />
        )}
        <View
          style={[
            styles.messageBubble,
            own
              ? [styles.ownBubble, { backgroundColor: colors.primary }]
              : [styles.otherBubble, { backgroundColor: colors.surface }],
          ]}
        >
          {item.type === 'image' ? (
            <FastImage
              source={{ uri: item.content }}
              style={styles.imageMessage}
              resizeMode={FastImage.resizeMode.cover}
            />
          ) : (
            <Text
              style={[
                styles.messageText,
                { color: own ? '#FFFFFF' : colors.text },
              ]}
            >
              {item.content}
            </Text>
          )}
          <Text
            style={[
              styles.messageTime,
              { color: own ? 'rgba(255,255,255,0.7)' : colors.textSecondary },
            ]}
          >
            {formatTimeAgo(item.createdAt)}
          </Text>
        </View>
        {own && (
          <FastImage
            source={{ uri: currentUser?.avatar || '' }}
            style={styles.messageAvatar}
          />
        )}
      </View>
    );
  };

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: colors.background }]}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <SafeAreaView style={styles.safeArea}>
        {/* 顶部导航 */}
        <View style={[styles.header, { backgroundColor: colors.background }]}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
            <Text style={[styles.backButtonText, { color: colors.text }]}>←</Text>
          </TouchableOpacity>
          <Text style={[styles.headerTitle, { color: colors.text }]}>{nickname}</Text>
          <View style={styles.headerRight} />
        </View>

        {/* 消息列表 */}
        {isLoading && allMessages.length === 0 ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={colors.primary} />
          </View>
        ) : (
          <FlatList
            ref={flatListRef}
            data={allMessages}
            renderItem={renderMessageItem}
            keyExtractor={(item) => item.id}
            showsVerticalScrollIndicator={false}
            onEndReached={handleLoadMore}
            onEndReachedThreshold={0.5}
            inverted={false}
            contentContainerStyle={styles.messagesList}
            ListEmptyComponent={
              <View style={styles.emptyContainer}>
                <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
                  开始和 {nickname} 聊天吧~
                </Text>
              </View>
            }
          />
        )}

        {/* 底部输入栏 */}
        <View style={[styles.inputBar, { backgroundColor: colors.surface, borderTopColor: colors.border }]}>
          <TextInput
            style={[styles.input, { color: colors.text, backgroundColor: colors.background }]}
            placeholder="发送消息..."
            placeholderTextColor={colors.textSecondary}
            value={messageText}
            onChangeText={setMessageText}
            onSubmitEditing={handleSend}
            returnKeyType="send"
            multiline
            maxLength={500}
          />
          <TouchableOpacity
            style={[
              styles.sendButton,
              {
                backgroundColor: messageText.trim() ? colors.primary : colors.border,
              },
            ]}
            onPress={handleSend}
            disabled={!messageText.trim() || sendMessageMutation.isPending}
          >
            <Text style={styles.sendButtonText}>发送</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#eee',
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
  },
  backButtonText: {
    fontSize: 24,
  },
  headerTitle: {
    fontSize: 17,
    fontWeight: '600',
  },
  headerRight: {
    width: 40,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  messagesList: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  messageRow: {
    flexDirection: 'row',
    marginBottom: 12,
    alignItems: 'flex-end',
  },
  ownRow: {
    justifyContent: 'flex-end',
  },
  otherRow: {
    justifyContent: 'flex-start',
  },
  messageAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
  },
  messageBubble: {
    maxWidth: '65%',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 16,
    marginHorizontal: 8,
  },
  ownBubble: {
    borderBottomRightRadius: 4,
  },
  otherBubble: {
    borderBottomLeftRadius: 4,
  },
  messageText: {
    fontSize: 15,
    lineHeight: 22,
  },
  imageMessage: {
    width: 200,
    height: 200,
    borderRadius: 8,
  },
  messageTime: {
    fontSize: 11,
    marginTop: 4,
    textAlign: 'right',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 100,
  },
  emptyText: {
    fontSize: 14,
  },
  inputBar: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderTopWidth: StyleSheet.hairlineWidth,
    gap: 8,
  },
  input: {
    flex: 1,
    fontSize: 15,
    maxHeight: 100,
    minHeight: 40,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  sendButton: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    height: 40,
  },
  sendButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '500',
  },
});
