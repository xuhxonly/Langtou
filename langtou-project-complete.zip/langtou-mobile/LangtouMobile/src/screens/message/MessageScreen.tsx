import React, { useState, useCallback, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  SafeAreaView,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import FastImage from 'react-native-fast-image';
import { useTheme } from '../../hooks/useTheme';
import { formatTimeAgo } from '../../utils/format';
import { useAuthStore, useWebSocketStore } from '../../store';
import { getNotifications, getUnreadCount, markAllRead } from '../../api/message';
import { WSConnectionState } from '../../api/websocket';
import { ChatListScreen } from './ChatListScreen';
import type { Notification, UnreadCount } from '../../types';

const NOTIFICATION_ICONS: Record<string, string> = {
  like: '❤️',
  comment: '💬',
  follow: '👤',
  collect: '⭐',
  system: '🔔',
};

interface MessageScreenProps {
  navigation?: any;
}

export const MessageScreen: React.FC<MessageScreenProps> = ({ navigation }) => {
  const { colors } = useTheme();
  const { isAuthenticated } = useAuthStore();
  const { connectionState, connect, disconnect, notifications: wsNotifications } = useWebSocketStore();
  const [activeSubTab, setActiveSubTab] = useState<'chat' | 'notification'>('chat');

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={[styles.headerTitle, { color: colors.text }]}>消息</Text>
      </View>

      {/* 聊天/通知 子Tab */}
      <View style={[styles.subTabBar, { borderBottomColor: colors.border }]}>
        <TouchableOpacity
          style={[
            styles.subTab,
            activeSubTab === 'chat' && { borderBottomColor: colors.primary },
          ]}
          onPress={() => setActiveSubTab('chat')}
        >
          <Text style={{ color: activeSubTab === 'chat' ? colors.primary : colors.textSecondary, fontWeight: activeSubTab === 'chat' ? '600' : '400' }}>
            聊天
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.subTab,
            activeSubTab === 'notification' && { borderBottomColor: colors.primary },
          ]}
          onPress={() => setActiveSubTab('notification')}
        >
          <Text style={{ color: activeSubTab === 'notification' ? colors.primary : colors.textSecondary, fontWeight: activeSubTab === 'notification' ? '600' : '400' }}>
            通知
          </Text>
        </TouchableOpacity>
      </View>

      {activeSubTab === 'chat' ? (
        <ChatListScreen navigation={navigation} />
      ) : (
        <NotificationList navigation={navigation} />
      )}
    </SafeAreaView>
  );
};

// ============ 通知列表子组件 ============

interface NotificationListProps {
  navigation?: any;
}

const NotificationList: React.FC<NotificationListProps> = ({ navigation }) => {
  const { colors } = useTheme();
  const { isAuthenticated } = useAuthStore();
  const { connectionState, connect, disconnect, notifications: wsNotifications } = useWebSocketStore();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadInfo, setUnreadInfo] = useState<UnreadCount>({
    total: 0,
    likes: 0,
    comments: 0,
    follows: 0,
    system: 0,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState<'all' | 'like' | 'comment' | 'follow' | 'system'>('all');

  // 登录后连接 WebSocket
  useEffect(() => {
    if (isAuthenticated && connectionState === WSConnectionState.DISCONNECTED) {
      connect();
    }
    return () => {
      if (!isAuthenticated) {
        disconnect();
      }
    };
  }, [isAuthenticated, connectionState, connect, disconnect]);

  // 合并 WebSocket 推送的通知和 API 拉取的通知
  useEffect(() => {
    if (wsNotifications.length > 0) {
      setNotifications((prev) => {
        const existingIds = new Set(prev.map((n) => n.id));
        const newNotifications = wsNotifications.filter((n) => !existingIds.has(n.id));
        return [...newNotifications, ...prev];
      });
    }
  }, [wsNotifications]);

  const loadNotifications = useCallback(async () => {
    try {
      setIsLoading(true);
      const [notificationsRes, unreadRes] = await Promise.all([
        getNotifications(),
        getUnreadCount(),
      ]);
      setNotifications(notificationsRes.list);
      setUnreadInfo(unreadRes);
    } catch (err) {
      console.error('Failed to load notifications:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  React.useEffect(() => {
    if (isAuthenticated) {
      loadNotifications();
    } else {
      setIsLoading(false);
    }
  }, [loadNotifications, isAuthenticated]);

  const handleRefresh = useCallback(async () => {
    if (!isAuthenticated) return;
    setIsRefreshing(true);
    await loadNotifications();
    setIsRefreshing(false);
  }, [loadNotifications, isAuthenticated]);

  const handleMarkAllRead = useCallback(async () => {
    if (!isAuthenticated) return;
    try {
      await markAllRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
      setUnreadInfo({ total: 0, likes: 0, comments: 0, follows: 0, system: 0 });
    } catch (err) {
      console.error('Failed to mark all read:', err);
    }
  }, [isAuthenticated]);

  const handleNotificationPress = useCallback(
    (notification: Notification) => {
      if (!notification.isRead) {
        setNotifications((prev) =>
          prev.map((n) => (n.id === notification.id ? { ...n, isRead: true } : n))
        );
        setUnreadInfo((prev) => ({
          ...prev,
          total: Math.max(0, prev.total - 1),
        }));
      }
      if (notification.note && notification.type !== 'follow' && notification.type !== 'system') {
        navigation?.navigate('NoteDetail', { noteId: notification.note.id });
      }
    },
    [navigation]
  );

  const filteredNotifications = notifications.filter((n) => {
    if (activeTab === 'like') return n.type === 'like';
    if (activeTab === 'comment') return n.type === 'comment';
    if (activeTab === 'follow') return n.type === 'follow';
    if (activeTab === 'system') return n.type === 'system';
    return true;
  });

  const renderItem = ({ item }: { item: Notification }) => (
    <TouchableOpacity
      style={[
        styles.notificationItem,
        { backgroundColor: colors.surface, borderBottomColor: colors.border },
        !item.isRead && styles.unreadItem,
      ]}
      onPress={() => handleNotificationPress(item)}
    >
      <View style={styles.iconContainer}>
        <Text style={styles.icon}>{NOTIFICATION_ICONS[item.type]}</Text>
      </View>
      <FastImage source={{ uri: item.fromUser.avatar }} style={styles.avatar} />
      <View style={styles.content}>
        <Text style={[styles.title, { color: colors.text }]}>
          <Text style={styles.bold}>{item.fromUser.nickname}</Text>
          {item.type === 'like' && ' 赞了你的笔记'}
          {item.type === 'comment' && ' 评论了你'}
          {item.type === 'follow' && ' 关注了你'}
          {item.type === 'collect' && ' 收藏了你的笔记'}
          {item.type === 'system' && ' 系统通知'}
        </Text>
        {item.content && (
          <Text style={[styles.subtitle, { color: colors.textSecondary }]} numberOfLines={1}>
            {item.content}
          </Text>
        )}
        <Text style={[styles.time, { color: colors.textSecondary }]}>
          {formatTimeAgo(item.createdAt)}
        </Text>
      </View>
      {!item.isRead && <View style={styles.unreadDot} />}
    </TouchableOpacity>
  );

  const getConnectionStatusText = () => {
    switch (connectionState) {
      case WSConnectionState.CONNECTED:
        return null;
      case WSConnectionState.CONNECTING:
      case WSConnectionState.RECONNECTING:
        return '连接中...';
      case WSConnectionState.DISCONNECTED:
        return '未连接';
      default:
        return null;
    }
  };

  const connectionStatusText = getConnectionStatusText();

  if (!isAuthenticated) {
    return (
      <View style={styles.unauthenticatedContainer}>
        <Text style={[styles.unauthenticatedText, { color: colors.textSecondary }]}>
          登录后查看消息
        </Text>
        <TouchableOpacity
          style={[styles.loginButton, { backgroundColor: colors.primary }]}
          onPress={() => navigation?.navigate('Login')}
        >
          <Text style={styles.loginButtonText}>立即登录</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={styles.notificationContainer}>
      {/* 通知类型Tab */}
      <View style={styles.notificationHeader}>
        <View style={styles.headerRight}>
          {connectionStatusText && (
            <Text style={[styles.connectionStatus, { color: colors.textSecondary }]}>
              {connectionStatusText}
            </Text>
          )}
          {unreadInfo.total > 0 && (
            <TouchableOpacity onPress={handleMarkAllRead}>
              <Text style={{ color: colors.primary, fontSize: 14 }}>全部已读</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      <View style={[styles.typeTabBar, { borderBottomColor: colors.border }]}>
        {[
          { key: 'all' as const, label: '全部', count: unreadInfo.total },
          { key: 'like' as const, label: '点赞', count: unreadInfo.likes },
          { key: 'comment' as const, label: '评论', count: unreadInfo.comments },
          { key: 'follow' as const, label: '关注', count: unreadInfo.follows },
          { key: 'system' as const, label: '系统', count: unreadInfo.system },
        ].map((tab) => (
          <TouchableOpacity
            key={tab.key}
            style={[
              styles.typeTab,
              activeTab === tab.key && { borderBottomColor: colors.primary },
            ]}
            onPress={() => setActiveTab(tab.key)}
          >
            <Text style={{ color: activeTab === tab.key ? colors.primary : colors.textSecondary, fontSize: 13 }}>
              {tab.label}
            </Text>
            {tab.count > 0 && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{tab.count > 99 ? '99+' : tab.count}</Text>
              </View>
            )}
          </TouchableOpacity>
        ))}
      </View>

      {/* 通知列表 */}
      <FlatList
        data={filteredNotifications}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary}
          />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
              暂无消息
            </Text>
          </View>
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  subTabBar: {
    flexDirection: 'row',
    borderBottomWidth: 1,
  },
  subTab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  notificationContainer: {
    flex: 1,
  },
  notificationHeader: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  connectionStatus: {
    fontSize: 12,
  },
  typeTabBar: {
    flexDirection: 'row',
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  typeTab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 4,
  },
  badge: {
    backgroundColor: '#FF2442',
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '500',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  unauthenticatedContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
  },
  unauthenticatedText: {
    fontSize: 16,
    marginBottom: 24,
  },
  loginButton: {
    paddingHorizontal: 48,
    paddingVertical: 12,
    borderRadius: 24,
  },
  loginButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  notificationItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  unreadItem: {
    backgroundColor: 'rgba(255, 36, 66, 0.05)',
  },
  unreadDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#FF2442',
    marginLeft: 8,
  },
  iconContainer: {
    marginRight: 8,
  },
  icon: {
    fontSize: 20,
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    marginRight: 12,
  },
  content: {
    flex: 1,
  },
  title: {
    fontSize: 14,
    lineHeight: 20,
  },
  bold: {
    fontWeight: '600',
  },
  subtitle: {
    fontSize: 13,
    marginTop: 2,
  },
  time: {
    fontSize: 12,
    marginTop: 4,
  },
  emptyContainer: {
    paddingVertical: 60,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 14,
  },
});
