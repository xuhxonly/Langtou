import React, { useState, useCallback, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  FlatList,
  TouchableOpacity,
  SafeAreaView,
  ActivityIndicator,
} from 'react-native';
import FastImage from 'react-native-fast-image';
import { useTheme } from '../../hooks/useTheme';
import { NoteCard } from '../../components/common/NoteCard';
import { useSearchNotes, useHotTags } from '../../hooks/useNotes';
import { useSearchUsers } from '../../hooks/useUser';
import { Storage } from '../../utils/storage';
import type { Note, User } from '../../types';

interface SearchResultScreenProps {
  route: { params: { keyword: string } };
  navigation: any;
}

const SEARCH_HISTORY_KEY = '@search_history';
const MAX_HISTORY = 20;

export const SearchResultScreen: React.FC<SearchResultScreenProps> = ({ route, navigation }) => {
  const { colors } = useTheme();
  const { keyword: initialKeyword } = route.params;
  const [keyword, setKeyword] = useState(initialKeyword);
  const [activeTab, setActiveTab] = useState<'all' | 'notes' | 'users'>('all');
  const [searchHistory, setSearchHistory] = useState<string[]>([]);

  const {
    data: searchNotesData,
    isLoading: notesSearchLoading,
    isFetching: notesFetching,
  } = useSearchNotes(keyword);
  const {
    data: searchUsersData,
    isLoading: usersSearchLoading,
  } = useSearchUsers(keyword);

  // 加载搜索历史
  useEffect(() => {
    loadSearchHistory();
    saveSearchHistory(initialKeyword);
  }, []);

  const loadSearchHistory = async () => {
    try {
      const history = await Storage.get(SEARCH_HISTORY_KEY);
      if (history) {
        setSearchHistory(JSON.parse(history));
      }
    } catch {
      // ignore
    }
  };

  const saveSearchHistory = async (term: string) => {
    if (!term.trim()) return;
    try {
      const updated = [term, ...searchHistory.filter((h) => h !== term)].slice(0, MAX_HISTORY);
      setSearchHistory(updated);
      await Storage.set(SEARCH_HISTORY_KEY, JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  const handleClearHistory = useCallback(async () => {
    setSearchHistory([]);
    try {
      await Storage.remove(SEARCH_HISTORY_KEY);
    } catch {
      // ignore
    }
  }, []);

  const handleSearch = useCallback((term: string) => {
    if (term.trim()) {
      setKeyword(term.trim());
      saveSearchHistory(term.trim());
    }
  }, []);

  const handleNotePress = useCallback(
    (note: Note) => {
      navigation.navigate('NoteDetail', { noteId: note.id });
    },
    [navigation]
  );

  const handleUserPress = useCallback(
    (user: User) => {
      navigation.navigate('UserProfile', { userId: user.id });
    },
    [navigation]
  );

  const isLoading = notesSearchLoading || notesFetching || usersSearchLoading;

  const renderSearchHistory = () => (
    <View style={styles.historyContainer}>
      <View style={styles.historyHeader}>
        <Text style={[styles.historyTitle, { color: colors.text }]}>搜索历史</Text>
        <TouchableOpacity onPress={handleClearHistory}>
          <Text style={{ color: colors.textSecondary, fontSize: 13 }}>清除</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.historyTags}>
        {searchHistory.map((term) => (
          <TouchableOpacity
            key={term}
            style={[styles.historyTag, { backgroundColor: colors.surface }]}
            onPress={() => handleSearch(term)}
          >
            <Text style={[styles.historyTagText, { color: colors.text }]}>{term}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  const renderSearchResults = () => (
    <View style={styles.resultsContainer}>
      {/* Tab切换 */}
      <View style={[styles.tabBar, { borderBottomColor: colors.border }]}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'all' && styles.activeTab]}
          onPress={() => setActiveTab('all')}
        >
          <Text
            style={[
              styles.tabText,
              {
                color: activeTab === 'all' ? colors.primary : colors.textSecondary,
                fontWeight: activeTab === 'all' ? '600' : '400',
              },
            ]}
          >
            综合
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'notes' && styles.activeTab]}
          onPress={() => setActiveTab('notes')}
        >
          <Text
            style={[
              styles.tabText,
              {
                color: activeTab === 'notes' ? colors.primary : colors.textSecondary,
                fontWeight: activeTab === 'notes' ? '600' : '400',
              },
            ]}
          >
            笔记
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'users' && styles.activeTab]}
          onPress={() => setActiveTab('users')}
        >
          <Text
            style={[
              styles.tabText,
              {
                color: activeTab === 'users' ? colors.primary : colors.textSecondary,
                fontWeight: activeTab === 'users' ? '600' : '400',
              },
            ]}
          >
            用户
          </Text>
        </TouchableOpacity>
      </View>

      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : activeTab === 'users' ? (
        <FlatList
          data={searchUsersData || []}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={[styles.userItem, { borderBottomColor: colors.border }]}
              onPress={() => handleUserPress(item)}
            >
              <FastImage source={{ uri: item.avatar }} style={styles.userAvatar} />
              <View style={styles.userInfo}>
                <Text style={[styles.userName, { color: colors.text }]}>{item.nickname}</Text>
                <Text style={[styles.userBio, { color: colors.textSecondary }]} numberOfLines={1}>
                  {item.bio || '这个人很懒，什么都没写~'}
                </Text>
              </View>
              <Text style={[styles.userFollowers, { color: colors.textSecondary }]}>
                {item.followersCount ?? 0} 粉丝
              </Text>
            </TouchableOpacity>
          )}
          keyExtractor={(item) => item.id}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
                没有找到相关用户
              </Text>
            </View>
          }
        />
      ) : (
        <FlatList
          data={searchNotesData?.list || []}
          renderItem={({ item }) => <NoteCard note={item} onPress={handleNotePress} />}
          keyExtractor={(item) => item.id}
          numColumns={2}
          contentContainerStyle={styles.resultsList}
          columnWrapperStyle={styles.columnWrapper}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
                没有找到相关笔记
              </Text>
            </View>
          }
        />
      )}
    </View>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      {/* 搜索栏 */}
      <View style={styles.searchContainer}>
        <View style={[styles.searchInputWrapper, { backgroundColor: colors.surface }]}>
          <TextInput
            style={[styles.searchInput, { color: colors.text }]}
            placeholder="搜索感兴趣的内容"
            placeholderTextColor={colors.textSecondary}
            value={keyword}
            onChangeText={setKeyword}
            onSubmitEditing={() => handleSearch(keyword)}
            returnKeyType="search"
            autoFocus
          />
          {keyword.length > 0 && (
            <TouchableOpacity
              onPress={() => setKeyword('')}
              style={styles.clearButton}
            >
              <Text style={{ color: colors.textSecondary, fontSize: 16 }}>×</Text>
            </TouchableOpacity>
          )}
        </View>
        <TouchableOpacity onPress={() => handleSearch(keyword)} style={styles.searchButton}>
          <Text style={{ color: colors.primary, fontSize: 15, fontWeight: '500' }}>搜索</Text>
        </TouchableOpacity>
      </View>

      {/* 搜索历史（仅在未搜索时显示） */}
      {searchHistory.length > 0 && !searchNotesData && !searchUsersData && (
        renderSearchHistory()
      )}

      {/* 搜索结果 */}
      {(searchNotesData || searchUsersData) && renderSearchResults()}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 8,
  },
  searchInputWrapper: {
    flex: 1,
    height: 40,
    borderRadius: 20,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    height: 40,
  },
  clearButton: {
    paddingHorizontal: 4,
  },
  searchButton: {
    paddingHorizontal: 8,
    paddingVertical: 8,
  },
  historyContainer: {
    paddingHorizontal: 16,
    paddingTop: 12,
  },
  historyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  historyTitle: {
    fontSize: 16,
    fontWeight: '600',
  },
  historyTags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  historyTag: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 16,
  },
  historyTagText: {
    fontSize: 14,
  },
  resultsContainer: {
    flex: 1,
  },
  tabBar: {
    flexDirection: 'row',
    borderBottomWidth: 1,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: '#FF2442',
  },
  tabText: {
    fontSize: 15,
  },
  loadingContainer: {
    paddingVertical: 40,
    alignItems: 'center',
  },
  resultsList: {
    padding: 8,
  },
  columnWrapper: {
    justifyContent: 'space-between',
    paddingHorizontal: 8,
  },
  emptyContainer: {
    paddingVertical: 60,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 14,
  },
  userItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  userAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    marginRight: 12,
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 15,
    fontWeight: '500',
    marginBottom: 4,
  },
  userBio: {
    fontSize: 13,
  },
  userFollowers: {
    fontSize: 12,
    marginLeft: 8,
  },
});
