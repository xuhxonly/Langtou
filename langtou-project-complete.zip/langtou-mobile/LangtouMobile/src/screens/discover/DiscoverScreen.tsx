import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  FlatList,
  TouchableOpacity,
  SafeAreaView,
  ActivityIndicator,
} from 'react-native';
import FastImage from 'react-native-fast-image';
import { useTheme } from '../../hooks/useTheme';
import { NoteCard } from '../../components/common/NoteCard';
import { useSearchNotes, useHotTags } from '../../hooks/useNotes';
import { useSearchUsers } from '../../hooks/useUser';
import type { Note, User } from '../../types';

interface DiscoverScreenProps {
  navigation?: any;
}

export const DiscoverScreen: React.FC<DiscoverScreenProps> = ({ navigation }) => {
  const { colors } = useTheme();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'notes' | 'users'>('notes');
  const [hasSearched, setHasSearched] = useState(false);

  const { data: hotTagsData, isLoading: tagsLoading } = useHotTags();
  const {
    data: searchNotesData,
    isLoading: notesSearchLoading,
    isFetching: notesFetching,
  } = useSearchNotes(searchQuery);
  const {
    data: searchUsersData,
    isLoading: usersSearchLoading,
  } = useSearchUsers(searchQuery);

  const hotTags = hotTagsData || [];

  const handleSearch = useCallback(() => {
    if (searchQuery.trim()) {
      setHasSearched(true);
      navigation?.navigate('SearchResult', { keyword: searchQuery.trim() });
    }
  }, [searchQuery, navigation]);

  const handleHotSearch = useCallback((term: string) => {
    setSearchQuery(term);
    setHasSearched(true);
  }, []);

  const handleTagSearch = useCallback((tagName: string) => {
    setSearchQuery(tagName);
    setHasSearched(true);
  }, []);

  const handleNotePress = useCallback(
    (note: Note) => {
      navigation?.navigate('NoteDetail', { noteId: note.id });
    },
    [navigation]
  );

  const handleUserPress = useCallback(
    (user: User) => {
      navigation?.navigate('UserProfile', { userId: user.id });
    },
    [navigation]
  );

  const isLoading = hasSearched
    ? activeTab === 'notes'
      ? notesSearchLoading || notesFetching
      : usersSearchLoading
    : tagsLoading;

  const renderHotTags = () => (
    <View style={styles.hotSearchContainer}>
      <Text style={[styles.sectionTitle, { color: colors.text }]}>热门搜索</Text>
      <View style={styles.tagsContainer}>
        {hotTags.map((tag) => (
          <TouchableOpacity
            key={tag.id}
            style={[styles.tag, { backgroundColor: colors.surface }]}
            onPress={() => handleTagSearch(tag.name)}
          >
            <Text style={[styles.tagText, { color: colors.text }]}>
              {tag.isHot && <Text style={{ color: '#FF2442' }}>🔥 </Text>}
              {tag.name}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* 兜底：如果API没返回热门标签，显示默认热门搜索 */}
      {hotTags.length === 0 && !tagsLoading && (
        <View style={styles.defaultHotContainer}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>热门搜索</Text>
          <View style={styles.tagsContainer}>
            {['夏日穿搭', '减脂餐', '杭州旅游', '口红试色', '独居生活'].map((term) => (
              <TouchableOpacity
                key={term}
                style={[styles.tag, { backgroundColor: colors.surface }]}
                onPress={() => handleHotSearch(term)}
              >
                <Text style={[styles.tagText, { color: colors.text }]}>{term}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )}
    </View>
  );

  const renderSearchResults = () => (
    <View style={styles.resultsContainer}>
      {/* Tab切换 */}
      <View style={[styles.tabBar, { borderBottomColor: colors.border }]}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'notes' && styles.activeTab]}
          onPress={() => setActiveTab('notes')}
        >
          <Text
            style={[
              styles.tabText,
              {
                color: activeTab === 'notes' ? colors.primary : colors.textSecondary,
                fontWeight: activeTab === 'notes' ? '600' : '400',
              },
            ]}
          >
            笔记
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'users' && styles.activeTab]}
          onPress={() => setActiveTab('users')}
        >
          <Text
            style={[
              styles.tabText,
              {
                color: activeTab === 'users' ? colors.primary : colors.textSecondary,
                fontWeight: activeTab === 'users' ? '600' : '400',
              },
            ]}
          >
            用户
          </Text>
        </TouchableOpacity>
      </View>

      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : activeTab === 'notes' ? (
        <FlatList
          data={searchNotesData?.list || []}
          renderItem={({ item }) => <NoteCard note={item} onPress={handleNotePress} />}
          keyExtractor={(item) => item.id}
          numColumns={2}
          contentContainerStyle={styles.resultsList}
          columnWrapperStyle={styles.columnWrapper}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
                没有找到相关笔记
              </Text>
            </View>
          }
        />
      ) : (
        <FlatList
          data={searchUsersData || []}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={[styles.userItem, { borderBottomColor: colors.border }]}
              onPress={() => handleUserPress(item)}
            >
              <FastImage source={{ uri: item.avatar }} style={styles.userAvatar} />
              <View style={styles.userInfo}>
                <Text style={[styles.userName, { color: colors.text }]}>{item.nickname}</Text>
                <Text style={[styles.userBio, { color: colors.textSecondary }]} numberOfLines={1}>
                  {item.bio || '这个人很懒，什么都没写~'}
                </Text>
              </View>
              <Text style={[styles.userFollowers, { color: colors.textSecondary }]}>
                {item.followersCount ?? 0} 粉丝
              </Text>
            </TouchableOpacity>
          )}
          keyExtractor={(item) => item.id}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
                没有找到相关用户
              </Text>
            </View>
          }
        />
      )}
    </View>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.searchContainer}>
        <View style={[styles.searchInputWrapper, { backgroundColor: colors.surface }]}>
          <TextInput
            style={[styles.searchInput, { color: colors.text }]}
            placeholder="搜索感兴趣的内容"
            placeholderTextColor={colors.textSecondary}
            value={searchQuery}
            onChangeText={setSearchQuery}
            onSubmitEditing={handleSearch}
            returnKeyType="search"
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity
              onPress={() => {
                setSearchQuery('');
                setHasSearched(false);
              }}
              style={styles.clearButton}
            >
              <Text style={{ color: colors.textSecondary, fontSize: 16 }}>×</Text>
            </TouchableOpacity>
          )}
        </View>
        <TouchableOpacity onPress={handleSearch} style={styles.searchButton}>
          <Text style={{ color: colors.primary, fontSize: 15, fontWeight: '500' }}>搜索</Text>
        </TouchableOpacity>
      </View>

      {!hasSearched ? renderHotTags() : renderSearchResults()}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 8,
  },
  searchInputWrapper: {
    flex: 1,
    height: 40,
    borderRadius: 20,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    height: 40,
  },
  clearButton: {
    paddingHorizontal: 4,
  },
  searchButton: {
    paddingHorizontal: 8,
    paddingVertical: 8,
  },
  hotSearchContainer: {
    paddingHorizontal: 16,
    paddingTop: 20,
  },
  defaultHotContainer: {
    marginTop: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  tag: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 16,
  },
  tagText: {
    fontSize: 14,
  },
  resultsContainer: {
    flex: 1,
  },
  tabBar: {
    flexDirection: 'row',
    borderBottomWidth: 1,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: '#FF2442',
  },
  tabText: {
    fontSize: 15,
  },
  loadingContainer: {
    paddingVertical: 40,
    alignItems: 'center',
  },
  resultsList: {
    padding: 8,
  },
  columnWrapper: {
    justifyContent: 'space-between',
    paddingHorizontal: 8,
  },
  emptyContainer: {
    paddingVertical: 60,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 14,
  },
  userItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  userAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    marginRight: 12,
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 15,
    fontWeight: '500',
    marginBottom: 4,
  },
  userBio: {
    fontSize: 13,
  },
  userFollowers: {
    fontSize: 12,
    marginLeft: 8,
  },
});
