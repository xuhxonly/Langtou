import React, { useEffect, useRef } from 'react';
import { View, StyleSheet, Animated, type ViewStyle } from 'react-native';
import { useTheme } from '../../hooks/useTheme';

type SkeletonVariant = 'list' | 'card' | 'text' | 'avatar';

interface SkeletonProps {
  variant?: SkeletonVariant;
  width?: number | string;
  height?: number;
  style?: ViewStyle;
  count?: number;
}

const SkeletonItem: React.FC<{
  width?: number | string;
  height?: number;
  style?: ViewStyle;
  borderRadius?: number;
}> = ({ width, height, style, borderRadius = 4 }) => {
  const { colors } = useTheme();
  const shimmerAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const animation = Animated.loop(
      Animated.sequence([
        Animated.timing(shimmerAnim, {
          toValue: 1,
          duration: 1200,
          useNativeDriver: true,
        }),
        Animated.timing(shimmerAnim, {
          toValue: 0,
          duration: 1200,
          useNativeDriver: true,
        }),
      ])
    );
    animation.start();
    return () => animation.stop();
  }, [shimmerAnim]);

  const translateX = shimmerAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [-200, 200],
  });

  return (
    <View
      style={[
        styles.skeleton,
        {
          width: width ?? '100%',
          height: height ?? 16,
          backgroundColor: colors.border,
          borderRadius,
          overflow: 'hidden',
        },
        style,
      ]}
    >
      <Animated.View
        style={[
          styles.shimmer,
          {
            transform: [{ translateX }],
          },
        ]}
      />
    </View>
  );
};

export const Skeleton: React.FC<SkeletonProps> = ({
  variant = 'text',
  width,
  height,
  style,
  count = 1,
}) => {
  const { colors } = useTheme();

  const renderVariant = () => {
    switch (variant) {
      case 'avatar':
        return (
          <SkeletonItem
            width={width ?? 48}
            height={height ?? 48}
            style={[style, { borderRadius: (height ?? 48) / 2 }]}
          />
        );
      case 'card':
        return (
          <View style={[styles.cardContainer, style]}>
            <SkeletonItem width="100%" height={160} borderRadius={12} />
            <View style={styles.cardContent}>
              <SkeletonItem width="70%" height={18} />
              <SkeletonItem width="40%" height={14} style={{ marginTop: 8 }} />
            </View>
          </View>
        );
      case 'list':
        return (
          <View style={[styles.listContainer, style]}>
            <SkeletonItem width={48} height={48} borderRadius={24} />
            <View style={styles.listContent}>
              <SkeletonItem width="60%" height={16} />
              <SkeletonItem width="40%" height={14} style={{ marginTop: 8 }} />
            </View>
          </View>
        );
      case 'text':
      default:
        return (
          <SkeletonItem
            width={width ?? '100%'}
            height={height ?? 16}
            style={style}
          />
        );
    }
  };

  return (
    <View style={{ gap: 12 }}>
      {Array.from({ length: count }).map((_, index) => (
        <View key={index}>{renderVariant()}</View>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  skeleton: {
    overflow: 'hidden',
  },
  shimmer: {
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(255,255,255,0.25)',
  },
  cardContainer: {
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: 'transparent',
  },
  cardContent: {
    padding: 12,
    gap: 4,
  },
  listContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
  },
  listContent: {
    flex: 1,
    marginLeft: 12,
    gap: 4,
  },
});
