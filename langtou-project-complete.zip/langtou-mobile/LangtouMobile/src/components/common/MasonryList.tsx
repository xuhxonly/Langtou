import React, { useCallback, useState, useEffect } from 'react';
import {
  View,
  FlatList,
  Dimensions,
  StyleSheet,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import type { Note } from '../../types';
import { NoteCard } from './NoteCard';
import { useTheme } from '../../hooks/useTheme';

const { width } = Dimensions.get('window');
const GAP = 8;
const COLUMN_WIDTH = (width - GAP * 3) / 2;

interface MasonryListProps {
  data: Note[];
  onRefresh?: () => void;
  onLoadMore?: () => void;
  refreshing?: boolean;
  loadingMore?: boolean;
  onNotePress?: (note: Note) => void;
  onLikePress?: (noteId: string) => void;
}

// 根据图片宽高比计算卡片高度
function getCardHeight(note: Note): number {
  if (note.imageWidth && note.imageHeight) {
    const ratio = note.imageHeight / note.imageWidth;
    return COLUMN_WIDTH * Math.max(0.75, Math.min(1.8, ratio));
  }
  // 默认随机比例模拟多种图片尺寸
  const hash = note.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const ratios = [1.0, 1.2, 1.33, 1.5, 0.75, 1.0, 1.2, 1.33];
  const ratio = ratios[hash % ratios.length];
  return COLUMN_WIDTH * ratio;
}

// 简单的瀑布流布局算法：将每个note分配到较矮的一列
function distributeToColumns(notes: Note[]): { left: Note[]; right: Note[] } {
  const left: Note[] = [];
  const right: Note[] = [];
  let leftHeight = 0;
  let rightHeight = 0;

  for (const note of notes) {
    const cardHeight = getCardHeight(note);
    if (leftHeight <= rightHeight) {
      left.push(note);
      leftHeight += cardHeight + 8; // 8 = marginBottom
    } else {
      right.push(note);
      rightHeight += cardHeight + 8;
    }
  }

  return { left, right };
}

export const MasonryList: React.FC<MasonryListProps> = ({
  data,
  onRefresh,
  onLoadMore,
  refreshing = false,
  loadingMore = false,
  onNotePress,
  onLikePress,
}) => {
  const { colors } = useTheme();

  const { left, right } = distributeToColumns(data);

  const renderColumn = useCallback(
    (columnData: Note[]) => (
      <View style={styles.column}>
        {columnData.map((item) => (
          <NoteCard
            key={item.id}
            note={item}
            onPress={onNotePress}
            onLike={onLikePress}
          />
        ))}
      </View>
    ),
    [onNotePress, onLikePress]
  );

  return (
    <FlatList
      data={[{ key: 'masonry' }]}
      renderItem={() => (
        <View style={styles.container}>
          {renderColumn(left)}
          {renderColumn(right)}
        </View>
      )}
      keyExtractor={(item) => item.key}
      refreshControl={
        onRefresh ? (
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        ) : undefined
      }
      onEndReached={onLoadMore}
      onEndReachedThreshold={0.5}
      ListFooterComponent={
        loadingMore ? (
          <View style={styles.footer}>
            <ActivityIndicator color={colors.primary} />
          </View>
        ) : null
      }
      showsVerticalScrollIndicator={false}
      contentContainerStyle={styles.contentContainer}
    />
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: GAP,
  },
  column: {
    width: COLUMN_WIDTH,
  },
  contentContainer: {
    paddingTop: GAP,
  },
  footer: {
    paddingVertical: 16,
    alignItems: 'center',
  },
});
