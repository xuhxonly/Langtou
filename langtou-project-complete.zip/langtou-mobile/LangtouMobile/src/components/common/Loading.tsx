import React from 'react';
import { View, Text, StyleSheet, ActivityIndicator, Dimensions } from 'react-native';
import { useTheme } from '../../hooks/useTheme';

const { width, height } = Dimensions.get('window');

interface LoadingProps {
  text?: string;
  mode?: 'fullscreen' | 'inline';
}

export const Loading: React.FC<LoadingProps> = ({
  text = '加载中...',
  mode = 'inline',
}) => {
  const { colors } = useTheme();

  if (mode === 'fullscreen') {
    return (
      <View style={[styles.fullscreenContainer, { backgroundColor: colors.overlay }]}>
        <View style={[styles.content, { backgroundColor: colors.surface }]}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={[styles.text, { color: colors.text }]}>{text}</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.inlineContainer}>
      <ActivityIndicator size="small" color={colors.primary} />
      <Text style={[styles.inlineText, { color: colors.textSecondary }]}>{text}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  fullscreenContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    width,
    height,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 999,
  },
  content: {
    paddingHorizontal: 32,
    paddingVertical: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 120,
  },
  text: {
    marginTop: 12,
    fontSize: 14,
    fontWeight: '500',
  },
  inlineContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
  },
  inlineText: {
    marginLeft: 8,
    fontSize: 14,
  },
});
