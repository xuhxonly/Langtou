import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import FastImage from 'react-native-fast-image';
import { useTheme } from '../../hooks/useTheme';
import { formatNumber } from '../../utils/format';
import type { Note } from '../../types';

const { width } = Dimensions.get('window');
const CARD_WIDTH = (width - 24) / 2;

// 支持的图片比例范围
const MIN_RATIO = 0.75; // 4:3 横向
const MAX_RATIO = 1.8; // 9:5 竖向
const DEFAULT_RATIO = 1.2; // 默认比例

interface NoteCardProps {
  note: Note;
  onPress?: (note: Note) => void;
  onLike?: (noteId: string) => void;
}

export const NoteCard: React.FC<NoteCardProps> = ({ note, onPress, onLike }) => {
  const { colors } = useTheme();
  const [imageHeight, setImageHeight] = useState<number | null>(null);

  // 根据图片实际宽高比计算卡片高度
  const calculateImageHeight = useCallback(
    (imgWidth: number, imgHeight: number) => {
      if (imgWidth <= 0 || imgHeight <= 0) return CARD_WIDTH * DEFAULT_RATIO;
      const ratio = imgHeight / imgWidth;
      // 限制比例范围，避免极端比例
      const clampedRatio = Math.max(MIN_RATIO, Math.min(MAX_RATIO, ratio));
      return CARD_WIDTH * clampedRatio;
    },
    []
  );

  // 如果 note 自带图片尺寸信息，直接使用
  const computedHeight =
    imageHeight ??
    (note.imageWidth && note.imageHeight
      ? calculateImageHeight(note.imageWidth, note.imageHeight)
      : null);

  // 如果没有预设尺寸，使用 FastImage 的 onLoad 回调获取
  const handleImageLoad = useCallback(
    (event: any) => {
      if (imageHeight !== null) return; // 已有高度则不重复计算
      const { width: imgWidth, height: imgHeight } = event.nativeEvent;
      const h = calculateImageHeight(imgWidth, imgHeight);
      setImageHeight(h);
    },
    [imageHeight, calculateImageHeight]
  );

  const displayHeight = computedHeight || CARD_WIDTH * DEFAULT_RATIO;

  return (
    <TouchableOpacity
      style={[styles.container, { backgroundColor: colors.surface }]}
      onPress={() => onPress?.(note)}
      activeOpacity={0.9}
    >
      <FastImage
        source={{ uri: note.images[0] }}
        style={[styles.image, { height: displayHeight }]}
        resizeMode={FastImage.resizeMode.cover}
        onLoad={handleImageLoad}
      />
      <View style={styles.content}>
        <Text style={[styles.title, { color: colors.text }]} numberOfLines={2}>
          {note.title}
        </Text>
        <View style={styles.authorRow}>
          <FastImage
            source={{ uri: note.author.avatar }}
            style={styles.avatar}
          />
          <Text style={[styles.authorName, { color: colors.textSecondary }]} numberOfLines={1}>
            {note.author.nickname}
          </Text>
        </View>
        <View style={styles.statsRow}>
          <TouchableOpacity onPress={() => onLike?.(note.id)} style={styles.statItem}>
            <Text style={[styles.statText, { color: colors.textSecondary }]}>
              {note.isLiked ? '❤️' : '🤍'} {formatNumber(note.likes)}
            </Text>
          </TouchableOpacity>
          <Text style={[styles.statText, { color: colors.textSecondary }]}>
            💬 {formatNumber(note.comments)}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    width: CARD_WIDTH,
    borderRadius: 12,
    marginBottom: 8,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  image: {
    width: CARD_WIDTH,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
  },
  content: {
    padding: 10,
  },
  title: {
    fontSize: 14,
    fontWeight: '500',
    lineHeight: 20,
    marginBottom: 8,
  },
  authorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  avatar: {
    width: 20,
    height: 20,
    borderRadius: 10,
    marginRight: 6,
  },
  authorName: {
    fontSize: 12,
    flex: 1,
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statText: {
    fontSize: 12,
  },
});
