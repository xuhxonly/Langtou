import React, { useRef, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Animated,
  ScrollView,
  Dimensions,
} from 'react-native';
import { useTheme } from '../../hooks/useTheme';

const { width: screenWidth } = Dimensions.get('window');

interface TabItem {
  key: string;
  label: string;
}

interface TabBarProps {
  tabs: TabItem[];
  activeKey: string;
  onChange: (key: string) => void;
  scrollable?: boolean;
}

export const TabBar: React.FC<TabBarProps> = ({
  tabs,
  activeKey,
  onChange,
  scrollable = false,
}) => {
  const { colors } = useTheme();
  const indicatorAnim = useRef(new Animated.Value(0)).current;
  const itemLayouts = useRef<Map<string, { x: number; width: number }>>(new Map()).current;

  const activeIndex = tabs.findIndex((t) => t.key === activeKey);

  useEffect(() => {
    const layout = itemLayouts.get(activeKey);
    if (layout) {
      Animated.spring(indicatorAnim, {
        toValue: layout.x + layout.width / 2,
        useNativeDriver: true,
        friction: 8,
        tension: 40,
      }).start();
    }
  }, [activeKey, indicatorAnim]);

  const handleLayout = (key: string, event: any) => {
    const { x, width } = event.nativeEvent.layout;
    itemLayouts.set(key, { x, width });
    if (key === activeKey) {
      indicatorAnim.setValue(x + width / 2);
    }
  };

  const renderTabs = () =>
    tabs.map((tab) => {
      const isActive = tab.key === activeKey;
      return (
        <TouchableOpacity
          key={tab.key}
          activeOpacity={0.8}
          onPress={() => onChange(tab.key)}
          onLayout={(e) => handleLayout(tab.key, e)}
          style={styles.tabItem}
        >
          <Text
            style={[
              styles.tabText,
              {
                color: isActive ? colors.primary : colors.textSecondary,
                fontWeight: isActive ? '700' : '400',
              },
            ]}
          >
            {tab.label}
          </Text>
        </TouchableOpacity>
      );
    });

  const indicatorWidth = itemLayouts.get(activeKey)?.width ?? 20;

  const content = (
    <View style={styles.container}>
      <View style={styles.tabsRow}>{renderTabs()}</View>
      <Animated.View
        style={[
          styles.indicator,
          {
            backgroundColor: colors.primary,
            width: indicatorWidth * 0.5,
            transform: [
              {
                translateX: indicatorAnim.interpolate({
                  inputRange: [0, screenWidth],
                  outputRange: [0, screenWidth],
                }),
              },
              { translateX: -(indicatorWidth * 0.25) },
            ],
          },
        ]}
      />
    </View>
  );

  if (scrollable) {
    return (
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        {content}
      </ScrollView>
    );
  }

  return content;
};

const styles = StyleSheet.create({
  container: {
    position: 'relative',
  },
  tabsRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  tabItem: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabText: {
    fontSize: 15,
  },
  indicator: {
    position: 'absolute',
    bottom: 0,
    height: 3,
    borderRadius: 1.5,
  },
});
