import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import FastImage from 'react-native-fast-image';

interface AvatarProps {
  uri?: string;
  size?: number;
  name?: string;
}

export const Avatar: React.FC<AvatarProps> = ({ uri, size = 40, name }) => {
  if (uri) {
    return (
      <FastImage
        source={{ uri }}
        style={[styles.image, { width: size, height: size, borderRadius: size / 2 }]}
      />
    );
  }

  return (
    <View
      style={[
        styles.fallback,
        { width: size, height: size, borderRadius: size / 2 },
      ]}
    >
      <Text style={[styles.text, { fontSize: size * 0.4 }]}>
        {name?.charAt(0) || '?'}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  image: {
    backgroundColor: '#E5E5E5',
  },
  fallback: {
    backgroundColor: '#FF2442',
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
});
