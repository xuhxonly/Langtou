import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useTheme } from '../../hooks/useTheme';

type BadgePosition = 'topRight' | 'topLeft' | 'bottomRight' | 'bottomLeft';

interface BadgeProps {
  count?: number;
  dot?: boolean;
  position?: BadgePosition;
  children: React.ReactNode;
  maxCount?: number;
}

export const Badge: React.FC<BadgeProps> = ({
  count,
  dot = false,
  position = 'topRight',
  children,
  maxCount = 99,
}) => {
  const { colors } = useTheme();

  const positionStyles: Record<BadgePosition, any> = {
    topRight: { top: -4, right: -4 },
    topLeft: { top: -4, left: -4 },
    bottomRight: { bottom: -4, right: -4 },
    bottomLeft: { bottom: -4, left: -4 },
  };

  const displayCount = count && count > maxCount ? `${maxCount}+` : String(count);

  return (
    <View style={styles.container}>
      {children}
      {(dot || (count !== undefined && count > 0)) && (
        <View
          style={[
            styles.badge,
            positionStyles[position],
            dot
              ? [styles.dot, { backgroundColor: colors.error }]
              : [styles.countBadge, { backgroundColor: colors.error }],
          ]}
        >
          {!dot && <Text style={styles.countText}>{displayCount}</Text>}
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'relative',
    alignSelf: 'flex-start',
  },
  badge: {
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  countBadge: {
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    paddingHorizontal: 4,
  },
  countText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: 'bold',
    lineHeight: 18,
  },
});
