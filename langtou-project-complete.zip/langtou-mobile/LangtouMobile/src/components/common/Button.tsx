import React from 'react';
import {
  TouchableOpacity,
  Text,
  StyleSheet,
  ActivityIndicator,
  View,
  type ViewStyle,
  type TextStyle,
} from 'react-native';
import { useTheme } from '../../hooks/useTheme';
import { Icon, type IconName } from './Icon';

type ButtonType = 'primary' | 'default' | 'danger' | 'link';
type ButtonSize = 'small' | 'medium' | 'large';

interface ButtonProps {
  title: string;
  type?: ButtonType;
  size?: ButtonSize;
  loading?: boolean;
  disabled?: boolean;
  icon?: IconName;
  onPress?: () => void;
  style?: ViewStyle;
  textStyle?: TextStyle;
}

export const Button: React.FC<ButtonProps> = ({
  title,
  type = 'default',
  size = 'medium',
  loading = false,
  disabled = false,
  icon,
  onPress,
  style,
  textStyle,
}) => {
  const { colors } = useTheme();

  const isDisabled = disabled || loading;

  const backgroundColors: Record<ButtonType, string> = {
    primary: colors.primary,
    default: colors.surface,
    danger: colors.error,
    link: 'transparent',
  };

  const textColors: Record<ButtonType, string> = {
    primary: '#FFFFFF',
    default: colors.text,
    danger: '#FFFFFF',
    link: colors.primary,
  };

  const borderColors: Record<ButtonType, string> = {
    primary: colors.primary,
    default: colors.border,
    danger: colors.error,
    link: 'transparent',
  };

  const sizeStyles: Record<ButtonSize, { height: number; fontSize: number; paddingHorizontal: number; iconSize: number }> = {
    small: { height: 32, fontSize: 13, paddingHorizontal: 12, iconSize: 14 },
    medium: { height: 44, fontSize: 15, paddingHorizontal: 20, iconSize: 18 },
    large: { height: 52, fontSize: 17, paddingHorizontal: 28, iconSize: 22 },
  };

  const s = sizeStyles[size];

  return (
    <TouchableOpacity
      activeOpacity={0.8}
      onPress={onPress}
      disabled={isDisabled}
      style={[
        styles.container,
        {
          height: s.height,
          paddingHorizontal: s.paddingHorizontal,
          backgroundColor: isDisabled ? colors.border : backgroundColors[type],
          borderColor: isDisabled ? colors.border : borderColors[type],
          borderWidth: type === 'link' ? 0 : 1,
          borderRadius: type === 'link' ? 0 : s.height / 2,
        },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={textColors[type]} size="small" />
      ) : (
        <View style={styles.content}>
          {icon && (
            <Icon
              name={icon}
              size={s.iconSize}
              color={isDisabled ? colors.textSecondary : textColors[type]}
              style={styles.icon}
            />
          )}
          <Text
            style={[
              styles.text,
              {
                fontSize: s.fontSize,
                color: isDisabled ? colors.textSecondary : textColors[type],
              },
              textStyle,
            ]}
          >
            {title}
          </Text>
        </View>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  icon: {
    marginRight: 6,
  },
  text: {
    fontWeight: '600',
  },
});
