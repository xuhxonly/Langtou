import { create } from 'zustand';
import type { ThemeMode } from '../types';
import { Colors } from '../constants/colors';

interface ThemeState {
  mode: ThemeMode;
  colors: typeof Colors.light;
  toggleTheme: () => void;
  setTheme: (mode: ThemeMode) => void;
}

export const useThemeStore = create<ThemeState>((set) => ({
  mode: 'light',
  colors: Colors.light,
  toggleTheme: () =>
    set((state) => {
      const newMode = state.mode === 'light' ? 'dark' : 'light';
      return { mode: newMode, colors: Colors[newMode] };
    }),
  setTheme: (mode) => set({ mode, colors: Colors[mode] }),
}));
