import { create } from 'zustand';
import wsManager, { WSConnectionState, WSMessageType, WSMessage } from '../api/websocket';
import { Storage } from '../utils/storage';
import { STORAGE_KEYS } from '../constants/config';
import type { Message, Notification } from '../types';

interface WebSocketState {
  connectionState: WSConnectionState;
  reconnectAttempts: number;
  messages: Message[];
  notifications: Notification[];

  // Actions
  connect: () => void;
  disconnect: () => void;
  sendChatMessage: (conversationId: string, content: string, type?: string) => boolean;
  sendTyping: (conversationId: string) => boolean;
  addMessage: (message: Message) => void;
  addNotification: (notification: Notification) => void;
  clearMessages: () => void;
}

export const useWebSocketStore = create<WebSocketState>((set, get) => ({
  connectionState: WSConnectionState.DISCONNECTED,
  reconnectAttempts: 0,
  messages: [],
  notifications: [],

  connect: () => {
    const token = Storage.get(STORAGE_KEYS.AUTH_TOKEN);
    if (!token) {
      console.warn('[WSStore] 无Token，无法连接WebSocket');
      return;
    }

    // 监听连接状态变化
    wsManager.onStateChange((state) => {
      set({ connectionState: state });
    });

    // 监听聊天消息
    wsManager.onMessage(WSMessageType.CHAT_MESSAGE, (wsMessage: WSMessage<Message>) => {
      get().addMessage(wsMessage.data);
    });

    // 监听通知消息
    wsManager.onMessage(WSMessageType.NOTIFICATION, (wsMessage: WSMessage<Notification>) => {
      get().addNotification(wsMessage.data);
    });

    // 建立连接
    wsManager.connect(token);
  },

  disconnect: () => {
    wsManager.disconnect();
    set({
      connectionState: WSConnectionState.DISCONNECTED,
      messages: [],
      notifications: [],
    });
  },

  sendChatMessage: (conversationId: string, content: string, type: string = 'text') => {
    return wsManager.sendChatMessage(conversationId, content, type);
  },

  sendTyping: (conversationId: string) => {
    return wsManager.sendTyping(conversationId);
  },

  addMessage: (message: Message) => {
    set((state) => ({
      messages: [...state.messages, message],
    }));
  },

  addNotification: (notification: Notification) => {
    set((state) => ({
      notifications: [notification, ...state.notifications],
    }));
  },

  clearMessages: () => {
    set({ messages: [] });
  },
}));
