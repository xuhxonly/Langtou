# 榔头 (Langtou) 社交内容社区 APP

榔头是一个类似小红书的社交内容社区移动应用，采用 React Native 0.86+ (New Architecture) 开发，支持 iOS 和 Android 双平台。

## 技术栈

- **React Native**: 0.86.0
- **React**: 19.2.3
- **TypeScript**: 5.8.3
- **状态管理**: Zustand
- **数据获取**: TanStack Query (React Query)
- **导航**: React Navigation v7
- **图片加载**: react-native-fast-image
- **HTTP 请求**: Axios

## 项目结构

```
LangtouMobile/
├── android/              # Android 原生代码
├── ios/                  # iOS 原生代码
├── src/
│   ├── api/              # API 请求封装
│   │   ├── client.ts     # Axios 客户端配置
│   │   └── notes.ts      # 笔记相关 API
│   ├── assets/           # 图片、字体等资源
│   │   ├── images/
│   │   └── fonts/
│   ├── components/       # 公共组件
│   │   ├── common/       # 通用组件
│   │   │   ├── Avatar.tsx
│   │   │   ├── MasonryList.tsx
│   │   │   └── NoteCard.tsx
│   │   └── business/     # 业务组件
│   ├── constants/        # 常量配置
│   │   ├── colors.ts     # 主题颜色
│   │   └── config.ts     # 应用配置
│   ├── hooks/            # 自定义 Hooks
│   │   ├── useNotes.ts   # 笔记数据 Hook
│   │   └── useTheme.ts   # 主题 Hook
│   ├── navigation/       # 导航配置
│   │   ├── AppNavigator.tsx
│   │   └── TabNavigator.tsx
│   ├── screens/          # 页面
│   │   ├── auth/         # 登录/注册
│   │   │   └── LoginScreen.tsx
│   │   ├── home/         # 首页
│   │   │   └── HomeScreen.tsx
│   │   ├── discover/     # 发现页
│   │   │   └── DiscoverScreen.tsx
│   │   ├── publish/      # 发布页
│   │   │   └── PublishScreen.tsx
│   │   ├── message/      # 消息页
│   │   │   └── MessageScreen.tsx
│   │   └── profile/      # 个人中心
│   │       └── ProfileScreen.tsx
│   ├── store/            # 状态管理 (Zustand)
│   │   ├── useAuthStore.ts
│   │   └── useThemeStore.ts
│   ├── types/            # TypeScript 类型定义
│   │   └── index.ts
│   └── utils/            # 工具函数
│       ├── format.ts     # 格式化工具
│       ├── mockData.ts   # Mock 数据
│       └── storage.ts    # 本地存储
├── App.tsx               # 应用入口
├── package.json
├── tsconfig.json
├── metro.config.js
└── babel.config.js
```

## 核心功能

### 1. 底部 Tab 导航
- 首页：双列瀑布流展示笔记
- 发现：搜索和热门内容
- 发布：图文发布编辑器
- 消息：通知和互动消息
- 我的：个人中心和设置

### 2. 首页瀑布流
- 双列 Masonry 布局
- 支持下拉刷新和上拉加载更多
- 笔记卡片展示图片、标题、作者和互动数据

### 3. 笔记卡片
- 图片展示 (FastImage 优化加载)
- 标题和作者信息
- 点赞、评论数显示
- 点击交互

### 4. 发布页面
- 图片选择器 (支持多选，最多9张)
- 标题和正文输入
- 标签添加功能
- 表单验证

### 5. 登录/注册
- 手机号验证码登录
- 未登录状态拦截
- 模拟用户数据

### 6. 个人中心
- 用户信息展示
- 粉丝/关注/获赞统计
- 我的笔记列表
- 编辑资料和设置

### 7. 主题系统
- 支持浅色/深色模式
- Zustand 全局状态管理
- 动态颜色切换

## 启动方式

### 安装依赖

```bash
cd LangtouMobile
npm install
# 或
yarn install
```

### iOS

```bash
cd ios && pod install && cd ..
npx react-native run-ios
```

### Android

```bash
npx react-native run-android
```

### 启动 Metro 服务

```bash
npx react-native start
```

## Mock 数据

项目内置了丰富的 Mock 数据，包括：
- 模拟用户数据 (5个不同领域的创作者)
- 模拟笔记数据 (10种不同类型的内容)
- 模拟通知数据 (点赞、评论、关注、收藏)

所有 API 请求均通过 setTimeout 模拟网络延迟，方便开发和演示。

## 注意事项

1. 本项目使用 React Native 0.86.0，支持 New Architecture (Fabric & TurboModules)
2. 图片使用 react-native-fast-image 进行优化加载
3. 状态管理使用 Zustand，轻量且易用
4. 数据获取使用 TanStack Query，支持缓存和自动刷新
5. 主题系统支持动态切换，颜色配置集中在 constants/colors.ts
